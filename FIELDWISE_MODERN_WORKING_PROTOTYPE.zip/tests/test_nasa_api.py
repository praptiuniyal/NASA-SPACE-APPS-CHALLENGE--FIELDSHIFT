"""Tests for engine/nasa_api.py and tools/prefetch_demo.py.
Run: python -m pytest tests/test_nasa_api.py
NO real NASA call here. FAKE_FOR_TESTS is made-up data used only to test our code."""
import json
import tempfile
from datetime import datetime, timedelta, date
from pathlib import Path
from unittest import mock

from engine import nasa_api
from tools import prefetch_demo

FAKE_FOR_TESTS = {'T2M': 20.0, 'T2M_MAX': 30.0, 'T2M_MIN': 10.0, 'PRECTOTCORR': 2.0,
                  'ALLSKY_SFC_SW_DWN': 5.0, 'RH2M': 60.0, 'WS2M': 2.0, 'GWETROOT': 0.5}


class FakeResponse:
    def __init__(self, status_code, payload, text=''):
        self.status_code, self._payload, self.text = status_code, payload, text
    def json(self):
        return self._payload


def make_payload(params, solar_units='MJ/m^2/day', holes=()):
    """Build a fake NASA answer for the dates asked. holes = day numbers where T2M is -999."""
    start = datetime.strptime(params['start'], '%Y%m%d').date()
    end = datetime.strptime(params['end'], '%Y%m%d').date()
    days = [start + timedelta(days=i) for i in range((end - start).days + 1)]
    series = {name: {} for name in FAKE_FOR_TESTS}
    for i, d in enumerate(days):
        key = d.strftime('%Y%m%d')
        for name, value in FAKE_FOR_TESTS.items():
            series[name][key] = -999 if (name == 'T2M' and i in holes) else value
    return {'properties': {'parameter': series},
            'parameters': {'ALLSKY_SFC_SW_DWN': {'units': solar_units}}}


class FakeRequests:
    """Stands in for the 'requests' library."""
    def __init__(self, solar_units='MJ/m^2/day', holes=(), fail_status=None, raise_error=False):
        self.solar_units, self.holes = solar_units, holes
        self.fail_status, self.raise_error, self.calls = fail_status, raise_error, 0
    def get(self, url, params=None, timeout=None):
        self.calls += 1
        if self.raise_error:
            raise ConnectionError('no internet (fake)')
        if self.fail_status:
            return FakeResponse(self.fail_status, {}, 'Unprocessable (fake)')
        return FakeResponse(200, make_payload(params, self.solar_units, self.holes))


def run(fake, years=2, lat=29.2, lon=79.5, cache_dir=None):
    """Call get_history with the fake internet and a temporary cache folder."""
    with tempfile.TemporaryDirectory() as tmp:
        folder = cache_dir if cache_dir is not None else Path(tmp)
        with mock.patch.object(nasa_api, 'requests', fake), \
             mock.patch.object(nasa_api, 'CACHE_DIR', folder), \
             mock.patch.object(nasa_api, 'RETRY_WAIT_S', 0):
            return nasa_api.get_history(lat, lon, years)


def test_minus_999_short_gap_filled_long_gap_stays_none():
    holes = {10, 100, 101, 102, 103, 104}          # 1-day gap, then a 5-day gap
    h = run(FakeRequests(holes=holes))
    t = h['daily']['tmean_c']
    assert t[10] == 20.0                             # filled by a straight line
    assert all(t[i] is None for i in range(100, 105))   # long gap stays None, never 0
    n_days = len(t)
    assert abs(h['data_quality']['missing_pct'] - round(100 * 5 / (8 * n_days), 2)) < 1e-9

def test_solar_unit_conversion_kwh_to_mj():
    assert run(FakeRequests(solar_units='kW-hr/m^2/day'))['daily']['solar_mj_m2'][0] == 18.0   # 5 x 3.6
    assert run(FakeRequests(solar_units='MJ/m^2/day'))['daily']['solar_mj_m2'][0] == 5.0

def test_history_has_exactly_the_contract_keys():
    h = run(FakeRequests())
    assert h['status'] == 'success' and h['source'] == 'NASA POWER'
    assert set(h) == {'status', 'code', 'message', 'source', 'fetched_on', 'grid_cell',
                      'years', 'daily', 'data_quality'}
    assert set(h['daily']) == {'date', 'tmax_c', 'tmin_c', 'tmean_c', 'rain_mm', 'solar_mj_m2',
                               'rh_pct', 'wind_ms', 'soil_wetness', 'et0_mm'}
    assert set(h['data_quality']) == {'years_available', 'missing_pct', 'from_cache'}
    assert h['data_quality']['from_cache'] is False
    assert h['grid_cell'] == {'latitude': 29.0, 'longitude': 79.5}
    start, end = nasa_api._date_range(2)
    assert h['years'] == [start, end] and h['daily']['date'][0] == f'{start}-01-01'
    assert h['daily']['date'][-1] == f'{end}-12-31'
    assert all(v is not None and v > 0 for v in h['daily']['et0_mm'])

def test_cache_fallback_then_error_when_no_cache():
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)
        first = run(FakeRequests(), cache_dir=folder)             # saves a copy
        assert first['data_quality']['from_cache'] is False and list(folder.glob('*.json'))
        again = run(FakeRequests(raise_error=True), cache_dir=folder)   # internet "unplugged"
        assert again['status'] == 'success' and again['data_quality']['from_cache'] is True
        assert again['daily']['tmean_c'] == first['daily']['tmean_c']
    no_cache = run(FakeRequests(raise_error=True))
    assert no_cache['status'] == 'error' and no_cache['code'] == 'nasa_unavailable'

def test_retries_then_clear_error_on_http_failure():
    fake = FakeRequests(fail_status=422)
    h = run(fake)
    assert fake.calls == 3                                          # 1 try + 2 retries
    assert h['code'] == 'nasa_unavailable' and '422' in h['message']

def test_bad_coordinates_and_years_return_errors():
    for lat, lon in [(95, 10), (10, 200), (None, 5), ('x', 5)]:
        assert nasa_api.get_history(lat, lon)['code'] == 'invalid_coordinates'
    assert nasa_api.get_history(29.2, 79.5, years=0)['code'] == 'invalid_years'
    assert nasa_api.get_history(29.2, 79.5, years=100)['code'] == 'invalid_years'

def test_grid_rounding():
    assert nasa_api._grid(29.2) == 29.0 and nasa_api._grid(79.5) == 79.5
    assert nasa_api._grid(30.9) == 31.0 and nasa_api._grid(75.85) == 76.0


# ---------- get_nasa_data with a tiny made-up history (hand-checkable) ----------
def tiny_history():
    """3 years. Year k has rain k mm/day except 10 dry days (Jul 1-10); temperature 20, 21, 22."""
    d = {key: [] for key in ['date', 'tmax_c', 'tmin_c', 'tmean_c', 'rain_mm',
                             'solar_mj_m2', 'rh_pct', 'wind_ms', 'soil_wetness', 'et0_mm']}
    for k, year in enumerate([2001, 2002, 2003], start=1):
        day = date(year, 1, 1)
        while day.year == year:
            dry = day.month == 7 and day.day <= 10
            t = 19.0 + k
            d['date'].append(day.isoformat()); d['tmean_c'].append(t)
            d['tmax_c'].append(t + 10); d['tmin_c'].append(t - 10)
            d['rain_mm'].append(0.0 if dry else float(k)); d['et0_mm'].append(4.0)
            d['solar_mj_m2'].append(15.0); d['rh_pct'].append(60.0)
            d['wind_ms'].append(2.0); d['soil_wetness'].append(0.5)
            day += timedelta(days=1)
    return {'status': 'success', 'code': None, 'message': None, 'source': 'NASA POWER',
            'fetched_on': '2026-11-01', 'grid_cell': {'latitude': 29.0, 'longitude': 79.5},
            'years': [2001, 2002, 2003], 'daily': d,
            'data_quality': {'years_available': 3, 'missing_pct': 0.0, 'from_cache': False}}

def test_get_nasa_data_indicators_by_hand():
    with mock.patch.object(nasa_api, 'get_history', lambda lat, lon, years=30: tiny_history()):
        c = nasa_api.get_nasa_data(29.2, 79.5)
    assert c['status'] == 'success'
    assert set(c) == {'status', 'code', 'message', 'source', 'fetched_on', 'location', 'summary',
                      'seasons', 'indicators', 'data_quality'}
    s, ind = c['summary'], c['indicators']
    assert s['rain_annual_mm'] == 710.0                       # totals 355, 710, 1065
    assert ind['rain_cv'] == 0.408                            # pstdev 289.8 / 710
    assert ind['temp_trend_c_per_decade'] == 10.0             # 20, 21, 22 -> +1 per year
    assert ind['rain_trend_pct'] is None                      # needs more than 10 years
    assert ind['dry_spell_days_max'] == 10                    # Jul 1-10 every year

def test_get_nasa_data_seasons_by_hand():
    with mock.patch.object(nasa_api, 'get_history', lambda lat, lon, years=30: tiny_history()):
        seasons = nasa_api.get_nasa_data(29.2, 79.5)['seasons']
    assert seasons['kharif']['rain_mm'] == 252.0              # (136-10 days) x mean 2 mm
    assert seasons['kharif']['et0_mm'] == 544.0               # 136 days x 4
    assert seasons['kharif']['temp_mean_c'] == 21.0 and seasons['zaid']['temp_mean_c'] == 21.0
    assert abs(seasons['rabi']['temp_mean_c'] - 20.99) < 0.01  # only 2 complete rabi seasons

def test_get_nasa_data_passes_errors_through():
    c = nasa_api.get_nasa_data(500, 10)
    assert c['status'] == 'error' and c['code'] == 'invalid_coordinates'


# ---------- prefetch_demo ----------
def test_demo_farms_follow_the_contract():
    keys = {'name', 'latitude', 'longitude', 'area_ha', 'soil_type', 'irrigation',
            'water_availability', 'start_season', 'previous_crops', 'current_plan',
            'priority', 'language'}
    assert len(prefetch_demo.DEMO_FARMS) == 3
    for f in prefetch_demo.DEMO_FARMS:
        assert set(f) == keys and f['area_ha'] == 1.5
        assert len(f['previous_crops']) == 2 and len(f['current_plan']) in (0, 3)
        assert f['priority'] == 'balanced' and f['language'] == 'en'
    assert prefetch_demo.DEMO_FARMS[2]['irrigation'] == 'rainfed'

def test_demo_file_and_crop_warnings():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'demo_farms.json'
        prefetch_demo.write_demo_farms(path)
        assert len(json.loads(path.read_text())['farms']) == 3
        csv_path = Path(tmp) / 'crops.csv'
        assert prefetch_demo.crop_name_warnings(prefetch_demo.DEMO_FARMS, csv_path) == []   # no file yet
        csv_path.write_text('crop,season\nwheat,rabi\nrice,kharif\n')
        warns = prefetch_demo.crop_name_warnings(prefetch_demo.DEMO_FARMS, csv_path)
        assert any("'mungbean'" in w for w in warns) and not any("'wheat'" in w for w in warns)
