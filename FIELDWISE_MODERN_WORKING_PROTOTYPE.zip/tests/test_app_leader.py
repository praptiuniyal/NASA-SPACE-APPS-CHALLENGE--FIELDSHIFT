import app

def test_health_and_pages():
    c=app.app.test_client(); assert c.get('/api/health').get_json()=={'status':'success','version':2}
    for p in ['/','/farm','/dashboard','/methods']: assert c.get(p).status_code==200

def test_contract_api_shapes_mock_mode():
    c=app.app.test_client(); crops=c.get('/api/crops').get_json(); assert crops['version']==2 and len(crops['rows'])==14
    farms=c.get('/api/demo-farms').get_json(); assert farms['version']==2 and len(farms['farms'])==3
    assert c.get('/api/mock').get_json()['mock'] is True

def test_validate_bad_farm_returns_400():
    c=app.app.test_client(); r=c.post('/api/validate-farm',json={'latitude':999}); assert r.status_code==400 and r.get_json()['version']==2

def test_gpm_context_endpoint_rejects_missing_location():
    c=app.app.test_client(); r=c.get('/api/gpm-context')
    assert r.status_code==400 and r.get_json()['code']=='gpm_invalid_location'
