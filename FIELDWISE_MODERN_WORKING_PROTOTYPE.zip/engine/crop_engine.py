"""engine/crop_engine.py  (Member 3)

Scores every crop for a farm.

    water_satisfaction(season_stats, farm)                    -> float 0..1 or None
    calculate_crop_suitability(crop_params, farm, climate, history) -> crop_result
    recommend_crops(farm, climate, history)                   -> {status, slots, rejected}

Uses crop_season_stats() from Member 2 (engine/season_stats.py). Functions never
raise: on failure they return {'status': 'error', 'code': ..., 'message': ...}.
"""
from statistics import median

from engine.crop_data import (
    OVERLAP_WARNING_DAYS,
    SLOT_DAYS,
    load_crops_report,
    sow_date_for_year,
    total_duration_days,
)

# Member 2 may not have delivered season_stats.py yet. Keep the import error so the
# message tells the leader what is wrong instead of failing at import time.
_SEASON_STATS_IMPORT_ERROR = None
try:
    from engine.season_stats import crop_season_stats
except Exception as exc:  # noqa: BLE001
    crop_season_stats = None
    _SEASON_STATS_IMPORT_ERROR = str(exc)

# ---------------------------------------------------------------- constants
# Share of a crop's water need (etc_mm) that irrigation can supply.
# ASSUMPTION: rainfed gets none; canal water is less reliable than borewell water
# (canal supply is rotational and can be cut at the tail end), so borewell shares
# are higher. water_availability scales how much of the need can be met.
IRRIGATION_SHARE = {
    "rainfed": {"low": 0.00, "medium": 0.00, "high": 0.00},   # ASSUMPTION
    "canal":   {"low": 0.40, "medium": 0.70, "high": 0.90},   # ASSUMPTION
    "borewell": {"low": 0.50, "medium": 0.80, "high": 1.00},  # ASSUMPTION
}

# Usable water the soil can hold for the crop, in mm. ASSUMPTION: clay holds the
# most, sand the least (rough textbook available-water values over the root zone).
SOIL_STORE_MM = {"sandy": 40, "loamy": 90, "silty": 100, "clay": 110}  # ASSUMPTION

# Weights of the crop score (sum 1.0).  # ASSUMPTION
SCORE_WEIGHTS = {"temperature": 0.25, "water": 0.35, "soil": 0.15, "season": 0.10, "stress": 0.15}

TEMP_FALLOFF_PER_C = 10.0        # ASSUMPTION: lose 10 points per degree outside the optimum
SOIL_NOT_PREFERRED_SCORE = 60    # from the prompt
OVERLAP_SEASON_PENALTY = 20      # from the prompt
# ASSUMPTION: a year counts as a "problem year" if it has at least this many days of
# heat at flowering, frost, or waterlogging. One hot day should not condemn a whole year,
# but a single frost day at the wrong stage can.
STRESS_DAY_LIMITS = {"heat": 3, "frost": 1, "waterlog": 3}

REJECT_HEAT_MEDIAN_DAYS = 5      # ASSUMPTION: median heat days at flowering above this -> reject
REJECT_WATER_MEAN = 0.5          # ASSUMPTION: mean water satisfaction below this -> reject
REJECT_WATERLOG_MEDIAN_DAYS = 3  # ASSUMPTION: median waterlog days above this -> reject
WATER_MOSTLY_MET = 0.8           # ASSUMPTION: at or above this counts as "mostly met"

_SUB_SCORE_KEYS = ("temperature", "water", "soil", "season", "stress")


def _msg(code, **params):
    """Build a message object (contract rule 7)."""
    return {"code": code, "params": params}


# ---------------------------------------------------------------- 1. water
def water_satisfaction(season_stats, farm):
    """Fraction (0..1) of the crop's water need that rain + irrigation + soil store meet.

    = min(1, (effective_rain_mm + irrigation_share * etc_mm + soil_store_mm) / etc_mm)
    Returns None if the inputs needed are unknown or etc_mm is None or 0.
    """
    try:
        etc = season_stats.get("etc_mm")
        rain = season_stats.get("effective_rain_mm")
        if etc is None or etc <= 0 or rain is None:
            return None
        if farm.get("irrigation") == "rainfed":
            share = 0.0  # water_availability is forced to low for rainfed farms
        else:
            share = IRRIGATION_SHARE.get(farm.get("irrigation"), {}).get(farm.get("water_availability"))
        store = SOIL_STORE_MM.get(farm.get("soil_type"))
        if share is None or store is None:
            return None
        value = (rain + share * etc + store) / etc
        return max(0.0, min(1.0, float(value)))
    except Exception:  # noqa: BLE001
        return None


# ---------------------------------------------------------------- 2. suitability
def _temperature_score(temp_mean, topt_min, topt_max):
    """100 inside the optimum range, falling off outside it. None if unknown."""
    if temp_mean is None or topt_min is None or topt_max is None:
        return None
    if topt_min <= temp_mean <= topt_max:
        return 100.0
    gap = topt_min - temp_mean if temp_mean < topt_min else temp_mean - topt_max
    return max(0.0, 100.0 - TEMP_FALLOFF_PER_C * gap)


def _history_years(history):
    """List of years in the history (from 'years', else from the daily dates)."""
    years = history.get("years")
    if years:
        return [int(y) for y in years]
    dates = (history.get("daily") or {}).get("date") or []
    return sorted({int(d[:4]) for d in dates})


def _get_stats(crop_params, daily, year, cache):
    """Season stats for one crop-year, cached per (crop, season, year)."""
    key = (crop_params["crop"], crop_params["season"], year)
    if cache is not None and key in cache:
        return cache[key]
    stats = None
    sow_date = sow_date_for_year(crop_params, year)
    if sow_date and crop_season_stats is not None:
        try:
            stats = crop_season_stats(daily, crop_params, sow_date)
        except Exception:  # noqa: BLE001
            stats = None
    if cache is not None:
        cache[key] = stats
    return stats


def _weighted_score(sub_scores):
    """Weighted mean of the known sub-scores (weights renormalised over known ones)."""
    total, weight_sum = 0.0, 0.0
    for name, weight in SCORE_WEIGHTS.items():
        value = sub_scores.get(name)
        if value is not None:
            total += weight * value
            weight_sum += weight
    return None if weight_sum == 0 else total / weight_sum


def _calculate(crop_params, farm, climate, history, cache):
    """Core of calculate_crop_suitability, with an optional shared cache."""
    crop = crop_params.get("crop")
    season = crop_params.get("season")
    result = {
        "crop": crop, "season": season, "score": None,
        "sub_scores": {k: None for k in _SUB_SCORE_KEYS},
        "reasons": [], "warnings": [], "rejected": False, "reject_reason": None,
    }
    sub = result["sub_scores"]

    # --- temperature: seasonal mean temperature from the climate summary
    seasons = (climate.get("seasons") or {}) if isinstance(climate, dict) else {}
    temp_mean = (seasons.get(season) or {}).get("temp_mean_c")
    sub["temperature"] = _temperature_score(
        temp_mean, crop_params.get("topt_min_c"), crop_params.get("topt_max_c"))
    if sub["temperature"] is None:
        result["warnings"].append(_msg("temperature_data_missing"))
    elif sub["temperature"] >= 100.0:
        result["reasons"].append(_msg("temperature_in_range"))
    else:
        result["warnings"].append(_msg("temperature_out_of_range", mean_c=round(temp_mean, 1)))

    # --- soil
    soil_type = farm.get("soil_type")
    if soil_type is None:
        result["warnings"].append(_msg("soil_unknown"))
    elif soil_type in (crop_params.get("preferred_soil") or []):
        sub["soil"] = 100.0
        result["reasons"].append(_msg("soil_matches", soil=soil_type))
    else:
        sub["soil"] = float(SOIL_NOT_PREFERRED_SCORE)
        result["warnings"].append(_msg("soil_not_preferred", soil=soil_type))

    # --- season: 100, minus 20 when the crop is longer than its slot (harvest_overlap)
    sub["season"] = 100.0
    duration = total_duration_days(crop_params)
    overlap = None if duration is None or season not in SLOT_DAYS else duration - SLOT_DAYS[season]
    if overlap is not None and overlap > OVERLAP_WARNING_DAYS:
        sub["season"] -= OVERLAP_SEASON_PENALTY
        result["warnings"].append(_msg("harvest_overlap", days=overlap))

    # --- history: season stats for every year
    if crop_season_stats is None:
        result["rejected"] = True
        result["reject_reason"] = _msg("season_stats_unavailable")
        return result

    water_values, heat_days, waterlog_days, problem_flags = [], [], [], []
    daily = history.get("daily") if isinstance(history, dict) else None
    for year in _history_years(history):
        stats = _get_stats(crop_params, daily, year, cache)
        # Rule S4: incomplete (or failed) seasons are left out.
        if not isinstance(stats, dict) or stats.get("status") == "error" \
                or stats.get("season_completed") is not True:
            continue
        ws = water_satisfaction(stats, farm)
        if ws is not None:
            water_values.append(ws)
        heat = stats.get("heat_days_flowering")
        frost = stats.get("frost_days")
        waterlog = stats.get("waterlog_days")
        if heat is not None:
            heat_days.append(heat)
        if waterlog is not None:
            waterlog_days.append(waterlog)
        checks = [(heat, "heat"), (frost, "frost"), (waterlog, "waterlog")]
        known = [(v, kind) for v, kind in checks if v is not None]
        if known:  # a year with all three unknown says nothing about stress
            problem_flags.append(any(v >= STRESS_DAY_LIMITS[kind] for v, kind in known))

    if not water_values:
        # No usable seasons at all: we do not guess a score (unknown stays None).
        result["rejected"] = True
        result["reject_reason"] = _msg("no_complete_seasons")
        return result

    mean_ws = sum(water_values) / len(water_values)
    sub["water"] = mean_ws * 100.0
    if problem_flags:
        sub["stress"] = 100.0 - 100.0 * sum(problem_flags) / len(problem_flags)
    else:
        result["warnings"].append(_msg("stress_data_missing"))

    if mean_ws >= WATER_MOSTLY_MET:
        result["reasons"].append(_msg("water_mostly_met"))
    elif mean_ws >= REJECT_WATER_MEAN:
        result["warnings"].append(_msg("water_partly_met", percent=round(mean_ws * 100)))

    # --- score
    score = _weighted_score(sub)
    result["score"] = None if score is None else round(max(0.0, min(100.0, score)), 1)
    for key in _SUB_SCORE_KEYS:
        if sub[key] is not None:
            sub[key] = round(sub[key], 1)

    # --- rejection rules (first one found is the reject_reason; the rest are warnings)
    rejections = []
    if heat_days and median(heat_days) > REJECT_HEAT_MEDIAN_DAYS:
        rejections.append(_msg("heat_flowering", days=int(round(median(heat_days)))))
    if mean_ws < REJECT_WATER_MEAN:
        rejections.append(_msg("water_deficit"))
    if crop_params.get("waterlogging_sensitive") is True and waterlog_days \
            and median(waterlog_days) > REJECT_WATERLOG_MEDIAN_DAYS:
        rejections.append(_msg("waterlogging", days=int(round(median(waterlog_days)))))
    if rejections:
        result["rejected"] = True
        result["reject_reason"] = rejections[0]
        result["warnings"].extend(rejections[1:])
    return result


def calculate_crop_suitability(crop_params, farm, climate, history):
    """Return a crop_result for one crop row (see contract). Never raises."""
    try:
        return _calculate(crop_params, farm, climate, history, cache=None)
    except Exception as exc:  # noqa: BLE001
        return {"status": "error", "code": "crop_suitability_failed", "message": str(exc)}


# ---------------------------------------------------------------- 3. recommend
def _excluded_result(item):
    """crop_result for a crop the loader excluded (no numbers, only the reason)."""
    return {
        "crop": item.get("crop"), "season": item.get("season"), "score": None,
        "sub_scores": {k: None for k in _SUB_SCORE_KEYS},
        "reasons": [], "warnings": [], "rejected": True,
        "reject_reason": _msg(item.get("code") or "missing_data"),
    }


def recommend_crops(farm, climate, history):
    """Return {'status', 'slots': {kharif, rabi, zaid: [crop_result] best first}, 'rejected': [...]}."""
    try:
        if not isinstance(history, dict) or history.get("status") == "error" \
                or not history.get("daily"):
            return {"status": "error", "code": "history_unavailable",
                    "message": "History data is missing, so crops cannot be scored."}
        if crop_season_stats is None:
            return {"status": "error", "code": "season_stats_unavailable",
                    "message": "engine/season_stats.py could not be imported: %s"
                               % _SEASON_STATS_IMPORT_ERROR}

        report = load_crops_report()
        out = {"status": "success", "slots": {"kharif": [], "rabi": [], "zaid": []}, "rejected": []}
        for item in report["excluded"]:
            out["rejected"].append(_excluded_result(item))

        cache = {}  # (crop, season, year) -> season_stats, shared across crops in this call
        for params in report["crops"]:
            crop_result = _calculate(params, farm, climate, history, cache)
            if crop_result["rejected"]:
                out["rejected"].append(crop_result)
            else:
                out["slots"][crop_result["season"]].append(crop_result)

        for slot_list in out["slots"].values():
            slot_list.sort(key=lambda r: (-r["score"], r["crop"]))  # best first
        out["rejected"].sort(key=lambda r: (r["season"] or "", r["crop"] or ""))
        return out
    except Exception as exc:  # noqa: BLE001
        return {"status": "error", "code": "recommend_crops_failed", "message": str(exc)}
