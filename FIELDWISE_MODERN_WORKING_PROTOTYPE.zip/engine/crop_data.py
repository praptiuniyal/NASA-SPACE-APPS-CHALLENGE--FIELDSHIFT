"""engine/crop_data.py  (Member 3)

Loads data/crops.csv into crop_params dicts exactly as in the contract.

Public functions (contract):
    load_crops()         -> list of crop_params
    load_crops_report()  -> {'crops': [...], 'excluded': [{'crop','season','code'}]}
    get_crop(crop, season)
    crop_rows()          -> [{'crop','season'}]  (for GET /api/crops)

Extra helpers used by crop_engine.py (and handy for other members):
    slot_of(month, day), total_duration_days(row), sow_date_for_year(row, year)

Nothing in this file raises to the caller.
"""
import csv
from datetime import date
from pathlib import Path

DEFAULT_CSV_PATH = Path(__file__).resolve().parent.parent / "data" / "crops.csv"

# Slot lengths in days, from the contract slot dates:
#   kharif Jun 1 - Oct 14 = 30 + 31 + 31 + 30 + 14 = 136
#   rabi   Oct 15 - Mar 15 = 17 + 30 + 31 + 31 + 28 + 15 = 152 (153 in a leap year)
#   zaid   Mar 16 - May 31 = 16 + 30 + 31 = 77
SLOT_DAYS = {"kharif": 136, "rabi": 152, "zaid": 77}

OVERLAP_WARNING_DAYS = 15   # rule S3: longer than slot by more than this -> harvest_overlap warning
OVERLAP_REJECT_DAYS = 30    # rule S3: longer than slot by more than this -> duration_exceeds_slot

STAGE_FIELDS = ["stage_ini_days", "stage_dev_days", "stage_mid_days", "stage_late_days"]
INT_FIELDS = STAGE_FIELDS + ["flowering_start_day", "flowering_end_day"]
FLOAT_FIELDS = [
    "kc_ini", "kc_mid", "kc_end", "ky", "tbase_c", "topt_min_c", "topt_max_c",
    "heat_threshold_flowering_c", "frost_threshold_c", "rain_min_mm", "rain_max_mm",
    "water_demand_mm", "n_credit_kg_ha", "yield_ref_kg_ha", "price_ref_inr_per_kg",
    "cost_ref_inr_per_ha",
]
BOOL_FIELDS = ["waterlogging_sensitive", "nitrogen_fixing", "assumption_flag"]

# A row with None in any of these is excluded with code missing_data.
REQUIRED_NUMERIC = [
    "kc_ini", "kc_mid", "kc_end", "ky", "tbase_c", "topt_min_c", "topt_max_c",
    "heat_threshold_flowering_c", "frost_threshold_c",
    "flowering_start_day", "flowering_end_day", "water_demand_mm",
] + STAGE_FIELDS


# ---------------------------------------------------------------- small helpers
def _clean(value):
    """Return a stripped string ('' for None or non-strings)."""
    return value.strip() if isinstance(value, str) else ""


def _to_number(text):
    """'12.5' -> 12.5; empty or invalid -> None (unknown is None, never 0)."""
    text = _clean(text)
    if text == "":
        return None
    try:
        number = float(text)
    except ValueError:
        return None
    if number != number:  # NaN
        return None
    return number


def _to_bool(text):
    """'True'/'False' (any case) -> bool; anything else -> None."""
    text = _clean(text).lower()
    if text == "true":
        return True
    if text == "false":
        return False
    return None


def _parse_mmdd(text):
    """'11-01' -> (11, 1); invalid -> None."""
    try:
        month_text, day_text = _clean(text).split("-")
        month, day = int(month_text), int(day_text)
        date(2001, month, day)  # raises if the month/day is impossible
        return month, day
    except Exception:
        return None


def slot_of(month, day):
    """Return the slot name containing a calendar day (contract SLOTS)."""
    md = (month, day)
    if (6, 1) <= md <= (10, 14):
        return "kharif"
    if md >= (10, 15) or md <= (3, 15):
        return "rabi"
    return "zaid"


def total_duration_days(row):
    """Sum of the 4 stage lengths, or None if any is missing."""
    try:
        values = [row[f] for f in STAGE_FIELDS]
        if any(v is None for v in values):
            return None
        return sum(values)
    except Exception:
        return None


def sow_date_for_year(crop_params, year):
    """Rule S5: midpoint of the sowing window, as 'YYYY-MM-DD' (None if impossible)."""
    try:
        window = crop_params["sowing_window"]
        start_md = _parse_mmdd(window["start"])
        end_md = _parse_mmdd(window["end"])
        start = date(year, start_md[0], start_md[1])
        end_year = year if end_md >= start_md else year + 1
        end = date(end_year, end_md[0], end_md[1])
        return (start + (end - start) // 2).isoformat()
    except Exception:
        return None


# ---------------------------------------------------------------- row parsing
def _parse_row(raw):
    """Turn one raw CSV dict (all strings) into a crop_params dict."""
    start = _parse_mmdd(raw.get("sowing_start"))
    end = _parse_mmdd(raw.get("sowing_end"))
    window = None
    if start is not None and end is not None:
        window = {"start": "%02d-%02d" % start, "end": "%02d-%02d" % end}

    row = {
        "crop": _clean(raw.get("crop")).lower(),
        "category": _clean(raw.get("category")).lower() or None,
        "family": _clean(raw.get("family")).lower() or None,
        "season": _clean(raw.get("season")).lower(),
        "sowing_window": window,
    }
    for field in INT_FIELDS:
        number = _to_number(raw.get(field))
        row[field] = None if number is None else int(round(number))
    for field in FLOAT_FIELDS:
        row[field] = _to_number(raw.get(field))
    soils = [s.strip().lower() for s in _clean(raw.get("preferred_soil")).split("|")]
    row["preferred_soil"] = [s for s in soils if s]
    for field in BOOL_FIELDS:
        row[field] = _to_bool(raw.get(field))
    row["drought_tolerance"] = _clean(raw.get("drought_tolerance")).lower() or None
    row["source_id"] = _clean(raw.get("source_id")) or None
    # If the flag is missing or unreadable, assume the row is NOT verified.
    if row["assumption_flag"] is None:
        row["assumption_flag"] = True
    return row


def _window_in_slot(row):
    """Rule S1: both ends of the sowing window must sit inside the crop's slot."""
    window = row["sowing_window"]
    for key in ("start", "end"):
        month, day = _parse_mmdd(window[key])
        if slot_of(month, day) != row["season"]:
            return False
    return True


def _check_row(row):
    """Return an exclusion code, or None if the row is valid."""
    if not row["crop"] or row["season"] not in SLOT_DAYS or row["sowing_window"] is None:
        return "missing_data"
    for field in REQUIRED_NUMERIC:
        if row[field] is None:
            return "missing_data"
    total = total_duration_days(row)
    if row["flowering_end_day"] > total or row["flowering_start_day"] > row["flowering_end_day"]:
        return "bad_flowering_window"
    if not _window_in_slot(row):
        return "sowing_outside_slot"
    if total - SLOT_DAYS[row["season"]] > OVERLAP_REJECT_DAYS:
        return "duration_exceeds_slot"
    # Longer by 16-30 days is only a warning (harvest_overlap); crop_engine adds it.
    return None


# ---------------------------------------------------------------- public API
def load_crops_report(path=None):
    """Return {'crops': [valid crop_params], 'excluded': [{'crop','season','code'}]}.

    `path` is optional and only used by tests; normal callers pass nothing.
    """
    report = {"crops": [], "excluded": []}
    try:
        csv_path = Path(path) if path else DEFAULT_CSV_PATH
        with open(csv_path, newline="", encoding="utf-8-sig") as handle:
            raw_rows = list(csv.DictReader(handle))
    except Exception:
        report["excluded"].append({"crop": None, "season": None, "code": "crops_file_unreadable"})
        return report

    seen = set()
    for raw in raw_rows:
        try:
            if not any(_clean(v) for v in raw.values() if isinstance(v, str)):
                continue  # blank line
            row = _parse_row(raw)
            code = _check_row(row)
            if code is None and (row["crop"], row["season"]) in seen:
                code = "duplicate_row"
        except Exception:
            row, code = {"crop": _clean(raw.get("crop")) or None,
                         "season": _clean(raw.get("season")) or None}, "missing_data"
        if code is None:
            seen.add((row["crop"], row["season"]))
            report["crops"].append(row)
        else:
            report["excluded"].append({"crop": row.get("crop") or None,
                                       "season": row.get("season") or None,
                                       "code": code})
    return report


def load_crops():
    """Return the list of valid crop_params dicts."""
    return load_crops_report()["crops"]


def get_crop(crop, season):
    """Return one crop_params dict, or None if not loaded."""
    for row in load_crops():
        if row["crop"] == crop and row["season"] == season:
            return row
    return None


def crop_rows():
    """Return [{'crop','season'}] for the /api/crops endpoint."""
    return [{"crop": r["crop"], "season": r["season"]} for r in load_crops()]
