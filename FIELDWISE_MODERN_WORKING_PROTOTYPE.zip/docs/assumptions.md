# FIELDWISE AI assumptions

| File | Line | Assumption | Code |
|---|---:|---|---|
| engine\crop_engine.py | 33 | rainfed gets none; canal water is less reliable than borewell water | `# ASSUMPTION: rainfed gets none; canal water is less reliable than borewell water` |
| engine\crop_engine.py | 37 | Assumption noted in code | `"rainfed": {"low": 0.00, "medium": 0.00, "high": 0.00},   # ASSUMPTION` |
| engine\crop_engine.py | 38 | Assumption noted in code | `"canal":   {"low": 0.40, "medium": 0.70, "high": 0.90},   # ASSUMPTION` |
| engine\crop_engine.py | 39 | Assumption noted in code | `"borewell": {"low": 0.50, "medium": 0.80, "high": 1.00},  # ASSUMPTION` |
| engine\crop_engine.py | 44 | Assumption noted in code | `SOIL_STORE_MM = {"sandy": 40, "loamy": 90, "silty": 100, "clay": 110}  # ASSUMPTION` |
| engine\crop_engine.py | 46 | Assumption noted in code | `# Weights of the crop score (sum 1.0).  # ASSUMPTION` |
| engine\crop_engine.py | 49 | lose 10 points per degree outside the optimum | `TEMP_FALLOFF_PER_C = 10.0        # ASSUMPTION: lose 10 points per degree outside the optimum` |
| engine\crop_engine.py | 52 | a year counts as a "problem year" if it has at least this many days of | `# ASSUMPTION: a year counts as a "problem year" if it has at least this many days of` |
| engine\crop_engine.py | 57 | median heat days at flowering above this -> reject | `REJECT_HEAT_MEDIAN_DAYS = 5      # ASSUMPTION: median heat days at flowering above this -> reject` |
| engine\crop_engine.py | 58 | mean water satisfaction below this -> reject | `REJECT_WATER_MEAN = 0.5          # ASSUMPTION: mean water satisfaction below this -> reject` |
| engine\crop_engine.py | 59 | median waterlog days above this -> reject | `REJECT_WATERLOG_MEDIAN_DAYS = 3  # ASSUMPTION: median waterlog days above this -> reject` |
| engine\crop_engine.py | 60 | at or above this counts as "mostly met" | `WATER_MOSTLY_MET = 0.8           # ASSUMPTION: at or above this counts as "mostly met"` |
| engine\farm_validation.py | 125 | India is approximated as lat 6..38 and lon 68..98 | `# ASSUMPTION: India is approximated as lat 6..38 and lon 68..98.` |
| engine\nasa_api.py | 28 | NASA grid cell ~0.5 degree, used as cache key | `GRID_DEG = 0.5               # ASSUMPTION: NASA grid cell ~0.5 degree, used as cache key` |
| engine\nasa_api.py | 31 | a dry day has rain below 1 mm | `DRY_DAY_MM = 1.0             # ASSUMPTION: a dry day has rain below 1 mm` |
| engine\nasa_api.py | 32 | a year needs 90% of days with data to be used | `MIN_YEAR_DATA = 0.9          # ASSUMPTION: a year needs 90% of days with data to be used` |
| engine\nasa_api.py | 105 | unknown unit means MJ already | `factor = 3.6 if 'kw' in units else 1.0      # ASSUMPTION: unknown unit means MJ already` |
| engine\nasa_api.py | 289 | mean daily max | `'temp_max_c': _r(mean_ignore_none(daily['tmax_c'])),   # ASSUMPTION: mean daily max` |
| engine\nasa_api.py | 290 | mean daily min | `'temp_min_c': _r(mean_ignore_none(daily['tmin_c'])),   # ASSUMPTION: mean daily min` |
| engine\nasa_api.py | 301 | population std | `if len(totals) >= 2 and mean_rain:                 # ASSUMPTION: population std` |
| engine\replay.py | 5 | from shared contract | `SURVIVE_THRESHOLD = 0.6  # ASSUMPTION from shared contract` |
| engine\scoring.py | 68 | formulas are specified by the shared contract / Member 4 prompt | `# ASSUMPTION formulas are specified by the shared contract / Member 4 prompt.` |
| engine\scoring.py | 138 | simple display reason threshold | `if est_water is not None and est_water <= 15000:  # ASSUMPTION: simple display reason threshold.` |
| engine\season_stats.py | 14 | a day with more than 50 mm rain is a waterlogging day | `WATERLOG_MM = 50      # ASSUMPTION: a day with more than 50 mm rain is a waterlogging day` |
| engine\season_stats.py | 80 | None = not sensitive | `waterlog_on = p.get('waterlogging_sensitive') is True   # ASSUMPTION: None = not sensitive` |

## Values I could not verify

Everything is unverified. The groups below are the ones that are **guesses or proxies**, not even recalled from a table.

**Whole columns that are my estimate for all 14 rows**
- `sowing_start`, `sowing_end` (Indo-Gangetic plain / Terai, # ASSUMPTION; each window was chosen to sit inside one slot)
- `stage_ini_days`, `stage_dev_days`, `stage_mid_days`, `stage_late_days` (FAO stage lengths are for other regions; these are shortened to typical Indian durations)
- `tbase_c`, `topt_min_c`, `topt_max_c`
- `heat_threshold_flowering_c`, `frost_threshold_c` (frost is 0 for all warm-season crops, which means "never triggers")
- `flowering_start_day`, `flowering_end_day`
- `rain_min_mm`, `rain_max_mm` (not used by the scoring code)
- `water_demand_mm`
- `preferred_soil`, `waterlogging_sensitive`, `drought_tolerance`
- `n_credit_kg_ha` (pulses, soybean, groundnut only; others are 0 by assumption)
- `yield_ref_kg_ha`, `cost_ref_inr_per_ha`
- `category`, `family` are botanical/agronomic facts and are low-risk, but still unchecked.

**Kc values (kc_ini, kc_mid, kc_end)**
- Recalled from FAO-56 Table 12: wheat, barley, chickpea, lentil, pea, rice, maize, soybean, groundnut, pearl_millet (millet row).
- Proxy (dry-bean values reused): mungbean, urdbean, cowpea.
- Guessed: mustard `kc_mid = 1.1` (FAO gives a 1.0-1.15 range for rapeseed/canola).

**Ky values**
- Recalled from FAO Paper 33: pea 1.15, rice 1.09, maize 1.25, soybean 0.85, groundnut 0.70, wheat 1.15 (the spring wheat figure; winter wheat is 1.0).
- Guessed (no confirmed FAO 33 value): chickpea 0.85, mustard 0.85, lentil 0.85, barley 1.0, mungbean 1.0, urdbean 1.0, cowpea 1.0, pearl_millet 0.9.

**Prices (price_ref_inr_per_kg), reference estimates**
- Based on remembered MSP figures: wheat 25.85, barley 19.80, chickpea 58.75, lentil 70.00, mustard 62.00 (Rabi Marketing Season 2026-27); rice 23.69, maize 24.00, soybean 53.28, groundnut 72.63, pearl_millet 27.75, mungbean 87.68, urdbean 78.00 (kharif 2025-26).
- Pure guesses: pea 38.00, cowpea 55.00 (no MSP exists).
- Kharif 2026-27 MSPs may already be announced and may differ. Update the year in this file once checked.

## 3. Checklist: what a person must verify first

Do these in order. Time-box to about 3 hours and start with the crops most likely to appear on top (wheat, chickpea, mustard, rice, maize).

- [ ] **Kc** for the top 5 crops against FAO-56 Table 12 (Kc ini / mid / end). Fix mungbean, urdbean, cowpea proxies if a better source exists.
- [ ] **Ky** for the top 5 crops against FAO Irrigation and Drainage Paper 33. Replace every guessed Ky listed above.
- [ ] **Sowing windows** against ICAR or the state agriculture department for Uttar Pradesh / Terai.
- [ ] **Heat thresholds at flowering** and **frost thresholds** against ICAR crop pages.
- [ ] **Stage lengths and total duration** against local variety descriptions.
- [ ] **Prices** against the current MSP notice and update the year.
- [ ] After each check, change `assumption_flag` to `False` **only on rows where every value was verified**, and move the verified value out of section 2.
