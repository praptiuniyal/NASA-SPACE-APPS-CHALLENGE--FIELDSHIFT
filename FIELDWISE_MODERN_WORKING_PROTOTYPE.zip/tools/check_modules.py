"""Import/call smoke checker for every public function in the shared file map."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent; sys.path.insert(0,str(ROOT))
checks=[]
def check(name,fn):
    try: fn(); print('PASS   ',name); checks.append('PASS')
    except (FileNotFoundError,ModuleNotFoundError,ImportError) as e: print('MISSING',name,'-',e); checks.append('MISSING')
    except Exception as e: print('FAIL   ',name,'-',type(e).__name__,e); checks.append('FAIL')
def farm():
    d=json.loads((ROOT/'data/demo_farms.json').read_text()); return d['farms'][0]
def main():
    f=farm()
    from engine.farm_validation import validate_farm; from engine.climate import compute_et0
    from engine.crop_data import load_crops,load_crops_report,crop_rows
    from engine.rotation_engine import generate_rotations; from engine.scoring import reweight,rank_rotations
    from engine.confidence import confidence; from engine.farmer_card import build_farmer_card
    check('validate_farm',lambda:validate_farm(f,crop_rows()))
    check('compute_et0',lambda:compute_et0(30,20,f['latitude'],100))
    check('load_crops',load_crops); check('load_crops_report',load_crops_report)
    check('reweight',lambda:reweight({'climate':80},{'climate':1}))
    check('rank_rotations',lambda:rank_rotations([{'rotation':['a'],'final_score':1,'base_score':1}]))
    check('confidence',lambda:confidence(f,{'data_quality':{'years_available':30,'missing_pct':0}},[],{'defaulted_fields':[],'warnings':[]}))
    check('build_farmer_card',lambda:build_farmer_card(f,[{'rotation':['a','b','c'],'slots':['rabi','zaid','kharif'],'final_score':80,'warnings':[]}],[{'survival_rate':.8}],{'status':'no_plan'},{'fetched_on':'2026-01-01'}))
    # Data-dependent calls are skipped cleanly when cache is absent.
    cache=list((ROOT/'data/cache').glob('history_*.json')) if (ROOT/'data/cache').exists() else []
    if not cache: print('SKIPPED data-dependent NASA/crop/replay/simulator/regret checks (no cached history yet)')
    print(f"FINAL: {checks.count('PASS')} PASS, {checks.count('FAIL')} FAIL, {checks.count('MISSING')} MISSING")
    return 1 if 'FAIL' in checks or 'MISSING' in checks else 0
if __name__=='__main__': raise SystemExit(main())
