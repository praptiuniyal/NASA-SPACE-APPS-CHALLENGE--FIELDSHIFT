"""Member 4: rotation scoring, ranking, reweighting and current-plan comparison."""
from statistics import mean
from engine.crop_data import load_crops

PRIORITY_WEIGHTS = {
    "balanced": {"climate": .20, "water": .20, "soil": .15, "diversity": .10, "compatibility": .10, "resilience": .25},
    "save_water": {"climate": .15, "water": .35, "soil": .10, "diversity": .05, "compatibility": .10, "resilience": .25},
    "improve_soil": {"climate": .15, "water": .15, "soil": .30, "diversity": .15, "compatibility": .10, "resilience": .15},
    "climate_resilience": {"climate": .20, "water": .15, "soil": .10, "diversity": .05, "compatibility": .05, "resilience": .45},
}
SLOT_ORDER = ["kharif", "rabi", "zaid"]

def _error(code, message):
    return {"status": "error", "code": code, "message": message}

def _clamp(x):
    return max(0.0, min(100.0, x))

def reweight(components, weights):
    if not isinstance(components, dict) or not isinstance(weights, dict):
        return None
    total = sum(max(0, weights.get(k, 0) or 0) for k in components)
    if total <= 0:
        return None
    value = sum((components.get(k) or 0) * max(0, weights.get(k, 0) or 0)
                for k in components) / total
    return _clamp(value)

def _slots(start):
    i = SLOT_ORDER.index(start)
    return [SLOT_ORDER[(i+j)%3] for j in range(3)]

def _find_result(crops, crop, slot):
    for r in crops.get("slots", {}).get(slot, []):
        if r.get("crop") == crop and r.get("season") == slot:
            return r
    for r in crops.get("rejected", []):
        if r.get("crop") == crop and r.get("season") == slot:
            return r
    return None

def _params_map():
    rows = load_crops()
    return {(r.get("crop"), r.get("season")): r for r in rows}

def _normalised_weights(priority, include_resilience):
    base = dict(PRIORITY_WEIGHTS.get(priority, PRIORITY_WEIGHTS["balanced"]))
    if not include_resilience:
        base["resilience"] = 0
    total = sum(base.values())
    return {k: (v/total if total else 0) for k,v in base.items()}

def score_rotation(rotation, farm, climate, priority, resilience=None, crops=None):
    try:
        if crops is None:
            return _error("crops_required", "Crop recommendations are required.")
        if not isinstance(rotation, list) or len(rotation) != 3:
            return _error("wrong_length", "Rotation must contain exactly 3 crops.")
        slots = _slots(farm["start_season"])
        results = [_find_result(crops, crop, slot) for crop, slot in zip(rotation, slots)]
        if any(r is None for r in results):
            return _error("unknown_crop", "A crop result is missing for its slot.")
        params = _params_map()
        rows = [params.get((crop, slot)) for crop, slot in zip(rotation, slots)]
        if any(r is None for r in rows):
            return _error("unknown_crop", "Crop parameters are missing.")

        # ASSUMPTION formulas are specified by the shared contract / Member 4 prompt.
        climate_component = min(mean([r["sub_scores"]["temperature"],
                                      r["sub_scores"]["season"],
                                      r["sub_scores"]["stress"]]) for r in results)
        water_component = min(r["sub_scores"]["water"] for r in results)
        soil_component = mean(r["sub_scores"]["soil"] for r in results)
        legume = any(bool(p.get("nitrogen_fixing")) for p in rows)
        if legume:
            soil_component = min(100, soil_component + 10)
        families = [p.get("family") for p in rows]
        diversity = (len(set(families))/3)*70 + (30 if legume else 0)
        diversity = _clamp(diversity)
        compatibility = 100
        same_pair = False
        for a,b in zip(families, families[1:]):
            if a == b:
                compatibility -= 40
                same_pair = True
        previous_same = False
        previous = (farm.get("previous_crops") or [None])[-1]
        if previous:
            prev_rows = [p for p in load_crops() if p.get("crop") == previous]
            if prev_rows and prev_rows[0].get("family") == families[0]:
                compatibility -= 40
                previous_same = True
        compatibility = _clamp(compatibility)

        components = {"climate": _clamp(climate_component), "water": _clamp(water_component),
                      "soil": _clamp(soil_component), "diversity": diversity,
                      "compatibility": compatibility, "resilience": resilience}
        pass1_components = dict(components)
        pass1_components["resilience"] = 0
        w1 = _normalised_weights(priority, False)
        base_score = reweight(pass1_components, w1)
        if resilience is None:
            final_score = base_score
            weights_used = w1
        else:
            w2 = _normalised_weights(priority, True)
            final_score = reweight(components, w2)
            weights_used = w2

        income = 0.0
        water = 0.0
        economics_ok = True
        water_ok = True
        for p in rows:
            vals = [p.get("yield_ref_kg_ha"), p.get("price_ref_inr_per_kg"), p.get("cost_ref_inr_per_ha")]
            if any(v is None for v in vals):
                economics_ok = False
            else:
                income += vals[0]*vals[1]-vals[2]
            if p.get("water_demand_mm") is None:
                water_ok = False
            else:
                water += p["water_demand_mm"]*10
        est_income = income if economics_ok else None
        est_water = water if water_ok else None
        crop_per_drop = (est_income/est_water if est_income is not None and est_water not in (None,0) else None)

        reasons = []
        warnings = []
        if legume:
            reasons.append({"code":"includes_legume","params":{"crop": next(rotation[i] for i,p in enumerate(rows) if p.get("nitrogen_fixing"))}})
        if not same_pair:
            reasons.append({"code":"no_repeated_family","params":{}})
        else:
            warnings.append({"code":"same_family_consecutive","params":{}})
        if previous_same:
            warnings.append({"code":"repeats_previous_family","params":{}})
        if est_water is not None and est_water <= 15000:  # ASSUMPTION: simple display reason threshold.
            reasons.append({"code":"low_water_demand","params":{}})
        if not reasons:
            reasons.append({"code":"rotation_scored","params":{}})

        return {"rank": None, "rotation": list(rotation), "slots": slots,
                "base_score": round(base_score,2) if base_score is not None else None,
                "final_score": round(final_score,2) if final_score is not None else None,
                "components": {k:(round(v,2) if isinstance(v,(int,float)) else v) for k,v in components.items()},
                "weights_used": weights_used,
                "est_income_inr_per_ha": round(est_income,2) if est_income is not None else None,
                "est_water_m3_per_ha": round(est_water,2) if est_water is not None else None,
                "crop_per_drop": round(crop_per_drop,4) if crop_per_drop is not None else None,
                "reasons": reasons, "warnings": warnings}
    except Exception as e:
        return _error("internal_error", f"score_rotation failed: {type(e).__name__}: {e}")

def rank_rotations(scored_list):
    valid = [x for x in scored_list if isinstance(x,dict) and "rotation" in x]
    valid.sort(key=lambda x: x.get("final_score") if x.get("final_score") is not None
               else (x.get("base_score") if x.get("base_score") is not None else -1), reverse=True)
    out=[]
    for i,x in enumerate(valid[:3],1):
        y=dict(x); y["rank"]=i; out.append(y)
    return out

def compare_current(farm, climate, history, recommended=None, recommended_replay=None, crops=None):
    empty = {"status":"no_plan","current_plan":None,"score":None,"survival_rate":None,
             "est_water_m3_per_ha":None,"est_income_inr_per_ha":None,
             "difference":{"score":None,"water_m3_per_ha":None,"income_inr_per_ha":None,"survival_rate":None}}
    if not farm.get("current_plan"):
        return empty
    try:
        from engine.replay import replay_history, calculate_resilience
        plan = farm["current_plan"]
        pass1 = score_rotation(plan, farm, climate, farm.get("priority","balanced"), None, crops)
        if pass1.get("status") == "error":
            return _error(pass1["code"], pass1["message"])
        replay = replay_history(plan, farm, history)
        resilience = calculate_resilience(replay, [])
        current = score_rotation(plan, farm, climate, farm.get("priority","balanced"), resilience, crops)
        if current.get("status") == "error":
            return _error(current["code"], current["message"])
        rec = recommended or {}
        rr = recommended_replay or {}
        def diff(a,b):
            return None if a is None or b is None else a-b
        return {"status":"success","current_plan":list(plan),"score":current.get("final_score"),
                "survival_rate":replay.get("survival_rate"),
                "est_water_m3_per_ha":current.get("est_water_m3_per_ha"),
                "est_income_inr_per_ha":current.get("est_income_inr_per_ha"),
                "difference":{"score":diff(rec.get("final_score"),current.get("final_score")),
                              "water_m3_per_ha":diff(rec.get("est_water_m3_per_ha"),current.get("est_water_m3_per_ha")),
                              "income_inr_per_ha":diff(rec.get("est_income_inr_per_ha"),current.get("est_income_inr_per_ha")),
                              "survival_rate":diff(rr.get("survival_rate"),replay.get("survival_rate"))}}
    except Exception as e:
        return _error("internal_error", f"compare_current failed: {type(e).__name__}: {e}")
