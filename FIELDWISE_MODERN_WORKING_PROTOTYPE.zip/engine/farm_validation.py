"""Validation helpers for FIELDWISE AI farm input."""

ALLOWED_SOIL_TYPES = {"sandy", "loamy", "clay", "silty"}
ALLOWED_IRRIGATION = {"rainfed", "canal", "borewell"}
ALLOWED_WATER = {"low", "medium", "high"}
ALLOWED_SEASONS = {"kharif", "rabi", "zaid"}
ALLOWED_PRIORITIES = {
    "save_water", "improve_soil", "climate_resilience", "balanced"
}
ALLOWED_LANGUAGES = {"en", "hi"}
SEASON_ORDER = ["kharif", "rabi", "zaid"]

# Optional farmer fields and their defaults.
DEFAULTS = {
    "water_availability": "low",
    "start_season": "kharif",
    "previous_crops": [],
    "current_plan": [],
    "priority": "balanced",
    "language": "en",
}


def _is_empty(value):
    """Return True only for values treated as farmer-left-empty."""
    return value is None or value == ""


def _add_error(errors, field, code):
    errors.append({"field": field, "code": code})


def _rotation_slots(start_season):
    """Return the three consecutive slots beginning at start_season."""
    if start_season not in ALLOWED_SEASONS:
        return None
    start = SEASON_ORDER.index(start_season)
    return [SEASON_ORDER[(start + i) % 3] for i in range(3)]


def validate_farm(farm, crop_rows=None):
    """Validate and clean a FIELDWISE AI farm dictionary. Never raises."""
    try:
        errors = []
        warnings = []
        defaulted_fields = []

        if not isinstance(farm, dict):
            return {
                "status": "error",
                "farm": {},
                "errors": [{"field": "farm", "code": "invalid_choice"}],
                "warnings": [],
                "defaulted_fields": [],
            }

        # Copy only contract farm keys so no extra keys leak into cleaned_farm.
        farm_keys = [
            "name", "latitude", "longitude", "area_ha", "soil_type",
            "irrigation", "water_availability", "start_season",
            "previous_crops", "current_plan", "priority", "language",
        ]
        cleaned = {key: farm.get(key) for key in farm_keys}

        # Fill optional fields only when missing/None/empty string.
        for field, default in DEFAULTS.items():
            if field not in farm or _is_empty(farm.get(field)):
                cleaned[field] = default.copy() if isinstance(default, list) else default
                defaulted_fields.append(field)

        # Numeric checks. bool is deliberately not accepted as a number.
        latitude = cleaned.get("latitude")
        if not isinstance(latitude, (int, float)) or isinstance(latitude, bool):
            _add_error(errors, "latitude", "out_of_range")
        elif not -90 <= latitude <= 90:
            _add_error(errors, "latitude", "out_of_range")

        longitude = cleaned.get("longitude")
        if not isinstance(longitude, (int, float)) or isinstance(longitude, bool):
            _add_error(errors, "longitude", "out_of_range")
        elif not -180 <= longitude <= 180:
            _add_error(errors, "longitude", "out_of_range")

        area = cleaned.get("area_ha")
        if not isinstance(area, (int, float)) or isinstance(area, bool) or area <= 0:
            _add_error(errors, "area_ha", "must_be_positive")

        enum_checks = {
            "soil_type": ALLOWED_SOIL_TYPES,
            "irrigation": ALLOWED_IRRIGATION,
            "water_availability": ALLOWED_WATER,
            "start_season": ALLOWED_SEASONS,
            "priority": ALLOWED_PRIORITIES,
            "language": ALLOWED_LANGUAGES,
        }
        for field, allowed in enum_checks.items():
            if cleaned.get(field) not in allowed:
                _add_error(errors, field, "invalid_choice")

        previous = cleaned.get("previous_crops")
        if not isinstance(previous, list) or len(previous) != 2:
            _add_error(errors, "previous_crops", "wrong_length")
        else:
            for crop in previous:
                if not isinstance(crop, str) or not crop or crop != crop.lower():
                    _add_error(errors, "previous_crops", "invalid_choice")
                    break

        current_plan = cleaned.get("current_plan")
        if not isinstance(current_plan, list) or len(current_plan) not in (0, 3):
            _add_error(errors, "current_plan", "wrong_length")
        elif len(current_plan) == 3:
            for crop in current_plan:
                if not isinstance(crop, str) or not crop or crop != crop.lower():
                    _add_error(errors, "current_plan", "invalid_choice")
                    break

        # Rainfed farms always use low water availability.
        if cleaned.get("irrigation") == "rainfed":
            if cleaned.get("water_availability") != "low":
                cleaned["water_availability"] = "low"
            warnings.append({"code": "rainfed_forces_low", "params": {}})

        # India bounding box is an explicit contract assumption.
        # ASSUMPTION: India is approximated as lat 6..38 and lon 68..98.
        if (
            isinstance(latitude, (int, float)) and not isinstance(latitude, bool)
            and isinstance(longitude, (int, float)) and not isinstance(longitude, bool)
            and -90 <= latitude <= 90 and -180 <= longitude <= 180
            and not (6 <= latitude <= 38 and 68 <= longitude <= 98)
        ):
            warnings.append({"code": "outside_india", "params": {}})

        if crop_rows is not None:
            valid_rows = []
            if isinstance(crop_rows, list):
                valid_rows = [
                    row for row in crop_rows
                    if isinstance(row, dict)
                    and isinstance(row.get("crop"), str)
                    and row.get("season") in ALLOWED_SEASONS
                ]

            known_crops = {row["crop"] for row in valid_rows}

            # Every crop name supplied by the farmer must exist in crop_rows.
            if isinstance(previous, list):
                for index, crop in enumerate(previous):
                    if isinstance(crop, str) and crop not in known_crops:
                        _add_error(errors, f"previous_crops[{index}]", "unknown_crop")

            if isinstance(current_plan, list):
                for index, crop in enumerate(current_plan):
                    if isinstance(crop, str) and crop not in known_crops:
                        _add_error(errors, f"current_plan[{index}]", "unknown_crop")

                slots = _rotation_slots(cleaned.get("start_season"))
                if len(current_plan) == 3 and slots is not None:
                    valid_pairs = {(row["crop"], row["season"]) for row in valid_rows}
                    for index, (crop, slot) in enumerate(zip(current_plan, slots)):
                        if crop in known_crops and (crop, slot) not in valid_pairs:
                            _add_error(errors, f"current_plan[{index}]", "crop_wrong_slot")

        return {
            "status": "error" if errors else "success",
            "farm": cleaned,
            "errors": errors,
            "warnings": warnings,
            "defaulted_fields": defaulted_fields,
        }
    except Exception:
        # Contract rule: validation must never raise to the caller.
        return {
            "status": "error",
            "farm": farm.copy() if isinstance(farm, dict) else {},
            "errors": [{"field": "farm", "code": "invalid_choice"}],
            "warnings": [],
            "defaulted_fields": [],
        }
