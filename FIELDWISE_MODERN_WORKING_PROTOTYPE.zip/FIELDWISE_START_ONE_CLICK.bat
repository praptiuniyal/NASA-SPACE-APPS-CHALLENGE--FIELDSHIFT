@echo off
setlocal
cd /d "%~dp0"
title FIELDWISE AI - Local Server

echo =============================================
echo            FIELDWISE AI LAUNCHER
echo =============================================
echo Project folder: %CD%
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python was not found on PATH.
  echo Install Python 3.10+ and enable Add Python to PATH.
  pause
  exit /b 1
)

if not exist "app.py" (
  echo ERROR: app.py was not found in this folder.
  echo Place RUN_FIELDWISE.bat beside app.py.
  pause
  exit /b 1
)

if not exist "requirements.txt" (
  echo ERROR: requirements.txt was not found.
  pause
  exit /b 1
)

echo Checking Python packages...
python -c "import flask, requests, pandas" >nul 2>&1
if errorlevel 1 (
  echo Installing required packages (internet may be needed)...
  python -m pip install -r requirements.txt
  if errorlevel 1 (
    echo ERROR: Dependency installation failed.
    pause
    exit /b 1
  )
)

echo.
echo Starting FIELDWISE at http://127.0.0.1:5000/
echo Keep this window open while using the website.
echo Press Ctrl+C to stop the server.
echo.
start "" /min cmd /c "timeout /t 4 /nobreak >nul & start "" http://127.0.0.1:5000/"
python app.py

echo.
echo FIELDWISE server has stopped.
pause
endlocal
