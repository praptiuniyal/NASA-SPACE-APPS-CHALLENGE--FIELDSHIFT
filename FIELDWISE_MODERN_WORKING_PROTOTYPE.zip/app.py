"""FIELDWISE AI integrated Flask server (Team Leader)."""
import copy, json, time
from pathlib import Path
from flask import Flask, jsonify, render_template, request

from engine.farm_validation import validate_farm
from engine.crop_data import crop_rows, load_crops
from engine.nasa_api import get_history, get_nasa_data, NASA_VARS
from engine.crop_engine import recommend_crops
from engine.rotation_engine import generate_rotations
from engine.scoring import score_rotation, rank_rotations, compare_current
from engine.replay import replay_history, calculate_resilience
from engine.simulator import simulate
from engine.regret import compare_rotations, backtest
from engine.confidence import confidence
from engine.farmer_card import build_farmer_card
from engine.gpm_api import get_gpm_context, evidence_consistency

ROOT = Path(__file__).resolve().parent
MOCK = ROOT / "docs" / "mock"
USE_MOCK = True  # Set False for final real-data demo after prefetch_demo.py succeeds.
app = Flask(__name__)
_HISTORY_CACHE = {}

FALLBACK_ROWS = ([{'crop':c,'season':'rabi'} for c in ['wheat','chickpea','mustard','lentil','barley','pea']] +
                 [{'crop':c,'season':'zaid'} for c in ['mungbean','urdbean','cowpea']] +
                 [{'crop':c,'season':'kharif'} for c in ['rice','maize','soybean','groundnut','pearl_millet']])

def _error(code, message): return {'status':'error','version':2,'code':code,'message':message}
def _load_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def _rows():
    try: return crop_rows()
    except Exception: return FALLBACK_ROWS

def _history(lat, lon):
    key=(round(float(lat)*2)/2, round(float(lon)*2)/2)
    if key not in _HISTORY_CACHE:
        _HISTORY_CACHE[key]=get_history(lat,lon)
    return _HISTORY_CACHE[key]

def run_analysis(farm):
    """Run the real v2 analysis pipeline and return (payload, HTTP status)."""
    try:
        t0=time.perf_counter(); validation=validate_farm(farm,_rows())
        if validation.get('status')!='success': return _error('invalid_farm','Farm validation failed.') | {'errors':validation.get('errors',[])},400
        farm=validation['farm']
        tf=time.perf_counter(); history=_history(farm['latitude'],farm['longitude']); climate=get_nasa_data(farm['latitude'],farm['longitude']); fetch_ms=(time.perf_counter()-tf)*1000
        if history.get('status')!='success': return _error(history.get('code','nasa_unavailable'),history.get('message','NASA history unavailable')),502
        if climate.get('status')!='success': return _error(climate.get('code','nasa_unavailable'),climate.get('message','NASA climate unavailable')),502
        tc=time.perf_counter(); crops=recommend_crops(farm,climate,history); crops_ms=(time.perf_counter()-tc)*1000
        if crops.get('status')!='success': return _error(crops.get('code','crop_error'),crops.get('message','Crop scoring failed')),500
        tr=time.perf_counter(); candidates=generate_rotations(farm,climate,crops)
        if isinstance(candidates,dict) and candidates.get('status')=='error': return _error(candidates['code'],candidates['message']),400
        scored=[score_rotation(r,farm,climate,farm['priority'],None,crops) for r in candidates]
        scored=[x for x in scored if isinstance(x,dict) and 'rotation' in x]
        scored.sort(key=lambda x:x.get('base_score') if x.get('base_score') is not None else -1,reverse=True)
        top5=scored[:5]; rotations_ms=(time.perf_counter()-tr)*1000
        if len(top5)<2: return _error('no_candidates','Fewer than two scoreable rotations were available.'),400
        tp=time.perf_counter(); replay5=[]; scenario5=[]; final=[]
        for r in top5:
            rep=replay_history(r['rotation'],farm,history); replay5.append(rep)
            scenarios=[simulate(r['rotation'],farm,climate,history,{'name':'drought'}), simulate(r['rotation'],farm,climate,history,{'name':'heat_stress'})]
            scenario5.append(scenarios)
            resilience=calculate_resilience(rep,scenarios)
            final.append(score_rotation(r['rotation'],farm,climate,farm['priority'],resilience,crops))
        top3=rank_rotations(final)
        replay_by_rotation={tuple(r['rotation']):rep for r,rep in zip(top5,replay5)}
        replays=[replay_by_rotation.get(tuple(r['rotation'])) or replay_history(r['rotation'],farm,history) for r in top3]
        replay_ms=(time.perf_counter()-tp)*1000
        comparison=compare_current(farm,climate,history,top3[0],replays[0],crops)
        regret=compare_rotations(top3[0],top3[1],farm,climate,history)
        backtest_result=backtest(top3[0]['rotation'],farm,history)
        confidence_result=confidence(farm,climate,top3,validation)
        nasa_used={'variables':list(NASA_VARS),'days':len(history['daily']['date']),'years':len(history['years']),'fetched_on':history['fetched_on'],'from_cache':history['data_quality']['from_cache']}
        farmer_card=build_farmer_card(farm,top3,replays,comparison,nasa_used)
        gpm=get_gpm_context(farm['latitude'],farm['longitude'],30)
        earth_state={'gpm':gpm,'evidence_consistency':evidence_consistency(gpm,climate)}
        warnings=list(validation.get('warnings',[]))
        if history.get('data_quality',{}).get('missing_pct',0)>10: warnings.append({'code':'high_missing_data','params':{}})
        assumptions=[]
        for row in load_crops():
            if row.get('assumption_flag'): assumptions.append(f"{row.get('crop')}:{row.get('season')}")
        labels={'nasa':['temperature','rainfall','solar','humidity','wind','soil wetness'],
                'farmer':list(farm.keys()),'reference_estimate':['income','water use','price','cost'],'assumption':assumptions}
        payload={'status':'success','version':2,'farm':farm,'warnings':warnings,'climate':climate,'top_crops':crops,
                 'rotations':top3,'replays':replays,'regret':regret,'backtest':backtest_result,'comparison':comparison,
                 'confidence':confidence_result,'farmer_card':farmer_card,'nasa_used':nasa_used,'earth_state':earth_state,'labels':labels,
                 'timings_ms':{'fetch':round(fetch_ms,2),'crops':round(crops_ms,2),'rotations':round(rotations_ms,2),'replay':round(replay_ms,2)}}
        return payload,200
    except Exception as exc:
        return _error('internal_error',f'run_analysis failed: {type(exc).__name__}: {exc}'),500

@app.get('/')
def home(): return render_template('index.html')
@app.get('/farm')
def farm_page(): return render_template('farm.html')
@app.get('/dashboard')
def dashboard(): return render_template('dashboard.html')
@app.get('/methods')
def methods(): return render_template('methods.html')
@app.get('/api/health')
def health(): return jsonify({'status':'success','version':2})
@app.get('/api/crops')
def api_crops(): return jsonify({'status':'success','version':2,'slots':['kharif','rabi','zaid'],'rows':_rows()})
@app.get('/api/demo-farms')
def api_demo_farms():
    try:
        p=ROOT/'data'/'demo_farms.json'; data=_load_json(p) if p.exists() else {'farms':[]}
        farms=data.get('farms',data if isinstance(data,list) else [])
        return jsonify({'status':'success','version':2,'farms':farms})
    except Exception as e: return jsonify(_error('internal_error',str(e))),500
@app.get('/api/mock')
def api_mock(): return jsonify(_load_json(MOCK/'analyze_response.json'))
@app.get('/api/gpm-context')
def api_gpm_context():
    try:
        lat=float(request.args.get('lat')); lon=float(request.args.get('lon'))
    except (TypeError,ValueError):
        return jsonify(_error('gpm_invalid_location','lat and lon query parameters are required.')),400
    result=get_gpm_context(lat,lon,30)
    return jsonify({'version':2,**result}),(200 if result.get('status')=='success' else 503)
@app.post('/api/validate-farm')
def api_validate():
    result=validate_farm(request.get_json(silent=True) or {},_rows()); result['version']=2; return jsonify(result), (200 if result.get('status')=='success' else 400)
@app.post('/api/analyze')
def api_analyze():
    farm=request.get_json(silent=True) or {}; validation=validate_farm(farm,_rows())
    if validation.get('status')!='success': validation['version']=2; return jsonify(validation),400
    if USE_MOCK:
        data=_load_json(MOCK/'analyze_response.json'); data['farm']=validation['farm']; data['warnings']=validation.get('warnings',[]); return jsonify(data)
    payload,status=run_analysis(validation['farm']); return jsonify(payload),status
@app.post('/api/simulate')
def api_simulate():
    body=request.get_json(silent=True) or {}; farm=body.get('farm'); rotation=body.get('rotation'); scenario=body.get('scenario')
    if not isinstance(farm,dict) or not isinstance(rotation,list) or len(rotation)!=3 or not isinstance(scenario,dict): return jsonify(_error('invalid_request','Body must contain farm, 3-crop rotation and scenario.')),400
    if USE_MOCK: return jsonify(_load_json(MOCK/'simulation_result.json'))
    v=validate_farm(farm,_rows())
    if v.get('status')!='success': return jsonify(_error('invalid_farm','Farm validation failed.')),400
    farm=v['farm']; history=_history(farm['latitude'],farm['longitude']); climate=get_nasa_data(farm['latitude'],farm['longitude'])
    if history.get('status')!='success' or climate.get('status')!='success': return jsonify(_error('nasa_unavailable','NASA data unavailable.')),502
    result=simulate(rotation,farm,climate,history,scenario); return jsonify(result),(200 if result.get('status')!='error' else 400)

if __name__=='__main__': app.run(debug=True)
