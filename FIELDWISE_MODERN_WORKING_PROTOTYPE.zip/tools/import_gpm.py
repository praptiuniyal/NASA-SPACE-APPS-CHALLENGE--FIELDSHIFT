"""Import a real NASA GPM IMERG point CSV exported from Giovanni/GES DISC."""
import argparse, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from engine.gpm_api import import_imerg_csv

p=argparse.ArgumentParser(description="Import NASA IMERG daily point CSV into FIELDWISE cache")
p.add_argument("csv")
p.add_argument("latitude",type=float)
p.add_argument("longitude",type=float)
a=p.parse_args()
print(json.dumps(import_imerg_csv(a.csv,a.latitude,a.longitude),indent=2))
