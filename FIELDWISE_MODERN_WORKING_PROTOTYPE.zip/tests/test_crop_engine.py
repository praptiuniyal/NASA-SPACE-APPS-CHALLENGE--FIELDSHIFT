"""Tests for engine/crop_engine.py  (run: python -m pytest tests/test_crop_engine.py)

FAKE_FOR_TESTS: all weather/season numbers below are made up for testing only.
They are never used by the real code.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import pytest  # noqa: E402

from engine import crop_engine  # noqa: E402
from engine.crop_data import get_crop  # noqa: E402

FAKE_FOR_TESTS_YEARS = [2001, 2002, 2003, 2004, 2005]
FAKE_FOR_TESTS_HISTORY = {"status": "success", "years": FAKE_FOR_TESTS_YEARS, "daily": {"date": ["2001-01-01"]}}


def _climate(temp=20.0):
    return {"status": "success", "seasons": {s: {"temp_mean_c": temp} for s in ("kharif", "rabi", "zaid")}}


def _farm(soil="loamy", irrigation="borewell", availability="medium"):
    return {"soil_type": soil, "irrigation": irrigation, "water_availability": availability}


def _fake_stats(etc=300.0, rain=100.0, heat=0, frost=0, waterlog=0, completed=True):
    """Build a replacement for crop_season_stats that returns FAKE_FOR_TESTS numbers."""
    def fake(daily, crop_params, sow_date):
        return {"status": "success", "crop": crop_params["crop"], "season": crop_params["season"],
                "sow_date": sow_date, "harvest_date": "2999-01-01", "etc_mm": etc,
                "effective_rain_mm": rain, "gdd": 1000.0, "heat_days_flowering": heat,
                "frost_days": frost, "waterlog_days": waterlog, "season_completed": completed}
    return fake


# ---------------------------------------------------------------- water_satisfaction
def test_water_satisfaction_rainfed_uses_only_rain_and_soil_store():
    stats = {"etc_mm": 400.0, "effective_rain_mm": 100.0}
    # (100 + 0 + 90) / 400 = 0.475
    assert crop_engine.water_satisfaction(stats, _farm("loamy", "rainfed", "low")) == pytest.approx(0.475)


def test_water_satisfaction_is_capped_at_one():
    stats = {"etc_mm": 300.0, "effective_rain_mm": 300.0}
    assert crop_engine.water_satisfaction(stats, _farm("clay", "borewell", "high")) == 1.0


def test_water_satisfaction_canal_medium_sandy():
    stats = {"etc_mm": 400.0, "effective_rain_mm": 40.0}
    # (40 + 0.70*400 + 40) / 400 = 0.9
    assert crop_engine.water_satisfaction(stats, _farm("sandy", "canal", "medium")) == pytest.approx(0.9)


def test_water_satisfaction_unknown_when_etc_is_none_or_zero():
    farm = _farm()
    assert crop_engine.water_satisfaction({"etc_mm": None, "effective_rain_mm": 50.0}, farm) is None
    assert crop_engine.water_satisfaction({"etc_mm": 0, "effective_rain_mm": 50.0}, farm) is None
    assert crop_engine.water_satisfaction({"etc_mm": 300.0, "effective_rain_mm": None}, farm) is None


# ---------------------------------------------------------------- suitability
def test_very_dry_rainfed_rice_in_zaid_is_rejected_for_water_deficit(monkeypatch):
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(etc=500.0, rain=5.0))
    rice = dict(get_crop("rice", "kharif"), season="zaid")  # FAKE_FOR_TESTS: rice forced into zaid
    result = crop_engine.calculate_crop_suitability(
        rice, _farm("sandy", "rainfed", "low"), _climate(), FAKE_FOR_TESTS_HISTORY)
    assert result["rejected"] is True
    assert result["reject_reason"]["code"] == "water_deficit"
    assert result["sub_scores"]["water"] is not None  # rejected crops still get sub-scores


def test_loamy_borewell_farm_scores_higher_than_sandy_rainfed(monkeypatch):
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(etc=300.0, rain=100.0))
    wheat = get_crop("wheat", "rabi")
    good = crop_engine.calculate_crop_suitability(
        wheat, _farm("loamy", "borewell", "medium"), _climate(), FAKE_FOR_TESTS_HISTORY)
    poor = crop_engine.calculate_crop_suitability(
        wheat, _farm("sandy", "rainfed", "low"), _climate(), FAKE_FOR_TESTS_HISTORY)
    assert good["score"] > poor["score"]


def test_heat_at_flowering_rejects_with_days_param(monkeypatch):
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(heat=8))
    result = crop_engine.calculate_crop_suitability(
        get_crop("wheat", "rabi"), _farm(), _climate(), FAKE_FOR_TESTS_HISTORY)
    assert result["rejected"] is True
    assert result["reject_reason"] == {"code": "heat_flowering", "params": {"days": 8}}


def test_waterlogging_rejects_only_sensitive_crops(monkeypatch):
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(waterlog=6))
    sensitive = crop_engine.calculate_crop_suitability(
        get_crop("chickpea", "rabi"), _farm(), _climate(), FAKE_FOR_TESTS_HISTORY)
    tolerant = crop_engine.calculate_crop_suitability(
        get_crop("wheat", "rabi"), _farm(), _climate(), FAKE_FOR_TESTS_HISTORY)
    assert sensitive["reject_reason"]["code"] == "waterlogging"
    assert tolerant["rejected"] is False


def test_incomplete_seasons_are_skipped_and_score_stays_unknown(monkeypatch):
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(completed=False))
    result = crop_engine.calculate_crop_suitability(
        get_crop("wheat", "rabi"), _farm(), _climate(), FAKE_FOR_TESTS_HISTORY)
    assert result["score"] is None
    assert result["reject_reason"]["code"] == "no_complete_seasons"


def test_messages_are_objects_not_sentences(monkeypatch):
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(etc=300.0, rain=250.0))
    result = crop_engine.calculate_crop_suitability(
        get_crop("wheat", "rabi"), _farm("loamy"), _climate(20.0), FAKE_FOR_TESTS_HISTORY)
    codes = [m["code"] for m in result["reasons"]]
    assert "temperature_in_range" in codes and "soil_matches" in codes and "water_mostly_met" in codes
    assert all(set(m) == {"code", "params"} for m in result["reasons"] + result["warnings"])
    assert 0 <= result["score"] <= 100


def test_stress_sub_score_counts_problem_years(monkeypatch):
    # 1 heat day is not a problem year; 4 heat days is (but still under the reject limit of 5)
    wheat = get_crop("wheat", "rabi")
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(heat=1))
    calm = crop_engine.calculate_crop_suitability(wheat, _farm(), _climate(), FAKE_FOR_TESTS_HISTORY)
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(heat=4))
    hot = crop_engine.calculate_crop_suitability(wheat, _farm(), _climate(), FAKE_FOR_TESTS_HISTORY)
    assert calm["sub_scores"]["stress"] == 100.0
    assert hot["sub_scores"]["stress"] == 0.0 and hot["rejected"] is False


# ---------------------------------------------------------------- recommend_crops
def test_recommend_crops_lists_are_sorted_best_first_and_complete(monkeypatch):
    monkeypatch.setattr(crop_engine, "crop_season_stats", _fake_stats(etc=300.0, rain=120.0))
    result = crop_engine.recommend_crops(_farm("loamy"), _climate(22.0), FAKE_FOR_TESTS_HISTORY)
    assert result["status"] == "success"
    total = sum(len(v) for v in result["slots"].values()) + len(result["rejected"])
    assert total == 14
    for slot, items in result["slots"].items():
        scores = [i["score"] for i in items]
        assert scores == sorted(scores, reverse=True)
        assert all(i["season"] == slot for i in items)


def test_recommend_crops_caches_season_stats_per_crop_season_year(monkeypatch):
    calls = []
    base = _fake_stats()

    def counting(daily, crop_params, sow_date):
        calls.append((crop_params["crop"], crop_params["season"], sow_date))
        return base(daily, crop_params, sow_date)

    monkeypatch.setattr(crop_engine, "crop_season_stats", counting)
    crop_engine.recommend_crops(_farm(), _climate(), FAKE_FOR_TESTS_HISTORY)
    assert len(calls) == len(set(calls)) == 14 * len(FAKE_FOR_TESTS_YEARS)


def test_recommend_crops_returns_error_dict_when_history_failed():
    result = crop_engine.recommend_crops(_farm(), _climate(), {"status": "error", "code": "nasa_down"})
    assert result["status"] == "error" and result["code"] == "history_unavailable"
