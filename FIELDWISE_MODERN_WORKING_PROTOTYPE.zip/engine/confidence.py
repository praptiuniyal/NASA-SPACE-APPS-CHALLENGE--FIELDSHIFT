"""Confidence score for FIELDWISE AI (Member 5)."""

def _load_crops():
    from engine.crop_data import load_crops
    return load_crops()

def confidence(farm, climate, rotations, validation_result):
    try:
        points=100; reasons=[]; dq=climate.get('data_quality',{})
        years=dq.get('years_available'); missing=dq.get('missing_pct')
        if years is not None and years < 20: points-=25; reasons.append({'code':'conf_low_years','params':{'years':years}})
        if missing is not None and missing > 10: points-=15; reasons.append({'code':'conf_high_missing','params':{'pct':missing}})
        n=min(4,len(validation_result.get('defaulted_fields',[])))
        if n: points-=5*n; reasons.append({'code':'conf_defaulted_fields','params':{'count':n}})
        if len(rotations)>=2 and rotations[0].get('final_score') is not None and rotations[1].get('final_score') is not None and abs(rotations[0]['final_score']-rotations[1]['final_score'])<3:
            points-=15; reasons.append({'code':'conf_close_scores','params':{}})
        if any(w.get('code')=='outside_india' for w in validation_result.get('warnings',[]) if isinstance(w,dict)):
            points-=10; reasons.append({'code':'conf_outside_india','params':{}})
        if rotations:
            names=rotations[0].get('rotation',[]); rows=_load_crops(); selected=[]
            slots=rotations[0].get('slots',[])
            for i,nm in enumerate(names):
                candidates=[r for r in rows if r.get('crop')==nm and (not slots or r.get('season')==slots[i])]
                if candidates:selected.append(candidates[0])
            if selected and sum(bool(r.get('assumption_flag')) for r in selected)/len(selected)>0.2:
                points-=10; reasons.append({'code':'conf_many_assumptions','params':{}})
        points=max(0,min(100,points))
        if not reasons: reasons=[{'code':'conf_strong_data','params':{}}]
        level='High' if points>=75 else ('Medium' if points>=50 else 'Low')
        return {'level':level,'points':points,'reasons':reasons}
    except Exception as e:
        return {'level':'Low','points':0,'reasons':[{'code':'conf_error','params':{'type':type(e).__name__}}]}
