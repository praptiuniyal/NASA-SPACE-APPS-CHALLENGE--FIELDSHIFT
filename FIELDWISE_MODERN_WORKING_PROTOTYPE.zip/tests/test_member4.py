import json, shutil, subprocess
from pathlib import Path
import pytest
from engine.rotation_engine import generate_rotations
from engine.scoring import reweight, rank_rotations, PRIORITY_WEIGHTS

def fake_crops():
    def r(c,s,score):
        return {"crop":c,"season":s,"score":score,"rejected":False,
                "sub_scores":{"temperature":80,"water":80,"soil":80,"season":80,"stress":80},
                "reasons":[],"warnings":[],"reject_reason":None}
    return {"status":"success","slots":{"rabi":[r("wheat","rabi",90),r("chickpea","rabi",85)],
      "zaid":[r("mungbean","zaid",88),r("cowpea","zaid",80)],
      "kharif":[r("rice","kharif",87),r("maize","kharif",82)]},"rejected":[]}

def test_generate_rabi_order_and_limit():
    out=generate_rotations({"start_season":"rabi"}, {}, fake_crops())
    assert isinstance(out,list) and len(out)<=300 and out[0][0] in ("wheat","chickpea")
    assert all(len(x)==3 and x[0]!=x[1] and x[1]!=x[2] for x in out)

def test_empty_slot_error():
    c=fake_crops(); c["slots"]["zaid"]=[]
    assert generate_rotations({"start_season":"rabi"}, {}, c)["code"]=="no_candidates"

def test_reweight_normalises_and_clamps():
    c={"climate":10,"water":20,"soil":30,"diversity":40,"compatibility":50,"resilience":60}
    assert abs(reweight(c,{k:1 for k in c})-reweight(c,{k:2 for k in c}))<1e-9
    assert reweight({"x":200},{"x":1})==100
    assert reweight({"x":20},{"x":0}) is None

def test_rank_exactly_three():
    rows=[{"rotation":[str(i)],"final_score":i,"base_score":i} for i in range(5)]
    out=rank_rotations(rows)
    assert [x["rank"] for x in out]==[1,2,3] and len(out)==3

def test_js_python_parity_fixed_cases():
    node=shutil.which("node")
    if not node: pytest.skip("node is not installed")
    js=Path(__file__).resolve().parents[1]/"static"/"js"/"reweight.js"
    cases=[
      ({"climate":10,"water":30,"soil":50,"diversity":70,"compatibility":90,"resilience":100}, PRIORITY_WEIGHTS["balanced"]),
      ({"climate":100,"water":0,"soil":50,"diversity":25,"compatibility":75,"resilience":60}, PRIORITY_WEIGHTS["save_water"]),
    ]
    for comp,w in cases:
        code=f"const x=require({json.dumps(str(js))}); console.log(JSON.stringify(x.reweight({json.dumps(comp)},{json.dumps(w)})));"
        got=json.loads(subprocess.check_output([node,"-e",code],text=True).strip())
        assert abs(got-reweight(comp,w))<0.01
