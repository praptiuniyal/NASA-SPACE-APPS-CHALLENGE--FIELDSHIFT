"""Generates docs/mock/*.json. MOCK values only - NOT NASA data."""
import json, random
random.seed(7)
W = {"climate": .20, "water": .20, "soil": .15, "diversity": .10, "compatibility": .15, "resilience": .20}

def replay(rot, base):
    by = []
    for y in range(1996, 2026):
        s = max(25, min(98, int(random.gauss(base, 12))))
        by.append({"year": y, "score": s, "survived": s >= 60})
    sc = sorted(b["score"] for b in by)
    w = min(by, key=lambda b: b["score"])
    return {"status": "success", "rotation": rot, "years_tested": 30, "survive_threshold": 0.6,
            "survival_rate": round(sum(b["survived"] for b in by) / 30, 2),
            "median_score": sc[15], "p10_score": sc[3],
            "worst_year": {"year": w["year"], "score": w["score"]}, "by_year": by}

def rot(rank, crops, comps, reasons, inc, water):
    final = round(sum(comps[k] * W[k] for k in W))
    return {"rank": rank, "rotation": crops, "slots": ["rabi", "zaid", "kharif"],
            "base_score": final, "final_score": final, "components": comps, "weights_used": W,
            "est_income_inr_per_ha": inc, "est_water_m3_per_ha": water,
            "crop_per_drop": round(inc / water, 2), "reasons": reasons, "warnings": []}

rots = [
  rot(1, ["chickpea", "mungbean", "maize"], dict(climate=86, water=84, soil=90, diversity=92, compatibility=88, resilience=82),
      ["MOCK: includes two legumes", "MOCK: no repeated plant family", "MOCK: moderate water demand"], 98000, 6200),
  rot(2, ["wheat", "mungbean", "soybean"], dict(climate=82, water=70, soil=84, diversity=85, compatibility=80, resilience=74),
      ["MOCK: legume before and after cereal"], 105000, 7800),
  rot(3, ["mustard", "mungbean", "pigeonpea"], dict(climate=78, water=80, soil=79, diversity=80, compatibility=76, resilience=70),
      ["MOCK: low water demand"], 87000, 5600),
]
replays = [replay(r["rotation"], b) for r, b in zip(rots, (80, 72, 66))]
data = {
  "status": "success", "mock": True,
  "farm": {"name": "Mock Farm", "latitude": 29.2, "longitude": 79.5, "area_ha": 1.5, "soil_type": "loamy",
           "irrigation": "borewell", "water_availability": "medium", "start_season": "rabi",
           "previous_crops": ["rice", "wheat"], "current_plan": ["wheat", "rice", "wheat"],
           "priority": "balanced", "language": "en"},
  "climate": {"status": "success", "source": "MOCK (not NASA)", "fetched_on": "2026-11-01",
              "summary": {"temp_mean_c": 24.1, "rain_annual_mm": 1180, "solar_mean_mj_m2": 17.5,
                          "humidity_mean_pct": 66, "soil_wetness_mean": 0.55},
              "indicators": {"rain_cv": 0.22, "temp_trend_c_per_decade": 0.3, "rain_trend_pct": -4},
              "data_quality": {"years_available": 30, "missing_pct": 0.5, "from_cache": False}},
  "top_crops": {"status": "success", "slots": {
      "rabi": [{"crop": "chickpea", "season": "rabi", "score": 84, "reasons": ["MOCK reason"], "rejected": False},
               {"crop": "wheat", "season": "rabi", "score": 80, "reasons": ["MOCK reason"], "rejected": False}],
      "zaid": [{"crop": "mungbean", "season": "zaid", "score": 81, "reasons": ["MOCK reason"], "rejected": False}],
      "kharif": [{"crop": "maize", "season": "kharif", "score": 79, "reasons": ["MOCK reason"], "rejected": False}]},
      "rejected": [{"crop": "rice", "season": "zaid", "score": 22, "rejected": True,
                    "reject_reason": "MOCK: water need far above supply in this season"}]},
  "rotations": rots, "replays": replays,
  "regret": {"recommended": rots[0]["rotation"], "alternative": rots[1]["rotation"], "baseline_difference": 6,
             "drought_difference": 19, "worst_year_difference": 14,
             "main_reason": "MOCK: alternative needs more water in the grain-filling stage"},
  "backtest": {"worst_years": [{"year": replays[0]["worst_year"]["year"], "type": "dry",
               "recommended_score": replays[0]["worst_year"]["score"], "current_plan_score": 31}],
               "note": "Model replay, not real harvest records."},
  "comparison": {"current_plan": ["wheat", "rice", "wheat"], "score": 61, "est_water_m3_per_ha": 9800,
                 "est_income_inr_per_ha": 90000,
                 "difference": {"score": rots[0]["final_score"] - 61, "water_m3_per_ha": 6200 - 9800, "income_inr_per_ha": 8000}},
  "confidence": {"level": "Medium", "reasons": ["30 years of data", "Soil entered as a category only"]},
  "labels": {"nasa": ["temperature", "rainfall"], "farmer": ["soil_type", "irrigation"],
             "reference_estimate": ["income", "water use"]},
}
sim = {"status": "success", "scenario": {"name": "drought", "rain_change_pct": -20, "temp_change_c": 1.0},
       "rotation": rots[0]["rotation"], "baseline_score": rots[0]["final_score"], "scenario_score": rots[0]["final_score"] - 7,
       "score_change": -7, "by_crop": [{"crop": c, "relative_yield": 0.8} for c in rots[0]["rotation"]],
       "explanation": "MOCK explanation.", "note": "What-if scenario, not a forecast."}
json.dump(data, open("docs/mock/analyze_response.json", "w"), indent=2)
json.dump(sim, open("docs/mock/simulation_result.json", "w"), indent=2)
