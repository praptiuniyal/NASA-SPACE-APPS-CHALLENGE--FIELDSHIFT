(function (global) {
  "use strict";
  const PRIORITY_WEIGHTS = {
    balanced: {climate:.20, water:.20, soil:.15, diversity:.10, compatibility:.10, resilience:.25},
    save_water: {climate:.15, water:.35, soil:.10, diversity:.05, compatibility:.10, resilience:.25},
    improve_soil: {climate:.15, water:.15, soil:.30, diversity:.15, compatibility:.10, resilience:.15},
    climate_resilience: {climate:.20, water:.15, soil:.10, diversity:.05, compatibility:.05, resilience:.45}
  };
  function reweight(components, weights) {
    if (!components || !weights) return null;
    let total = 0, value = 0;
    Object.keys(components).forEach(k => {
      const w = Math.max(0, Number(weights[k] || 0));
      total += w;
      value += Number(components[k] || 0) * w;
    });
    if (total <= 0) return null;
    return Math.max(0, Math.min(100, value / total));
  }
  global.PRIORITY_WEIGHTS = PRIORITY_WEIGHTS;
  global.reweight = reweight;
  if (typeof module !== "undefined" && module.exports) module.exports = {PRIORITY_WEIGHTS, reweight};
})(typeof window !== "undefined" ? window : globalThis);
