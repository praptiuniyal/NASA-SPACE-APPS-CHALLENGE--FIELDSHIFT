from datetime import date,timedelta
import copy
from engine import replay, simulator, regret, confidence

ROWS=[
 {'crop':'a','season':'kharif','sowing_window':{'start':'06-01','end':'06-01'},'stage_ini_days':10,'stage_dev_days':10,'stage_mid_days':10,'stage_late_days':10,'ky':1.0,'assumption_flag':False},
 {'crop':'b','season':'rabi','sowing_window':{'start':'10-15','end':'10-15'},'stage_ini_days':10,'stage_dev_days':10,'stage_mid_days':10,'stage_late_days':10,'ky':1.0,'assumption_flag':False},
 {'crop':'c','season':'zaid','sowing_window':{'start':'03-16','end':'03-16'},'stage_ini_days':10,'stage_dev_days':10,'stage_mid_days':10,'stage_late_days':10,'ky':1.0,'assumption_flag':False},
]

def hist(years=3,rain=5):
 s=date(2000,1,1); e=date(2000+years,12,31); n=(e-s).days+1
 dates=[(s+timedelta(days=i)).isoformat() for i in range(n)]
 return {'status':'success','daily':{'date':dates,'tmax_c':[30.]*n,'tmin_c':[15.]*n,'tmean_c':[22.5]*n,'rain_mm':[rain]*n,'et0_mm':[4.]*n}}

def fake_stats(daily,row,sow):
 start=date.fromisoformat(sow); harvest=start+timedelta(days=40)
 last=date.fromisoformat(daily['date'][-1]); complete=harvest<=last
 return {'status':'success','crop':row['crop'],'season':row['season'],'sow_date':sow,'harvest_date':harvest.isoformat(),'etc_mm':100 if complete else None,'effective_rain_mm':100 if complete else None,'gdd':500 if complete else None,'heat_days_flowering':0 if complete else None,'frost_days':0 if complete else None,'waterlog_days':0 if complete else None,'season_completed':complete}

def patch_replay(monkeypatch, ws=1.0):
 monkeypatch.setattr(replay,'_deps',lambda:(lambda:ROWS,lambda st,f:ws, fake_stats))

def test_replay_perfect_and_year_labels(monkeypatch):
 patch_replay(monkeypatch,1.0); r=replay.replay_history(['a','b','c'],{'start_season':'kharif'},hist())
 assert r['status']=='success' and r['survival_rate']==1.0 and r['by_year'][0]['year']==2000

def test_replay_zero_water_fails(monkeypatch):
 patch_replay(monkeypatch,0.0); r=replay.replay_history(['a','b','c'],{'start_season':'kharif'},hist())
 assert r['survival_rate']==0.0

def test_incomplete_final_cycles_excluded(monkeypatch):
 patch_replay(monkeypatch,1.0); r=replay.replay_history(['a','b','c'],{'start_season':'kharif'},hist(1))
 assert r['years_excluded']>=1

def test_resilience_clamped():
 assert 0<=replay.calculate_resilience({'survival_rate':1,'p10_score':100},[{'baseline_score':100,'score_change':-500}])<=100

def fake_detail(rotation,farm,history):
 rain=sum(x or 0 for x in history['daily']['rain_mm'])/len(history['daily']['rain_mm'])
 ry=min(1,rain/5); return {'status':'success','cycles':[{'year':2000,'score':ry*100,'survived':ry>=.6,'crops':[{'crop':c,'relative_yield':ry} for c in rotation]}]}

def test_simulator_baseline_and_no_mutation(monkeypatch):
 monkeypatch.setattr(simulator,'replay_detailed',fake_detail); h=hist(1); old=copy.deepcopy(h)
 r=simulator.simulate(['a','b','c'],{'latitude':29.2},{},h,{'name':'baseline'})
 assert r['score_change']==0 and h==old and r['note']['code']=='whatif_not_forecast'

def test_drought_not_improve(monkeypatch):
 monkeypatch.setattr(simulator,'replay_detailed',fake_detail); r=simulator.simulate(['a','b','c'],{'latitude':29.2},{},hist(1),{'name':'drought'})
 assert r['score_change']<=0

def test_regret_identical(monkeypatch):
 monkeypatch.setattr(regret,'replay_detailed',lambda rot,f,h:{'status':'success','cycles':[{'year':2000,'score':50}]})
 monkeypatch.setattr(regret,'simulate',lambda *a,**k:{'scenario_score':50})
 x={'rotation':['a','b','c'],'components':{'water':80}}
 r=regret.compare_rotations(x,x,{}, {}, {})
 assert r['baseline_difference']==0 and r['drought_difference']==0 and r['worst_year_difference']==0

def test_backtest_dry_and_no_plan(monkeypatch):
 h=hist(1); # make 2000 dry, 2001 wet
 for i,d in enumerate(h['daily']['date']): h['daily']['rain_mm'][i]=1 if d.startswith('2000') else 10
 monkeypatch.setattr(regret,'replay_detailed',lambda *a:{'status':'success','cycles':[{'year':2000,'score':40},{'year':2001,'score':80}]})
 r=regret.backtest(['a','b','c'],{'current_plan':[]},h)
 assert r['worst_years'][0]['type']=='dry' and r['worst_years'][0]['year']==2000 and r['worst_years'][0]['current_plan_score'] is None

def test_confidence_perfect(monkeypatch):
 monkeypatch.setattr(confidence,'_load_crops',lambda:ROWS)
 ro=[{'rotation':['a','b','c'],'slots':['kharif','rabi','zaid'],'final_score':90},{'rotation':['a','b','c'],'slots':['kharif','rabi','zaid'],'final_score':80}]
 r=confidence.confidence({}, {'data_quality':{'years_available':30,'missing_pct':0}},ro,{'defaulted_fields':[],'warnings':[]})
 assert r=={'level':'High','points':100,'reasons':[{'code':'conf_strong_data','params':{}}]}

def test_confidence_deductions(monkeypatch):
 bad=[dict(x,assumption_flag=True) for x in ROWS]; monkeypatch.setattr(confidence,'_load_crops',lambda:bad)
 ro=[{'rotation':['a','b','c'],'slots':['kharif','rabi','zaid'],'final_score':90},{'rotation':['a','b','c'],'slots':['kharif','rabi','zaid'],'final_score':89}]
 r=confidence.confidence({}, {'data_quality':{'years_available':10,'missing_pct':20}},ro,{'defaulted_fields':['x','y','z','q'],'warnings':[{'code':'outside_india','params':{}}]})
 assert r['points']==5 and r['level']=='Low'
