"""
engine/nasa_api.py  -  Member 2
The ONLY file that talks to NASA POWER. Everyone else reads the dicts we return.
  get_history(latitude, longitude, years=30)  -> history  (daily weather)
  get_nasa_data(latitude, longitude)          -> climate  (summary numbers)
Never invents data. If NASA fails we use the saved copy (from_cache True) or return an error.
"""
import json
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from statistics import median, pstdev

try:
    import requests
except ImportError:          # we still import fine; get_history will explain what to install
    requests = None

from engine.climate import (compute_et0, day_of_year, mean_ignore_none, sum_ignore_none,
                            linear_slope, SLOTS)

NASA_URL = 'https://power.larc.nasa.gov/api/temporal/daily/point'
NASA_VARS = ['T2M', 'T2M_MAX', 'T2M_MIN', 'PRECTOTCORR', 'ALLSKY_SFC_SW_DWN',
             'RH2M', 'WS2M', 'GWETROOT']
TIMEOUT_S = 60
RETRIES = 2
RETRY_WAIT_S = 2
GRID_DEG = 0.5               # ASSUMPTION: NASA grid cell ~0.5 degree, used as cache key
MAX_GAP_DAYS = 2             # gaps up to 2 days are filled by a straight line
FIRST_NASA_YEAR = 1981
DRY_DAY_MM = 1.0             # ASSUMPTION: a dry day has rain below 1 mm
MIN_YEAR_DATA = 0.9          # ASSUMPTION: a year needs 90% of days with data to be used
CACHE_DIR = Path(__file__).resolve().parent.parent / 'data' / 'cache'


def _error(code, message):
    return {'status': 'error', 'code': code, 'message': message}


def _is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _grid(x):
    """Round a coordinate to the 0.5 degree grid cell."""
    return round(round(x / GRID_DEG) * GRID_DEG, 1)


def _date_range(years, today=None):
    """Last `years` COMPLETE calendar years, ending last December 31."""
    today = today or date.today()
    end_year = today.year - 1
    return end_year - years + 1, end_year


def _cache_file(glat, glon, start_year, end_year):
    return CACHE_DIR / f"history_{glat}_{glon}_{start_year}_{end_year}.json"


# ---------------- talking to NASA ----------------
def _fetch_nasa(glat, glon, start_year, end_year):
    """Returns (json, None) or (None, error text). 60 s timeout, 2 retries."""
    if requests is None:
        return None, "The 'requests' library is missing. Run: pip install requests"
    params = {'parameters': ','.join(NASA_VARS), 'community': 'AG',
              'longitude': glon, 'latitude': glat,
              'start': f"{start_year}0101", 'end': f"{end_year}1231", 'format': 'JSON'}
    last_error = 'unknown error'
    for attempt in range(RETRIES + 1):
        try:
            r = requests.get(NASA_URL, params=params, timeout=TIMEOUT_S)
            if r.status_code == 200:
                return r.json(), None
            last_error = f"NASA returned HTTP {r.status_code}: {str(getattr(r, 'text', ''))[:200]}"
        except Exception as e:
            last_error = f"{type(e).__name__}: {e}"
        if attempt < RETRIES:
            time.sleep(RETRY_WAIT_S)
    return None, last_error


def _clean(v):
    """NASA's missing marker -999 becomes None (never averaged)."""
    if v is None:
        return None
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    return None if v == -999 else v


def _parse_nasa(data):
    """Turn the NASA JSON into plain parallel lists. Returns (dict, None) or (None, error)."""
    try:
        series = data['properties']['parameter']
        for name in NASA_VARS:
            if name not in series:
                return None, f"NASA response has no data for {name}"
        keys = sorted(series['T2M'].keys())                       # 'YYYYMMDD'
        dates = [f"{k[:4]}-{k[4:6]}-{k[6:]}" for k in keys]
        raw = {name: [_clean(series[name].get(k)) for k in keys] for name in NASA_VARS}
        # Unit check: if solar is kWh/m2/day convert to MJ/m2/day (x 3.6).
        units = str(data.get('parameters', {}).get('ALLSKY_SFC_SW_DWN', {}).get('units', '')).lower()
        factor = 3.6 if 'kw' in units else 1.0      # ASSUMPTION: unknown unit means MJ already
        raw['ALLSKY_SFC_SW_DWN'] = [None if v is None else v * factor
                                    for v in raw['ALLSKY_SFC_SW_DWN']]
        raw['date'] = dates
        return raw, None
    except Exception as e:
        return None, f"Could not read NASA response ({type(e).__name__}: {e})"


def _fill_short_gaps(values, max_gap=MAX_GAP_DAYS):
    """Fill runs of None of length <= max_gap with a straight line between neighbours."""
    out = list(values)
    n, i = len(out), 0
    while i < n:
        if out[i] is None:
            j = i
            while j < n and out[j] is None:
                j += 1
            gap = j - i
            if i > 0 and j < n and gap <= max_gap:
                a, b = out[i - 1], out[j]
                for k in range(gap):
                    out[i + k] = a + (b - a) * (k + 1) / (gap + 1)
            i = j
        else:
            i += 1
    return out


def _build_history(raw, glat, glon, start_year, end_year):
    filled = {name: _fill_short_gaps(raw[name]) for name in NASA_VARS}
    total = sum(len(v) for v in filled.values())
    missing = sum(1 for v in filled.values() for x in v if x is None)
    dates = raw['date']
    et0 = [compute_et0(tx, tn, glat, day_of_year(d))
           for tx, tn, d in zip(filled['T2M_MAX'], filled['T2M_MIN'], dates)]
    years = list(range(start_year, end_year + 1))
    return {
        'status': 'success', 'code': None, 'message': None,
        'source': 'NASA POWER',
        'fetched_on': date.today().isoformat(),
        'grid_cell': {'latitude': glat, 'longitude': glon},
        'years': years,
        'daily': {'date': dates,
                  'tmax_c': filled['T2M_MAX'], 'tmin_c': filled['T2M_MIN'],
                  'tmean_c': filled['T2M'], 'rain_mm': filled['PRECTOTCORR'],
                  'solar_mj_m2': filled['ALLSKY_SFC_SW_DWN'], 'rh_pct': filled['RH2M'],
                  'wind_ms': filled['WS2M'], 'soil_wetness': filled['GWETROOT'],
                  'et0_mm': et0},
        'data_quality': {'years_available': len(years),
                         'missing_pct': round(100 * missing / total, 2) if total else 100.0,
                         'from_cache': False},
    }


def _write_cache(path, history):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(history))
    except Exception:
        pass                      # a failed cache write must never break the app


def _read_cache(path):
    try:
        data = json.loads(path.read_text())
        if data.get('status') == 'success' and 'daily' in data:
            return data
    except Exception:
        pass
    return None


def get_history(latitude, longitude, years=30):
    """Contract: get_history(latitude, longitude, years=30) -> history (or error dict)."""
    try:
        if not _is_number(latitude) or not _is_number(longitude) \
                or not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
            return _error('invalid_coordinates',
                          'Latitude must be -90..90 and longitude -180..180.')
        if isinstance(years, bool) or not isinstance(years, int) or years < 1:
            return _error('invalid_years', 'years must be a whole number of 1 or more.')
        start_year, end_year = _date_range(years)
        if start_year < FIRST_NASA_YEAR:
            return _error('invalid_years', f'NASA POWER daily data starts in {FIRST_NASA_YEAR}.')
        glat, glon = _grid(latitude), _grid(longitude)
        cache_path = _cache_file(glat, glon, start_year, end_year)

        data, err = _fetch_nasa(glat, glon, start_year, end_year)
        raw = None
        if data is not None:
            raw, err = _parse_nasa(data)
        if raw is None:                                   # NASA failed -> try the saved copy
            cached = _read_cache(cache_path)
            if cached is not None:
                cached['data_quality']['from_cache'] = True
                return cached
            return _error('nasa_unavailable',
                          f'NASA POWER could not be used and there is no saved copy. Details: {err}')
        history = _build_history(raw, glat, glon, start_year, end_year)
        _write_cache(cache_path, history)
        return history
    except Exception as e:
        return _error('internal_error', f'get_history failed: {type(e).__name__}: {e}')


# ---------------- climate summary ----------------
def _r(x, nd=2):
    return None if x is None else round(x, nd)


def _year_index(dates):
    """{year: [first_index, last_index]} for a daily list."""
    out = {}
    for i, d in enumerate(dates):
        y = int(d[:4])
        if y in out:
            out[y][1] = i
        else:
            out[y] = [i, i]
    return out


def _annual(values, year_index, how):
    """One number per calendar year ('sum' or 'mean'), skipping None.
    A year is skipped if fewer than 90% of its days have data (ASSUMPTION)."""
    out = {}
    for y, (i0, i1) in year_index.items():
        chunk = values[i0:i1 + 1]
        good = [v for v in chunk if v is not None]
        if not chunk or len(good) / len(chunk) < MIN_YEAR_DATA:
            continue
        out[y] = sum(good) if how == 'sum' else sum(good) / len(good)
    return out


def _longest_dry_run(rain):
    best = run = 0
    for r in rain:
        if r is not None and r < DRY_DAY_MM:      # unknown (None) breaks a run: ASSUMPTION
            run += 1
            best = max(best, run)
        else:
            run = 0
    return best


def _season_means(daily, years, pos):
    """30-year mean of each slot's window. Rabi crosses the new year, so a rabi season is
    labelled by the year it STARTS (Oct 15 of year Y to Mar 15 of Y+1). Incomplete seasons
    (data missing at either end) are skipped. None days inside a window are skipped."""
    seasons = {}
    for slot, ((m1, d1), (m2, d2)) in SLOTS.items():
        temps, rains, et0s = [], [], []
        for y in years:
            end_y = y if (m2, d2) >= (m1, d1) else y + 1
            s, e = f"{y}-{m1:02d}-{d1:02d}", f"{end_y}-{m2:02d}-{d2:02d}"
            if s not in pos or e not in pos:
                continue
            sl = slice(pos[s], pos[e] + 1)
            temps.append(mean_ignore_none(daily['tmean_c'][sl]))
            rains.append(sum_ignore_none(daily['rain_mm'][sl]))
            et0s.append(sum_ignore_none(daily['et0_mm'][sl]))
        seasons[slot] = {'temp_mean_c': _r(mean_ignore_none(temps)),
                         'rain_mm': _r(mean_ignore_none(rains)),
                         'et0_mm': _r(mean_ignore_none(et0s))}
    return seasons


def get_nasa_data(latitude, longitude):
    """Contract: get_nasa_data(latitude, longitude) -> climate. Calls get_history once."""
    try:
        history = get_history(latitude, longitude)
        if history.get('status') != 'success':
            return history
        daily, years = history['daily'], history['years']
        dates = daily['date']
        pos = {d: i for i, d in enumerate(dates)}
        yidx = _year_index(dates)

        rain_year = _annual(daily['rain_mm'], yidx, 'sum')
        temp_year = _annual(daily['tmean_c'], yidx, 'mean')
        summary = {
            'temp_mean_c': _r(mean_ignore_none(daily['tmean_c'])),
            'temp_max_c': _r(mean_ignore_none(daily['tmax_c'])),   # ASSUMPTION: mean daily max
            'temp_min_c': _r(mean_ignore_none(daily['tmin_c'])),   # ASSUMPTION: mean daily min
            'rain_annual_mm': _r(mean_ignore_none(list(rain_year.values()))),
            'solar_mean_mj_m2': _r(mean_ignore_none(daily['solar_mj_m2'])),
            'humidity_mean_pct': _r(mean_ignore_none(daily['rh_pct'])),
            'soil_wetness_mean': _r(mean_ignore_none(daily['soil_wetness']), 3),
        }

        # --- indicators ---
        totals = list(rain_year.values())
        mean_rain = mean_ignore_none(totals)
        rain_cv = None
        if len(totals) >= 2 and mean_rain:                 # ASSUMPTION: population std
            rain_cv = pstdev(totals) / mean_rain
        ys = sorted(temp_year)
        trend = linear_slope(ys, [temp_year[y] for y in ys])
        rain_ys = sorted(rain_year)
        rain_trend = None
        if len(rain_ys) > 10:                              # last 10 years vs all earlier years
            base = [rain_year[y] for y in rain_ys[:-10]]
            recent = [rain_year[y] for y in rain_ys[-10:]]
            base_mean = sum(base) / len(base)
            if base_mean > 0:
                rain_trend = (sum(recent) / len(recent) - base_mean) / base_mean * 100
        runs = []
        for y in years:                                    # longest dry run, Jun 1 - Sep 30
            s, e = f"{y}-06-01", f"{y}-09-30"
            if s in pos and e in pos:
                runs.append(_longest_dry_run(daily['rain_mm'][pos[s]:pos[e] + 1]))
        dry = None
        if runs:
            dry = median(runs)
            dry = int(dry) if dry == int(dry) else dry
        indicators = {'rain_cv': _r(rain_cv, 3),
                      'temp_trend_c_per_decade': _r(None if trend is None else trend * 10, 3),
                      'rain_trend_pct': _r(rain_trend),
                      'dry_spell_days_max': dry}

        return {'status': 'success', 'code': None, 'message': None,
                'source': history['source'], 'fetched_on': history['fetched_on'],
                'location': {'latitude': latitude, 'longitude': longitude},
                'summary': summary,
                'seasons': _season_means(daily, years, pos),
                'indicators': indicators,
                'data_quality': history['data_quality']}
    except Exception as e:
        return _error('internal_error', f'get_nasa_data failed: {type(e).__name__}: {e}')
