"""Tests for engine/crop_data.py  (run: python -m pytest tests/test_crop_data.py)"""
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from engine.crop_data import (  # noqa: E402
    crop_rows, get_crop, load_crops, load_crops_report, sow_date_for_year, total_duration_days,
)

REAL_CSV = ROOT / "data" / "crops.csv"


def _real_rows():
    with open(REAL_CSV, newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        return reader.fieldnames, list(reader)


def _write_csv(tmp_path, rows):
    """Write rows (dicts) to a temp CSV with the real header; return its path."""
    header, _ = _real_rows()
    path = tmp_path / "crops_test.csv"
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=header)
        writer.writeheader()
        writer.writerows(rows)
    return path


def _base_row(crop="wheat"):
    _, rows = _real_rows()
    return dict(next(r for r in rows if r["crop"] == crop))


def test_real_csv_has_14_rows_and_34_columns():
    header, rows = _real_rows()
    assert len(header) == 34
    assert len(rows) == 14
    assert all(len(r) == 34 for r in rows)


def test_real_csv_all_rows_load_with_no_exclusions():
    report = load_crops_report()
    assert report["excluded"] == []
    assert len(report["crops"]) == 14
    assert len(crop_rows()) == 14


def test_valid_row_loads_with_correct_types():
    row = get_crop("wheat", "rabi")
    assert row["sowing_window"] == {"start": "11-01", "end": "11-25"}
    assert row["preferred_soil"] == ["loamy", "silty", "clay"]
    assert row["waterlogging_sensitive"] is False
    assert row["nitrogen_fixing"] is False
    assert isinstance(row["kc_mid"], float)
    assert isinstance(row["stage_mid_days"], int)
    assert row["assumption_flag"] is True


def test_row_with_missing_kc_is_excluded(tmp_path):
    bad = _base_row("wheat")
    bad["kc_mid"] = ""
    report = load_crops_report(_write_csv(tmp_path, [bad]))
    assert report["crops"] == []
    assert report["excluded"] == [{"crop": "wheat", "season": "rabi", "code": "missing_data"}]


def test_200_day_crop_in_zaid_is_excluded(tmp_path):
    long_crop = _base_row("mungbean")
    long_crop.update(stage_ini_days="50", stage_dev_days="50", stage_mid_days="50", stage_late_days="50")
    report = load_crops_report(_write_csv(tmp_path, [long_crop]))
    assert report["crops"] == []
    assert report["excluded"][0]["code"] == "duration_exceeds_slot"


def test_crop_longer_than_slot_by_20_days_only_warns(tmp_path):
    # zaid slot is 77 days; 97 days is 20 over: allowed (harvest_overlap is added by crop_engine)
    ok = _base_row("mungbean")
    ok.update(stage_ini_days="20", stage_dev_days="30", stage_mid_days="30", stage_late_days="17")
    report = load_crops_report(_write_csv(tmp_path, [ok]))
    assert len(report["crops"]) == 1
    assert total_duration_days(report["crops"][0]) == 97


def test_flowering_end_after_harvest_is_excluded(tmp_path):
    bad = _base_row("wheat")
    bad["flowering_end_day"] = "200"
    report = load_crops_report(_write_csv(tmp_path, [bad]))
    assert report["excluded"][0]["code"] == "bad_flowering_window"


def test_sowing_window_outside_slot_is_excluded(tmp_path):
    bad = _base_row("wheat")
    bad.update(season="zaid")  # wheat window is in November, not in the zaid slot
    report = load_crops_report(_write_csv(tmp_path, [bad]))
    assert report["excluded"][0]["code"] == "sowing_outside_slot"


def test_missing_file_does_not_raise(tmp_path):
    report = load_crops_report(tmp_path / "nope.csv")
    assert report["crops"] == []
    assert report["excluded"][0]["code"] == "crops_file_unreadable"


def test_sow_date_is_window_midpoint():
    row = get_crop("wheat", "rabi")           # Nov 1 .. Nov 25 -> Nov 13
    assert sow_date_for_year(row, 2010) == "2010-11-13"


def test_load_crops_returns_list_of_dicts():
    crops = load_crops()
    assert isinstance(crops, list) and crops[0]["crop"]
