# sources.md - FIELDWISE AI crop table (Member 3)

**Read this first (honest status).** Every number in `crops.csv` was written from the
author's memory of the documents below. **None of these documents were opened or
checked while building the file.** That is why all 14 rows have `assumption_flag = True`.
Treat the file as a first draft that a person must verify. Prices are reference
estimates, not live market data.

## 1. Sources table

One `source_id` per CSV row (S01-S14). Each row draws on the same family of documents.

| source_id | crop (season) | Document / website that should support it | What it should support | Status |
|---|---|---|---|---|
| S01 | wheat (rabi) | FAO-56 Table 12; FAO I&D Paper 33; ICAR / state agriculture dept package of practices; CACP / Govt of India MSP notice for Rabi Marketing Season | Kc, Ky, sowing window, heat/frost limits, price | Recalled, not verified |
| S02 | chickpea (rabi) | same set as S01 | same | Recalled, not verified |
| S03 | mustard (rabi) | same set as S01 | same | Recalled, not verified |
| S04 | lentil (rabi) | same set as S01 | same | Recalled, not verified |
| S05 | barley (rabi) | same set as S01 | same | Recalled, not verified |
| S06 | pea (rabi) | same set as S01 (no MSP for pea; price is a market guess) | same | Recalled, not verified |
| S07 | mungbean (zaid) | FAO-56 Table 12 (proxy: dry beans); ICAR / state package of practices; MSP notice (kharif 2025-26) | Kc proxy, sowing window, price | Recalled / proxy, not verified |
| S08 | urdbean (zaid) | same as S07 | same | Recalled / proxy, not verified |
| S09 | cowpea (zaid) | same as S07 (no MSP for cowpea; price is a guess) | same | Recalled / proxy, not verified |
| S10 | rice (kharif) | FAO-56 Table 12; FAO I&D Paper 33; ICAR / state package of practices; MSP notice 2025-26 | Kc, Ky, sowing window, price | Recalled, not verified |
| S11 | maize (kharif) | same as S10 | same | Recalled, not verified |
| S12 | soybean (kharif) | same as S10 | same | Recalled, not verified |
| S13 | groundnut (kharif) | same as S10 | same | Recalled, not verified |
| S14 | pearl_millet (kharif) | FAO-56 Table 12 (millet); ICAR / state package of practices; MSP notice 2025-26 | Kc, sowing window, price | Recalled, not verified |

Where to find them:
- FAO-56 (Allen et al., 1998), Crop Evapotranspiration, Table 11 (stage lengths) and Table 12 (Kc).
- FAO Irrigation and Drainage Paper 33 (Doorenbos & Kassam, 1979), Yield Response to Water, for Ky.
- ICAR crop pages / your state agriculture department "package of practices" for sowing windows, heat and frost limits.
- Ministry of Agriculture / CACP for the MSP notice (the price column).

## 2. Values I could not verify

Everything is unverified. The groups below are the ones that are **guesses or proxies**, not even recalled from a table.

**Whole columns that are my estimate for all 14 rows**
- `sowing_start`, `sowing_end` (Indo-Gangetic plain / Terai, # ASSUMPTION; each window was chosen to sit inside one slot)
- `stage_ini_days`, `stage_dev_days`, `stage_mid_days`, `stage_late_days` (FAO stage lengths are for other regions; these are shortened to typical Indian durations)
- `tbase_c`, `topt_min_c`, `topt_max_c`
- `heat_threshold_flowering_c`, `frost_threshold_c` (frost is 0 for all warm-season crops, which means "never triggers")
- `flowering_start_day`, `flowering_end_day`
- `rain_min_mm`, `rain_max_mm` (not used by the scoring code)
- `water_demand_mm`
- `preferred_soil`, `waterlogging_sensitive`, `drought_tolerance`
- `n_credit_kg_ha` (pulses, soybean, groundnut only; others are 0 by assumption)
- `yield_ref_kg_ha`, `cost_ref_inr_per_ha`
- `category`, `family` are botanical/agronomic facts and are low-risk, but still unchecked.

**Kc values (kc_ini, kc_mid, kc_end)**
- Recalled from FAO-56 Table 12: wheat, barley, chickpea, lentil, pea, rice, maize, soybean, groundnut, pearl_millet (millet row).
- Proxy (dry-bean values reused): mungbean, urdbean, cowpea.
- Guessed: mustard `kc_mid = 1.1` (FAO gives a 1.0-1.15 range for rapeseed/canola).

**Ky values**
- Recalled from FAO Paper 33: pea 1.15, rice 1.09, maize 1.25, soybean 0.85, groundnut 0.70, wheat 1.15 (the spring wheat figure; winter wheat is 1.0).
- Guessed (no confirmed FAO 33 value): chickpea 0.85, mustard 0.85, lentil 0.85, barley 1.0, mungbean 1.0, urdbean 1.0, cowpea 1.0, pearl_millet 0.9.

**Prices (price_ref_inr_per_kg), reference estimates**
- Based on remembered MSP figures: wheat 25.85, barley 19.80, chickpea 58.75, lentil 70.00, mustard 62.00 (Rabi Marketing Season 2026-27); rice 23.69, maize 24.00, soybean 53.28, groundnut 72.63, pearl_millet 27.75, mungbean 87.68, urdbean 78.00 (kharif 2025-26).
- Pure guesses: pea 38.00, cowpea 55.00 (no MSP exists).
- Kharif 2026-27 MSPs may already be announced and may differ. Update the year in this file once checked.

## 3. Checklist: what a person must verify first

Do these in order. Time-box to about 3 hours and start with the crops most likely to appear on top (wheat, chickpea, mustard, rice, maize).

- [ ] **Kc** for the top 5 crops against FAO-56 Table 12 (Kc ini / mid / end). Fix mungbean, urdbean, cowpea proxies if a better source exists.
- [ ] **Ky** for the top 5 crops against FAO Irrigation and Drainage Paper 33. Replace every guessed Ky listed above.
- [ ] **Sowing windows** against ICAR or the state agriculture department for Uttar Pradesh / Terai.
- [ ] **Heat thresholds at flowering** and **frost thresholds** against ICAR crop pages.
- [ ] **Stage lengths and total duration** against local variety descriptions.
- [ ] **Prices** against the current MSP notice and update the year.
- [ ] After each check, change `assumption_flag` to `False` **only on rows where every value was verified**, and move the verified value out of section 2.
