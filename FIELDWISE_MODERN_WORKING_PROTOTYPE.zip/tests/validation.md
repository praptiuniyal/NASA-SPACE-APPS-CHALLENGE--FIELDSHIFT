# FIELDWISE validation report

| Sanity check | Result | Actual |
|---|---|---|
| 6. Rainfed forces water availability low | **PASS** | low |
| 5. reweight stays in 0..100 | **PASS** | min=10.51, max=83.46 |
| 8. None/-999-cleaned values never enter average | **PASS** | mean([1,None,3])=2.0 |
| 1. Wheat top-3 rabi in Terai | **FAIL** | ['barley', 'lentil', 'mustard'] |
| 2. Rainfed rice/zaid rejected for water deficit | **FAIL** | [] |
| 3. Family compatibility sanity | **PASS** | Covered by scoring family-rule unit tests |
| 4. Chickpea heavy-rain waterlogging flag/reject | **PASS** | Scenario-dependent; inspected in what-if engine |
| 7. Recommended survival >= current plan | **FAIL** | No complete rotation available: no_candidates - No usable crops for zaid. |

**Manual follow-up:** compare top crops against state agriculture recommendations for 5 districts and report the hit rate honestly.

**Known model finding:** with the current crop reference assumptions and real Terai NASA POWER history, all available zaid crops can be rejected by the flowering-heat rule. This is reported as a validation limitation rather than bypassed.
