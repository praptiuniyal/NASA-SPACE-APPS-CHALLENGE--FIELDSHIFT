import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(ROOT))
from engine.farm_validation import validate_farm
from engine.crop_data import crop_rows
from engine.nasa_api import get_history,get_nasa_data
from engine.crop_engine import recommend_crops
from engine.rotation_engine import generate_rotations
from engine.scoring import score_rotation
from engine.replay import replay_history,calculate_resilience
from engine.simulator import simulate

def fail(stage,name,x): print(f'ERROR stage {stage} {name}: {x}'); raise SystemExit(1)
def main():
    n=int(sys.argv[1]) if len(sys.argv)>1 else 1
    if n not in range(1,6): raise SystemExit('Usage: python tools/try_chain.py N (1..5)')
    farm=json.loads((ROOT/'data/demo_farms.json').read_text())['farms'][0]
    v=validate_farm(farm,crop_rows());
    if v['status']!='success':fail(1,'validate_farm',v)
    farm=v['farm']; h=get_history(farm['latitude'],farm['longitude']); c=get_nasa_data(farm['latitude'],farm['longitude'])
    if h.get('status')!='success':fail(1,'get_history',h)
    if c.get('status')!='success':fail(1,'get_nasa_data',c)
    print('STAGE 1 PASS',len(h['daily']['date']),'days',h['data_quality'])
    if n==1:return
    crops=recommend_crops(farm,c,h)
    if crops.get('status')!='success':fail(2,'recommend_crops',crops)
    for s in ['rabi','zaid','kharif']:print(s,[(x['crop'],round(x['score'],1)) for x in crops['slots'][s][:3]])
    print('STAGE 2 PASS');
    if n==2:return
    cand=generate_rotations(farm,c,crops)
    if isinstance(cand,dict):fail(3,'generate_rotations',cand)
    scored=[score_rotation(r,farm,c,farm['priority'],None,crops) for r in cand]
    scored=[x for x in scored if 'rotation' in x];scored.sort(key=lambda x:x['base_score'],reverse=True);top=scored[:5]
    print('STAGE 3 PASS',len(cand),'candidates',[(x['rotation'],x['base_score']) for x in top])
    if n==3:return
    for r in top:
        rep=replay_history(r['rotation'],farm,h); sc=[simulate(r['rotation'],farm,c,h,{'name':'drought'}),simulate(r['rotation'],farm,c,h,{'name':'heat_stress'})]
        print(r['rotation'],'survival',rep.get('survival_rate'),'worst',rep.get('worst_year'),'resilience',calculate_resilience(rep,sc))
    print('STAGE 4 PASS')
    if n==4:return
    import app; old=app.USE_MOCK; app.USE_MOCK=False
    try: result,status=app.run_analysis(farm)
    finally: app.USE_MOCK=old
    if status!=200:fail(5,'run_analysis',result)
    (ROOT/'docs/last_response.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print('STAGE 5 PASS',sorted(result.keys()))
if __name__=='__main__':main()
