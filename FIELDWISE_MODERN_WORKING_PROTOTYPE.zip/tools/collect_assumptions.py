from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent; rows=[]
for p in list((ROOT/'engine').glob('*.py'))+[ROOT/'app.py']:
    lines=p.read_text(encoding='utf-8').splitlines()
    for i,line in enumerate(lines,1):
        if '# ASSUMPTION' in line:
            comment=line.split('# ASSUMPTION',1)[1].strip(' :.-') or 'Assumption noted in code'
            rows.append((str(p.relative_to(ROOT)),i,comment,line.strip().replace('|','\\|')))
out=ROOT/'docs/assumptions.md'; out.parent.mkdir(exist_ok=True)
text=['# FIELDWISE AI assumptions','','| File | Line | Assumption | Code |','|---|---:|---|---|']+[f'| {f} | {n} | {c} | `{code}` |' for f,n,c,code in rows]
src=ROOT/'data/sources.md'
if src.exists():
    s=src.read_text(encoding='utf-8'); marker='Values I could not verify'; idx=s.lower().find(marker.lower())
    if idx>=0:text+=['','## Values I could not verify','',s[idx+len(marker):].strip()]
out.write_text('\n'.join(text)+'\n',encoding='utf-8'); print(f'Found {len(rows)} assumptions; wrote {out}')
