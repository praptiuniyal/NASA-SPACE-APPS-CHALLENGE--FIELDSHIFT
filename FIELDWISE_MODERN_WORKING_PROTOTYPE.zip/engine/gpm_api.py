"""NASA GPM IMERG recent-precipitation evidence layer.

FIELDWISE uses POWER for the 30-year replay. IMERG is deliberately separate:
it supplies *recent* satellite precipitation evidence (7/30-day totals and
heavy-rain events) so we do not double-count rainfall in the historical model.

The most reliable hackathon workflow is offline-first. ``get_gpm_context`` reads
real IMERG daily point observations cached as JSON/CSV. ``import_imerg_csv``
imports a point time-series exported from NASA Giovanni/GES DISC. A project may
also set ``FIELDWISE_GPM_POINT_URL`` to an authenticated/subsetting service that
returns JSON rows; the provider caches any successful response.

No synthetic precipitation is ever substituted for unavailable GPM data.
NASA product target: IMERG V07 Early Run daily, ~0.1 degree (~10 km).
"""
from __future__ import annotations

import csv
import json
import os
from datetime import date, datetime, timedelta
from pathlib import Path
from statistics import mean
from typing import Iterable

import requests

ROOT = Path(__file__).resolve().parents[1]
CACHE_DIR = ROOT / "data" / "cache" / "gpm"
PRODUCT = "GPM_3IMERGDE_07"
SOURCE = "NASA GPM IMERG Early Run"
SPATIAL_RESOLUTION = "0.1 degree (~10 km)"
TEMPORAL_RESOLUTION = "1 day (derived from IMERG half-hourly estimates)"
HEAVY_RAIN_MM = 50.0  # ASSUMPTION: agronomic screening threshold, not a NASA threshold.


def _error(code: str, message: str) -> dict:
    return {"status": "error", "code": code, "message": message}


def _grid(v: float) -> float:
    return round(float(v), 1)


def _cache_path(latitude: float, longitude: float) -> Path:
    return CACHE_DIR / f"imerg_{_grid(latitude):.1f}_{_grid(longitude):.1f}.json"


def _state(total_30d: float | None) -> str | None:
    """Coarse recent-rain state; intentionally not called an anomaly."""
    if total_30d is None:
        return None
    # ASSUMPTION: simple communication bands; not climatological percentiles.
    if total_30d < 20:
        return "very_dry"
    if total_30d < 60:
        return "dry"
    if total_30d <= 200:
        return "normal"
    if total_30d <= 350:
        return "wet"
    return "very_wet"


def _normalise_rows(rows: Iterable[dict]) -> list[dict]:
    out = []
    for row in rows:
        ds = row.get("date") or row.get("Date") or row.get("time")
        val = row.get("rain_mm")
        if val is None:
            for key in ("precipitation", "precipitationCal", "precip_mm", "value"):
                if row.get(key) not in (None, ""):
                    val = row.get(key)
                    break
        try:
            d = datetime.fromisoformat(str(ds)[:10]).date().isoformat()
            v = float(val)
            if v < 0:
                continue
            out.append({"date": d, "rain_mm": round(v, 4)})
        except (TypeError, ValueError):
            continue
    dedup = {x["date"]: x for x in out}
    return [dedup[k] for k in sorted(dedup)]


def _summarise(rows: list[dict], latitude: float, longitude: float, from_cache: bool) -> dict:
    if not rows:
        return _error("gpm_no_data", "No valid IMERG daily precipitation observations were available.")
    rows = sorted(rows, key=lambda x: x["date"])
    last_date = datetime.fromisoformat(rows[-1]["date"]).date()
    def window(days: int) -> list[float]:
        start = last_date - timedelta(days=days - 1)
        return [x["rain_mm"] for x in rows if datetime.fromisoformat(x["date"]).date() >= start]
    r7, r30 = window(7), window(30)
    total7 = round(sum(r7), 2) if r7 else None
    total30 = round(sum(r30), 2) if r30 else None
    heavy = sum(1 for v in r30 if v >= HEAVY_RAIN_MM)
    return {
        "status": "success",
        "source": SOURCE,
        "product": PRODUCT,
        "spatial_resolution": SPATIAL_RESOLUTION,
        "temporal_resolution": TEMPORAL_RESOLUTION,
        "location": {"latitude": _grid(latitude), "longitude": _grid(longitude)},
        "latest_date": rows[-1]["date"],
        "recent_7d_rain_mm": total7,
        "recent_30d_rain_mm": total30,
        "recent_30d_mean_daily_mm": round(mean(r30), 2) if r30 else None,
        "heavy_rain_days_30d": heavy,
        "rain_state": _state(total30),
        "observations_available": len(rows),
        "from_cache": bool(from_cache),
        "note": {"code": "gpm_recent_context_not_forecast", "params": {}},
    }


def import_imerg_csv(csv_path: str | Path, latitude: float, longitude: float) -> dict:
    """Import a real NASA Giovanni/GES DISC point CSV and cache normalized rows."""
    try:
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            rows = _normalise_rows(csv.DictReader(line for line in f if not line.lstrip().startswith("#")))
        if not rows:
            return _error("gpm_no_data", "The CSV contained no recognizable date/precipitation rows.")
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        payload = {"source": SOURCE, "product": PRODUCT, "latitude": _grid(latitude),
                   "longitude": _grid(longitude), "rows": rows}
        _cache_path(latitude, longitude).write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return _summarise(rows, latitude, longitude, True)
    except Exception as exc:
        return _error("gpm_import_error", f"Could not import IMERG CSV: {type(exc).__name__}: {exc}")


def _fetch_configured_point_service(latitude: float, longitude: float, days: int) -> list[dict] | None:
    """Optional authenticated JSON point service hook.

    FIELDWISE_GPM_POINT_URL should accept lat, lon, start, end and return either
    a JSON list of rows or {'rows': [...]}. FIELDWISE_GPM_TOKEN is sent as a
    Bearer token. This keeps credentials outside source control and lets teams
    point at a NASA GES DISC/Harmony proxy or their own Earthdata-authenticated
    subset service without changing the decision engine.
    """
    url = os.getenv("FIELDWISE_GPM_POINT_URL")
    if not url:
        return None
    end = date.today() - timedelta(days=1)
    start = end - timedelta(days=max(days, 30) - 1)
    headers = {}
    token = os.getenv("FIELDWISE_GPM_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.get(url, params={"lat": latitude, "lon": longitude,
                                  "start": start.isoformat(), "end": end.isoformat(),
                                  "product": PRODUCT}, headers=headers, timeout=60)
    r.raise_for_status()
    body = r.json()
    return _normalise_rows(body.get("rows", body) if isinstance(body, dict) else body)


def get_gpm_context(latitude: float, longitude: float, days: int = 30, force_refresh: bool = False) -> dict:
    """Return recent IMERG precipitation evidence without ever fabricating data."""
    try:
        latitude, longitude = float(latitude), float(longitude)
        if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
            return _error("gpm_invalid_location", "Latitude/longitude are outside valid ranges.")
        path = _cache_path(latitude, longitude)
        if path.exists() and not force_refresh:
            data = json.loads(path.read_text(encoding="utf-8"))
            return _summarise(_normalise_rows(data.get("rows", [])), latitude, longitude, True)
        try:
            rows = _fetch_configured_point_service(latitude, longitude, days)
            if rows:
                CACHE_DIR.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps({"source": SOURCE, "product": PRODUCT,
                                            "latitude": _grid(latitude), "longitude": _grid(longitude),
                                            "rows": rows}, indent=2), encoding="utf-8")
                return _summarise(rows, latitude, longitude, False)
        except Exception as exc:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                return _summarise(_normalise_rows(data.get("rows", [])), latitude, longitude, True)
            return _error("gpm_unavailable", f"IMERG retrieval failed and no cache exists: {type(exc).__name__}: {exc}")
        return _error(
            "gpm_unavailable",
            "No IMERG cache is available. Import a NASA Giovanni/GES DISC point CSV with tools/import_gpm.py, "
            "or configure FIELDWISE_GPM_POINT_URL (and FIELDWISE_GPM_TOKEN when required).",
        )
    except Exception as exc:
        return _error("gpm_unavailable", f"IMERG context failed: {type(exc).__name__}: {exc}")


def evidence_consistency(gpm: dict, climate: dict) -> dict:
    """Compare recent IMERG state with POWER climatological rainfall cautiously."""
    if gpm.get("status") != "success":
        return {"level": "unavailable", "messages": [{"code": "gpm_unavailable", "params": {}}]}
    state = gpm.get("rain_state")
    annual = (climate or {}).get("summary", {}).get("rain_annual_mm")
    messages = [{"code": "gpm_recent_rain_state", "params": {"state": state}}]
    # This is context, not a statistical anomaly comparison: POWER is long-term climate,
    # while IMERG is recent satellite precipitation.
    if annual is not None:
        messages.append({"code": "gpm_power_different_timescales", "params": {}})
    return {"level": "context_only", "messages": messages}
