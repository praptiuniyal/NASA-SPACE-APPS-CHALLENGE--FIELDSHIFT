"""Tests for engine/season_stats.py.  Run: python -m pytest tests/test_season_stats.py
FAKE weather only - hand-checkable numbers."""
from datetime import date, timedelta
from engine.season_stats import crop_season_stats

PARAMS = {'crop': 'testcrop', 'season': 'rabi',
          'stage_ini_days': 10, 'stage_dev_days': 10, 'stage_mid_days': 20, 'stage_late_days': 10,
          'kc_ini': 0.4, 'kc_mid': 1.0, 'kc_end': 0.4, 'tbase_c': 5.0,
          'heat_threshold_flowering_c': 35.0, 'frost_threshold_c': 0.0,
          'flowering_start_day': 20, 'flowering_end_day': 30,
          'waterlogging_sensitive': False}

def make_daily(n_days, start='2001-01-01', tmax=30.0, tmin=10.0, rain=0.0, et0=4.0, overrides=None):
    """Constant FAKE weather. overrides = {day_number: {'tmax_c': 40, ...}}"""
    s = date.fromisoformat(start)
    d = {'date': [], 'tmax_c': [], 'tmin_c': [], 'tmean_c': [], 'rain_mm': [], 'et0_mm': []}
    for i in range(n_days):
        row = {'tmax_c': tmax, 'tmin_c': tmin, 'rain_mm': rain}
        row.update((overrides or {}).get(i, {}))
        d['date'].append((s + timedelta(days=i)).isoformat())
        d['tmax_c'].append(row['tmax_c']); d['tmin_c'].append(row['tmin_c'])
        d['tmean_c'].append((tmax + tmin) / 2); d['rain_mm'].append(row['rain_mm'])
        d['et0_mm'].append(et0)
    return d

def test_etc_gdd_and_dates_by_hand():
    r = crop_season_stats(make_daily(100), PARAMS, '2001-01-01')
    # ini 10*0.4*4=16, dev 6.7*4=26.8, mid 20*1.0*4=80, late 7.3*4=29.2  -> 152.0
    assert abs(r['etc_mm'] - 152.0) < 0.01
    assert abs(r['gdd'] - 750.0) < 0.01              # (20 - 5) * 50 days
    assert r['harvest_date'] == '2001-02-20' and r['season_completed'] is True
    assert r['status'] == 'success' and r['crop'] == 'testcrop'

def test_heat_days_counted_only_inside_flowering_window():
    hot_all = {i: {'tmax_c': 40.0} for i in range(50)}
    assert crop_season_stats(make_daily(100, overrides=hot_all), PARAMS, '2001-01-01')['heat_days_flowering'] == 11
    hot_early = {5: {'tmax_c': 40.0}}                 # day 5 is before the window
    assert crop_season_stats(make_daily(100, overrides=hot_early), PARAMS, '2001-01-01')['heat_days_flowering'] == 0

def test_frost_days_and_effective_rain():
    frost = {i: {'tmin_c': -2.0} for i in (0, 1, 2)}
    r = crop_season_stats(make_daily(100, rain=1.0, overrides=frost), PARAMS, '2001-01-01')
    assert r['frost_days'] == 3
    # Jan 31 mm -> 29.4624, Feb 19 mm -> 18.4224  => 47.88
    assert abs(r['effective_rain_mm'] - 47.88) < 0.01

def test_incomplete_season_is_flagged():
    r = crop_season_stats(make_daily(30), PARAMS, '2001-01-01')
    assert r['status'] == 'success' and r['season_completed'] is False

def test_waterlog_days_only_for_sensitive_crops():
    wet = {i: {'rain_mm': 60.0} for i in range(4)}
    sensitive = dict(PARAMS, waterlogging_sensitive=True)
    assert crop_season_stats(make_daily(100, overrides=wet), sensitive, '2001-01-01')['waterlog_days'] == 4
    assert crop_season_stats(make_daily(100, overrides=wet), PARAMS, '2001-01-01')['waterlog_days'] == 0

def test_none_days_are_skipped_not_zero():
    d = make_daily(100)
    d['et0_mm'][0] = None
    full = crop_season_stats(make_daily(100), PARAMS, '2001-01-01')['etc_mm']
    skipped = crop_season_stats(d, PARAMS, '2001-01-01')['etc_mm']
    assert abs((full - skipped) - 0.4 * 4) < 0.01     # lost exactly day 0 (kc 0.4 * et0 4)

def test_errors_instead_of_crashing():
    bad = dict(PARAMS, kc_mid=None)
    r = crop_season_stats(make_daily(100), bad, '2001-01-01')
    assert r['status'] == 'error' and r['code'] == 'missing_data'
    assert crop_season_stats(make_daily(100), PARAMS, 'tomorrow')['code'] == 'invalid_date'
    assert crop_season_stats({}, PARAMS, '2001-01-01')['status'] == 'error'
    out = crop_season_stats(make_daily(100), PARAMS, '1990-01-01')   # sowing date not in data
    assert out['season_completed'] is False and out['etc_mm'] is None
