"""
engine/climate.py  -  Member 2 (water maths and small helpers)

ET0 = how much water the AIR "drinks" per day (mm/day).
We use Hargreaves-Samani:  ET0 = 0.0023 * (tmean + 17.8) * sqrt(tmax - tmin) * Ra
Ra = sunlight reaching the top of the air (FAO-56 formulas), in mm/day.
Unknown values are None (never 0).
"""
import math
from datetime import date

GSC = 0.0820   # solar constant in MJ/m2/min (FAO-56)
# Slot windows from the contract: (month, day) start and end.
SLOTS = {'kharif': ((6, 1), (10, 14)),
         'rabi':   ((10, 15), (3, 15)),    # crosses the new year
         'zaid':   ((3, 16), (5, 31))}


def day_of_year(date_string):
    """'2020-03-01' -> 61.  Returns None if the date is not valid."""
    try:
        return date.fromisoformat(str(date_string)[:10]).timetuple().tm_yday
    except (ValueError, TypeError):
        return None


def mean_ignore_none(values):
    """Average of the numbers in a list, skipping None. None if there are no numbers."""
    nums = [v for v in values if v is not None]
    return sum(nums) / len(nums) if nums else None


def sum_ignore_none(values):
    """Sum of the numbers in a list, skipping None. None if there are no numbers."""
    nums = [v for v in values if v is not None]
    return sum(nums) if nums else None


def linear_slope(x_list, y_list):
    """Straight-line slope (least squares). Pairs with a None are skipped.
    Returns None if there are fewer than 2 pairs or all x are equal."""
    pairs = [(x, y) for x, y in zip(x_list, y_list) if x is not None and y is not None]
    if len(pairs) < 2:
        return None
    mx = sum(p[0] for p in pairs) / len(pairs)
    my = sum(p[1] for p in pairs) / len(pairs)
    var = sum((p[0] - mx) ** 2 for p in pairs)
    if var == 0:
        return None
    return sum((p[0] - mx) * (p[1] - my) for p in pairs) / var


def slot_of_date(date_string):
    """Which slot a date falls in: 'kharif', 'rabi' or 'zaid' (None if bad date)."""
    try:
        d = date.fromisoformat(str(date_string)[:10])
    except (ValueError, TypeError):
        return None
    md = (d.month, d.day)
    if (6, 1) <= md <= (10, 14):
        return 'kharif'
    if md >= (10, 15) or md <= (3, 15):
        return 'rabi'
    return 'zaid'


def extraterrestrial_radiation(latitude, day_of_year_number):
    """Ra in MJ/m2/day (FAO-56 equations 21-25)."""
    phi = math.radians(latitude)
    j = day_of_year_number
    dr = 1 + 0.033 * math.cos(2 * math.pi * j / 365)             # sun-earth distance
    delta = 0.409 * math.sin(2 * math.pi * j / 365 - 1.39)        # solar declination
    x = -math.tan(phi) * math.tan(delta)
    x = max(-1.0, min(1.0, x))                                    # polar day / night
    ws = math.acos(x)                                             # sunset hour angle
    return (24 * 60 / math.pi) * GSC * dr * (
        ws * math.sin(phi) * math.sin(delta) + math.cos(phi) * math.cos(delta) * math.sin(ws))


def compute_et0(tmax_c, tmin_c, latitude, day_of_year):
    """Hargreaves-Samani ET0 in mm/day. None if any input is None. Never negative.
    ASSUMPTION: Hargreaves-Samani needs only temperature, so it is simple but less
    accurate than FAO-56 Penman-Monteith (future work)."""
    if tmax_c is None or tmin_c is None or latitude is None or day_of_year is None:
        return None
    try:
        tmean = (tmax_c + tmin_c) / 2
        ra_mm = extraterrestrial_radiation(latitude, day_of_year) / 2.45   # MJ -> mm/day
        et0 = 0.0023 * (tmean + 17.8) * math.sqrt(max(tmax_c - tmin_c, 0)) * ra_mm
        return max(et0, 0.0)
    except (TypeError, ValueError):
        return None
