# FIELDWISE AI Shared Contract (v2.1)

This project follows the exact Shared Contract supplied in `FIELDWISE_Leader_Prompts.pdf`. Key integration rules:

- API version is `2`; errors are dictionaries, never uncaught exceptions.
- Slots: kharif Jun 1-Oct 14; rabi Oct 15-Mar 15; zaid Mar 16-May 31.
- A rotation is three crops in consecutive slots beginning at `farm.start_season`.
- Unknown numeric values are `None`, never silently replaced with zero.
- NASA POWER daily history is fetched only by `engine/nasa_api.py` and cached on disk.
- Scores are 0..100; survival/water-satisfaction fractions are 0..1.
- Human-readable engine reasons are message objects `{code, params}` translated by the UI.
- Replay is a model reconstruction, not observed harvest records.
- Real analyze responses do not carry `mock`; mock responses may carry `mock: true`.

See the source PDF for the complete authoritative data shapes, formulas and function signatures.

## GPM/IMERG extension

`GET /api/gpm-context?lat=<latitude>&lon=<longitude>` returns version 2 plus either an error or a GPM context object. Real analyses also include `earth_state.gpm` and `earth_state.evidence_consistency`.

GPM is recent precipitation evidence only. It does not replace or alter the NASA POWER historical replay. Missing GPM must never be silently replaced with mock rainfall.
