# FIELDWISE AI

FIELDWISE AI is a transparent crop-rotation advisor built for the NASA Space Apps hackathon. A farmer enters location, soil, water availability and recent crops. FIELDWISE uses NASA POWER daily weather history, crop reference parameters and explainable scoring to recommend a three-season rotation, replay it across historical weather, compare it with the farmer's current plan, run what-if climate scenarios, and create a shareable Farmer Card.

## Run locally

```bash
python -m pip install -r requirements.txt
python tools/make_mock.py
python app.py
```

Open `http://127.0.0.1:5000/`. `app.py` starts with `USE_MOCK = True`. After real NASA data have been cached with `python tools/prefetch_demo.py`, change it to `False` for the real pipeline.

## Project structure

- `engine/` — validation, NASA/climate maths, crop scoring, rotation scoring, replay, simulation, confidence, Farmer Card.
- `data/` — crop references, sources, demo farms and (after prefetch) real NASA cache.
- `templates/`, `static/` — farm input, dashboard, charts, translations and methods page.
- `tools/` — prefetch, mock generation, module checks, chain tests, code/assumption collectors.
- `tests/` — unit/integration tests and `validation.md`.
- `docs/` — contract, assumptions, mock responses and submission materials.

## The 30-year replay

For each historical rotation cycle, FIELDWISE places each crop at the midpoint of its sowing window, calculates crop water need and stress from daily weather, converts water satisfaction to relative yield using Ky, applies heat/frost/waterlogging penalties, and marks a cycle as survived only when every crop has relative yield at least 0.6. The result is a model replay, not recorded harvest data or a yield promise.

## Data sources

The weather engine uses NASA POWER daily point data: `T2M`, `T2M_MAX`, `T2M_MIN`, `PRECTOTCORR`, `ALLSKY_SFC_SW_DWN`, `RH2M`, `WS2M`, `GWETROOT`. The default history is the last 30 complete calendar years. Real responses are cached under `data/cache/` so demo farms can work offline. Crop references and citations are documented in `data/sources.md`.

## Limits

- Historical replay is a model, not harvest records.
- Scores are relative decision-support scores, not yield or income promises.
- Crop reference data and sowing windows are India/Terai-oriented.
- Hargreaves-Samani ET0 is simpler than FAO-56 Penman-Monteith.
- What-if scenarios are sensitivity tests, not forecasts.
- Uncertain thresholds are marked `# ASSUMPTION` and collected in `docs/assumptions.md`.

## Tests and integration

```bash
python -m pytest
python tools/check_modules.py
python tools/try_chain.py 1
python tools/try_chain.py 2
python tools/try_chain.py 3
python tools/try_chain.py 4
python tools/try_chain.py 5
python tools/collect_codes.py --fill
python tools/collect_assumptions.py
```

`tests/validation.md` records eight agronomic sanity checks honestly, including failures.

## Team roles

1. Farm input, validation and translation
2. NASA data and climate maths
3. Crop and soil knowledge
4. Rotations and scoring
5. Replay, what-if, regret and confidence
6. Dashboard, charts and Farmer Card
7. Team leader: server, integration, checks and submission

## How we used AI

The team used AI coding assistants, including ChatGPT and/or other tools used by individual members, to help implement modules from a human-defined shared contract, draft tests and assist debugging/integration. AI-generated code was not treated as automatically correct: the project includes unit tests, parity tests, validation checks, provenance labels, explicit assumptions and manual review. The team should only submit claims and results it has actually tested and can explain.

## NASA GPM IMERG recent-rainfall layer

FIELDWISE now supports **NASA GPM IMERG V07 Early Run** as an optional recent-precipitation evidence layer. POWER remains the 30-year historical climate/replay source; IMERG is kept separate so recent satellite rainfall is not double-counted as historical climate.

The GPM panel can report recent 7-day/30-day rainfall, heavy-rain days, latest observation date, cache status, and a coarse recent-rainfall communication state. The state bands are explicitly model assumptions, not climatological anomalies.

### Supplying real IMERG point data

NASA GES DISC / PPS access may require Earthdata/PPS authentication. FIELDWISE therefore never fabricates GPM observations. Use either:

1. **NASA Giovanni/GES DISC CSV import (recommended for a hackathon demo):** export a daily IMERG point time series for the demo farm, then run:

```bash
python tools/import_gpm.py path/to/imerg.csv 29.2 79.5
```

2. **Authenticated point-subset service:** set `FIELDWISE_GPM_POINT_URL` to a service returning JSON rows with `date` and precipitation, and optionally `FIELDWISE_GPM_TOKEN`. Successful data are cached under `data/cache/gpm/`.

If neither real cache nor authenticated service is available, the dashboard explicitly says GPM is unavailable and the POWER analysis continues normally.

NASA reference: https://gpm.nasa.gov/data and https://gpm.nasa.gov/data/imerg
