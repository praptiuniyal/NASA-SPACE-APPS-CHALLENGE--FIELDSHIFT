"""Regret comparison and extreme-year backtest (Member 5)."""
from engine.replay import replay_detailed
from engine.simulator import simulate

def _mean(d):
    c=d.get('cycles',[]) if isinstance(d,dict) else []
    return sum(x['score'] for x in c)/len(c) if c else None

def compare_rotations(best, alternative, farm, climate, history):
    try:
        br, ar = best['rotation'], alternative['rotation']
        bd, ad = replay_detailed(br,farm,history), replay_detailed(ar,farm,history)
        bm, am=_mean(bd),_mean(ad); baseline=None if bm is None or am is None else bm-am
        bs=simulate(br,farm,climate,history,{'name':'drought'}); ass=simulate(ar,farm,climate,history,{'name':'drought'})
        drought=None if bs.get('scenario_score') is None or ass.get('scenario_score') is None else bs['scenario_score']-ass['scenario_score']
        amap={c['year']:c['score'] for c in ad.get('cycles',[])}; bmap={c['year']:c['score'] for c in bd.get('cycles',[])}
        wy=min(amap,key=amap.get) if amap else None; worst=None if wy is None or wy not in bmap else bmap[wy]-amap[wy]
        comps=best.get('components',{}); ac=alternative.get('components',{})
        key=max(comps, key=lambda k: comps.get(k,0)-ac.get(k,0)) if comps else 'climate'
        return {'recommended':br,'alternative':ar,'baseline_difference':baseline,'drought_difference':drought,
                'worst_year_difference':worst,'main_reason':{'code':f'regret_main_{key}','params':{}}}
    except Exception as e:
        return {'status':'error','code':'internal_error','message':f'compare_rotations failed: {type(e).__name__}: {e}'}

def _calendar_stats(history):
    d=history['daily']; years={}
    for i,ds in enumerate(d['date']):
        y=int(ds[:4]); x=years.setdefault(y,{'rain':[],'tmax':[]})
        if d['rain_mm'][i] is not None:x['rain'].append(d['rain_mm'][i])
        if d['tmax_c'][i] is not None:x['tmax'].append(d['tmax_c'][i])
    return {y:{'rain':sum(v['rain']) if v['rain'] else None,'tmax':sum(v['tmax'])/len(v['tmax']) if v['tmax'] else None} for y,v in years.items()}

def backtest(rotation, farm, history):
    try:
        stats=_calendar_stats(history); valid_r={y:v['rain'] for y,v in stats.items() if v['rain'] is not None}; valid_t={y:v['tmax'] for y,v in stats.items() if v['tmax'] is not None}
        picks=[('dry',min(valid_r,key=valid_r.get) if valid_r else None),('hot',max(valid_t,key=valid_t.get) if valid_t else None),('wet',max(valid_r,key=valid_r.get) if valid_r else None)]
        rec=replay_detailed(rotation,farm,history); rmap={c['year']:c['score'] for c in rec.get('cycles',[])}
        plan=farm.get('current_plan') or []; pmap={}
        if plan:
            pd=replay_detailed(plan,farm,history); pmap={c['year']:c['score'] for c in pd.get('cycles',[])}
        return {'worst_years':[{'year':y,'type':typ,'recommended_score':rmap.get(y),'current_plan_score':pmap.get(y) if plan else None} for typ,y in picks],
                'note':{'code':'model_replay_not_harvest','params':{}}}
    except Exception as e:
        return {'status':'error','code':'internal_error','message':f'backtest failed: {type(e).__name__}: {e}'}
