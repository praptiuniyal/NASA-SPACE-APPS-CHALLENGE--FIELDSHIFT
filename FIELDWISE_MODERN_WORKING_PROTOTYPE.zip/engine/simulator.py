"""What-if simulator for FIELDWISE AI (Member 5)."""
from copy import deepcopy
from engine.climate import compute_et0, day_of_year
from engine.replay import replay_detailed

PRESETS = {'baseline': (0, 0.0), 'drought': (-20, 0.5), 'heat_stress': (0, 2.0), 'heavy_rain': (20, 0.0)}

def _error(code, message): return {'status':'error','code':code,'message':message}

def _mean_score(d):
    c = d.get('cycles', []) if isinstance(d, dict) else []
    return sum(x['score'] for x in c)/len(c) if c else None

def simulate(rotation, farm, climate, history, scenario):
    try:
        name = scenario.get('name', 'custom') if isinstance(scenario, dict) else None
        if name in PRESETS: rain_pct, temp_c = PRESETS[name]
        elif name == 'custom': rain_pct, temp_c = scenario.get('rain_change_pct'), scenario.get('temp_change_c')
        else: return _error('invalid_choice', 'unknown scenario')
        if rain_pct is None or temp_c is None or not -20 <= rain_pct <= 20 or not 0 <= temp_c <= 2:
            return _error('out_of_range', 'scenario values out of range')
        changed = deepcopy(history); d = changed['daily']
        for i, ds in enumerate(d['date']):
            if d['rain_mm'][i] is not None: d['rain_mm'][i] *= 1 + rain_pct/100
            for k in ('tmax_c','tmin_c','tmean_c'):
                if d[k][i] is not None: d[k][i] += temp_c
            d['et0_mm'][i] = compute_et0(d['tmax_c'][i], d['tmin_c'][i], farm.get('latitude'), day_of_year(ds))
        base = replay_detailed(rotation, farm, history); scen = replay_detailed(rotation, farm, changed)
        if base.get('status') != 'success': return base
        if scen.get('status') != 'success': return scen
        bs, ss = _mean_score(base), _mean_score(scen); change = None if bs is None or ss is None else ss-bs
        by_crop=[]
        for crop in rotation:
            vals=[c['relative_yield'] for cyc in scen['cycles'] for c in cyc['crops'] if c['crop']==crop]
            by_crop.append({'crop':crop,'relative_yield':sum(vals)/len(vals) if vals else None})
        explanation=[]
        if change is not None and abs(change) <= 2: explanation.append({'code':'scenario_small_effect','params':{}})
        else:
            base_crop={}
            for crop in rotation:
                vals=[c['relative_yield'] for cyc in base['cycles'] for c in cyc['crops'] if c['crop']==crop]
                base_crop[crop]=sum(vals)/len(vals) if vals else None
            losses=[(crop, base_crop[crop]-r['relative_yield']) for crop,r in zip(rotation,by_crop) if base_crop[crop] is not None and r['relative_yield'] is not None]
            if losses:
                crop, loss=max(losses,key=lambda x:x[1]); explanation.append({'code':'scenario_hurts_crop','params':{'crop':crop,'pct':round(max(0,loss)*100,1)}})
        return {'status':'success','scenario':{'name':name,'rain_change_pct':rain_pct,'temp_change_c':temp_c},
                'rotation':rotation,'baseline_score':bs,'scenario_score':ss,'score_change':change,
                'by_crop':by_crop,'explanation':explanation,'note':{'code':'whatif_not_forecast','params':{}}}
    except Exception as e: return _error('internal_error',f'simulate failed: {type(e).__name__}: {e}')
