"""
engine/season_stats.py  -  Member 2   (the MOST IMPORTANT function in the project)
crop_season_stats(daily, crop_params, sow_date): for ONE crop sown on ONE date, add up
what the weather did to it: water need, rain, heat, frost, growing degree days.
Members 3 and 5 both call this, so live analysis and history replay use the same logic.
Unknown (None) weather days are skipped, never treated as 0.
"""
from datetime import date, timedelta

REQUIRED = ['stage_ini_days', 'stage_dev_days', 'stage_mid_days', 'stage_late_days',
            'kc_ini', 'kc_mid', 'kc_end', 'tbase_c', 'heat_threshold_flowering_c',
            'frost_threshold_c', 'flowering_start_day', 'flowering_end_day']
DAILY_KEYS = ['date', 'tmax_c', 'tmin_c', 'tmean_c', 'rain_mm', 'et0_mm']
WATERLOG_MM = 50      # ASSUMPTION: a day with more than 50 mm rain is a waterlogging day


def _error(code, message):
    return {'status': 'error', 'code': code, 'message': message}


def effective_rain_month(p):
    """USDA-SCS: the part of a month's rain (mm) that the crop can really use. ASSUMPTION."""
    return p * (125 - 0.2 * p) / 125 if p <= 250 else 125 + 0.1 * p


def _find_index(dates, target):
    """Position of a date string in the daily list (fast guess, then a slow search)."""
    try:
        guess = (date.fromisoformat(target) - date.fromisoformat(dates[0])).days
        if 0 <= guess < len(dates) and dates[guess] == target:
            return guess
        return dates.index(target)
    except ValueError:
        return None


def _kc(d, p):
    """Crop coefficient on day d after sowing: flat, rising line, flat, falling line."""
    ini, dev = p['stage_ini_days'], p['stage_dev_days']
    mid, late = p['stage_mid_days'], p['stage_late_days']
    if d < ini:
        return p['kc_ini']
    if d < ini + dev:
        return p['kc_ini'] + (p['kc_mid'] - p['kc_ini']) * (d - ini) / dev
    if d < ini + dev + mid:
        return p['kc_mid']
    return p['kc_mid'] + (p['kc_end'] - p['kc_mid']) * (d - ini - dev - mid) / late


def crop_season_stats(daily, crop_params, sow_date):
    """Contract: crop_season_stats(daily, crop_params, sow_date) -> season_stats."""
    try:
        if not isinstance(daily, dict) or not all(daily.get(k) for k in DAILY_KEYS):
            return _error('missing_data', f'Daily weather needs these lists: {DAILY_KEYS}')
        if not isinstance(crop_params, dict):
            return _error('missing_data', 'crop_params must be a dict.')
        missing = [k for k in REQUIRED if crop_params.get(k) is None]
        if missing:
            return _error('missing_data', f'Crop parameters missing (None): {missing}')
        try:
            sow = date.fromisoformat(str(sow_date))
        except ValueError:
            return _error('invalid_date', "sow_date must look like 'YYYY-MM-DD'.")

        p = crop_params
        length = (p['stage_ini_days'] + p['stage_dev_days']
                  + p['stage_mid_days'] + p['stage_late_days'])
        harvest = sow + timedelta(days=length)       # season days are sow .. harvest-1
        result = {'status': 'success', 'crop': p.get('crop'), 'season': p.get('season'),
                  'sow_date': sow.isoformat(), 'harvest_date': harvest.isoformat(),
                  'etc_mm': None, 'effective_rain_mm': None, 'gdd': None,
                  'heat_days_flowering': None, 'frost_days': None, 'waterlog_days': None,
                  'season_completed': False}

        dates = daily['date']
        i0 = _find_index(dates, sow.isoformat())
        if i0 is None:                    # sowing date is not inside the data
            return result
        n = min(length, len(dates) - i0)  # days of the season we really have
        waterlog_on = p.get('waterlogging_sensitive') is True   # ASSUMPTION: None = not sensitive

        etc = gdd = 0.0
        n_etc = n_gdd = n_tx = n_tn = n_rain = 0
        heat = frost = waterlog = 0
        month_rain = {}
        for d in range(n):
            i = i0 + d
            et0, tmean = daily['et0_mm'][i], daily['tmean_c'][i]
            tmax, tmin, rain = daily['tmax_c'][i], daily['tmin_c'][i], daily['rain_mm'][i]
            if et0 is not None:
                etc += _kc(d, p) * et0
                n_etc += 1
            if tmean is not None:
                gdd += max(tmean - p['tbase_c'], 0)
                n_gdd += 1
            if tmax is not None:
                n_tx += 1
                if p['flowering_start_day'] <= d <= p['flowering_end_day'] \
                        and tmax > p['heat_threshold_flowering_c']:
                    heat += 1
            if tmin is not None:
                n_tn += 1
                if tmin < p['frost_threshold_c']:
                    frost += 1
            if rain is not None:
                n_rain += 1
                month = dates[i][:7]
                month_rain[month] = month_rain.get(month, 0.0) + rain
                if waterlog_on and rain > WATERLOG_MM:
                    waterlog += 1

        result.update({
            'etc_mm': round(etc, 2) if n_etc else None,
            'effective_rain_mm': round(sum(effective_rain_month(m) for m in month_rain.values()), 2)
                                 if n_rain else None,
            'gdd': round(gdd, 2) if n_gdd else None,
            'heat_days_flowering': heat if n_tx else None,
            'frost_days': frost if n_tn else None,
            'waterlog_days': (waterlog if n_rain else None) if waterlog_on else 0,
            'season_completed': n == length,
        })
        return result
    except Exception as e:
        return _error('internal_error', f'crop_season_stats failed: {type(e).__name__}: {e}')
