"""Tests for engine/climate.py.  Run: python -m pytest tests/test_climate.py"""
from engine.climate import (compute_et0, day_of_year, mean_ignore_none, linear_slope,
                            slot_of_date, extraterrestrial_radiation)

def test_none_input_gives_none():
    assert compute_et0(None, 10, 29.2, 100) is None
    assert compute_et0(30, None, 29.2, 100) is None
    assert compute_et0(30, 10, None, 100) is None
    assert compute_et0(30, 10, 29.2, None) is None

def test_et0_never_negative():
    assert compute_et0(-5, -20, 29.2, 15) >= 0        # very cold
    assert compute_et0(10, 20, 29.2, 100) >= 0        # tmax below tmin (bad data)

def test_et0_bigger_in_june_than_january():
    june = compute_et0(35, 22, 29.2, day_of_year('2020-06-15'))
    jan = compute_et0(35, 22, 29.2, day_of_year('2020-01-15'))
    assert june > jan > 0

def test_radiation_matches_fao56_worked_example():
    # FAO-56 Example 8: latitude 20 S, 3 September (day 246) -> Ra = 32.2 MJ/m2/day
    assert abs(extraterrestrial_radiation(-20, 246) - 32.2) < 0.3

def test_mean_ignore_none_skips_none():
    assert mean_ignore_none([1, None, 3]) == 2
    assert mean_ignore_none([None, None]) is None

def test_linear_slope():
    assert abs(linear_slope([1, 2, 3], [2, 4, 6]) - 2.0) < 1e-9
    assert abs(linear_slope([1, 2, 3], [1, None, 3]) - 1.0) < 1e-9
    assert linear_slope([1], [5]) is None

def test_day_of_year_and_slots():
    assert day_of_year('2021-03-01') == 60
    assert day_of_year('not a date') is None
    assert slot_of_date('2020-06-01') == 'kharif' and slot_of_date('2020-10-14') == 'kharif'
    assert slot_of_date('2020-10-15') == 'rabi' and slot_of_date('2021-03-15') == 'rabi'
    assert slot_of_date('2020-03-16') == 'zaid' and slot_of_date('2020-05-31') == 'zaid'
