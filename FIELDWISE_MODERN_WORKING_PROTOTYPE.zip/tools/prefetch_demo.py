"""
tools/prefetch_demo.py  -  Member 2
Downloads real NASA data ONCE for the 3 demo farms (saved in data/cache/) so the demo
still works if the internet fails. Also writes data/demo_farms.json.
Run from the project folder:   python tools/prefetch_demo.py      (needs internet)
"""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))          # so "from engine..." works when run as a script

DEMO_FILE = ROOT / 'data' / 'demo_farms.json'
CROPS_CSV = ROOT / 'data' / 'crops.csv'

DEMO_FARMS = [
    {'name': 'Terai Uttarakhand', 'latitude': 29.2, 'longitude': 79.5, 'area_ha': 1.5,
     'soil_type': 'loamy', 'irrigation': 'borewell', 'water_availability': 'medium',
     'start_season': 'rabi', 'previous_crops': ['mungbean', 'rice'],
     'current_plan': ['wheat', 'mungbean', 'rice'], 'priority': 'balanced', 'language': 'en'},
    {'name': 'Ludhiana Punjab', 'latitude': 30.9, 'longitude': 75.85, 'area_ha': 1.5,
     'soil_type': 'loamy', 'irrigation': 'canal', 'water_availability': 'high',
     'start_season': 'rabi', 'previous_crops': ['mungbean', 'rice'],
     'current_plan': [], 'priority': 'balanced', 'language': 'en'},
    {'name': 'Nagpur Maharashtra', 'latitude': 21.15, 'longitude': 79.09, 'area_ha': 1.5,
     'soil_type': 'clay', 'irrigation': 'rainfed', 'water_availability': 'low',
     'start_season': 'kharif', 'previous_crops': ['chickpea', 'mungbean'],
     'current_plan': ['soybean', 'chickpea', 'mungbean'], 'priority': 'balanced',
     'language': 'en'},
]


def write_demo_farms(path=DEMO_FILE):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({'farms': DEMO_FARMS}, indent=2))


def crop_name_warnings(farms, csv_path=CROPS_CSV):
    """Warn about crop names that are not in data/crops.csv (only if that file exists)."""
    if not Path(csv_path).exists():
        return []
    with open(csv_path, newline='', encoding='utf-8') as f:
        known = {row.get('crop', '').strip().lower() for row in csv.DictReader(f)}
    warnings = []
    for farm in farms:
        for crop in farm['previous_crops'] + farm['current_plan']:
            if crop not in known:
                warnings.append(f"WARNING: '{crop}' ({farm['name']}) is not in crops.csv")
    return warnings


def main():
    from engine.nasa_api import get_history
    for farm in DEMO_FARMS:
        h = get_history(farm['latitude'], farm['longitude'])
        if h.get('status') == 'success':
            dq = h['data_quality']
            print(f"{farm['name']}: status=success, days={len(h['daily']['date'])}, "
                  f"missing_pct={dq['missing_pct']}, from_cache={dq['from_cache']}")
        else:
            print(f"{farm['name']}: status=error, code={h.get('code')}, {h.get('message')}")
    write_demo_farms()
    print(f"Wrote {DEMO_FILE}")
    for w in sorted(set(crop_name_warnings(DEMO_FARMS))):
        print(w)


if __name__ == '__main__':
    main()
