(function () {
  "use strict";

  const SEASONS = ["kharif", "rabi", "zaid"];
  let cropRows = [];
  let demoFarms = [];
  let map = null;
  let marker = null;
  let progressTimer = null;

  const byId = (id) => document.getElementById(id);

  function rotationSlots(startSeason) {
    const start = SEASONS.indexOf(startSeason);
    if (start < 0) return SEASONS.slice();
    return [0, 1, 2].map((offset) => SEASONS[(start + offset) % SEASONS.length]);
  }

  function uniqueCrops() {
    return [...new Set(cropRows.map((row) => row.crop).filter(Boolean))].sort();
  }

  function setOptions(select, crops, placeholder) {
    const oldValue = select.value;
    select.replaceChildren();
    const blank = document.createElement("option");
    blank.value = "";
    blank.textContent = placeholder;
    select.appendChild(blank);
    crops.forEach((crop) => {
      const option = document.createElement("option");
      option.value = crop;
      option.textContent = crop;
      select.appendChild(option);
    });
    if (crops.includes(oldValue)) select.value = oldValue;
  }

  function fillPreviousCropDropdowns() {
    const crops = uniqueCrops();
    setOptions(byId("previous_crop_1"), crops, "Choose crop");
    setOptions(byId("previous_crop_2"), crops, "Choose crop");
  }

  function renderCurrentPlan(values) {
    const slots = rotationSlots(byId("start_season").value);
    const holder = byId("current-plan-fields");
    const existing = values || [...holder.querySelectorAll("select")].map((el) => el.value);
    holder.replaceChildren();

    slots.forEach((slot, index) => {
      const wrap = document.createElement("div");
      const label = document.createElement("label");
      const select = document.createElement("select");
      label.htmlFor = `current_plan_${index}`;
      label.textContent = `${slot[0].toUpperCase()}${slot.slice(1)} crop`;
      select.id = `current_plan_${index}`;
      select.dataset.slot = slot;
      const valid = [...new Set(cropRows.filter((row) => row.season === slot).map((row) => row.crop))].sort();
      setOptions(select, valid, "No crop / choose crop");
      if (existing[index] && valid.includes(existing[index])) select.value = existing[index];
      wrap.append(label, select);
      holder.appendChild(wrap);
    });
  }

  function showPageNotice(text) {
    const notice = byId("page-notice");
    notice.textContent = text;
    notice.hidden = !text;
  }

  async function loadCrops() {
    const response = await fetch("/api/crops");
    const data = await response.json();
    if (!response.ok || data.status === "error" || !Array.isArray(data.rows)) throw new Error(data.message || "Could not load crops.");
    cropRows = data.rows;
    fillPreviousCropDropdowns();
    renderCurrentPlan();
  }

  function demoName(farm, index) {
    return farm.name || `Demo farm ${index + 1}`;
  }

  async function loadDemoFarms() {
    const response = await fetch("/api/demo-farms");
    const data = await response.json();
    if (!response.ok || data.status === "error" || !Array.isArray(data.farms)) throw new Error(data.message || "Could not load demo farms.");
    demoFarms = data.farms.slice(0, 3);
    const holder = byId("demo-buttons");
    holder.replaceChildren();
    demoFarms.forEach((farm, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "btn btn-secondary";
      button.textContent = demoName(farm, index);
      button.addEventListener("click", () => fillFarm(farm));
      holder.appendChild(button);
    });
    if (!demoFarms.length) holder.textContent = "No demo farms available.";
  }

  function setMapLocation(latitude, longitude) {
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || !map) return;
    const point = [latitude, longitude];
    if (!marker) marker = L.marker(point).addTo(map);
    else marker.setLatLng(point);
    map.setView(point, Math.max(map.getZoom(), 8));
  }

  function initMap() {
    map = L.map("farm-map").setView([22.5, 79.0], 5); // India overview only; not farm data.
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap contributors"
    }).addTo(map);
    map.on("click", (event) => {
      byId("latitude").value = event.latlng.lat.toFixed(6);
      byId("longitude").value = event.latlng.lng.toFixed(6);
      setMapLocation(event.latlng.lat, event.latlng.lng);
    });
  }

  function fillFarm(farm) {
    ["name", "latitude", "longitude", "area_ha", "soil_type", "irrigation", "water_availability", "start_season", "priority", "language"].forEach((field) => {
      if (farm[field] !== undefined && farm[field] !== null) byId(field).value = farm[field];
    });
    const previous = Array.isArray(farm.previous_crops) ? farm.previous_crops : [];
    byId("previous_crop_1").value = previous[0] || "";
    byId("previous_crop_2").value = previous[1] || "";
    renderCurrentPlan(Array.isArray(farm.current_plan) ? farm.current_plan : []);
    setMapLocation(Number(farm.latitude), Number(farm.longitude));
    clearMessages();
  }

  function readFarm() {
    const plan = [...byId("current-plan-fields").querySelectorAll("select")].map((el) => el.value).filter(Boolean);
    return {
      name: byId("name").value.trim(),
      latitude: Number(byId("latitude").value),
      longitude: Number(byId("longitude").value),
      area_ha: Number(byId("area_ha").value),
      soil_type: byId("soil_type").value,
      irrigation: byId("irrigation").value,
      water_availability: byId("water_availability").value,
      start_season: byId("start_season").value,
      previous_crops: [byId("previous_crop_1").value, byId("previous_crop_2").value].filter(Boolean),
      current_plan: plan.length === 0 ? [] : plan,
      priority: byId("priority").value,
      language: byId("language").value
    };
  }

  function clearMessages() {
    document.querySelectorAll(".err").forEach((el) => { el.textContent = ""; });
    byId("warnings").replaceChildren();
    showPageNotice("");
  }

  async function translate(message, lang) {
    if (typeof window.t !== "function") return message.code || "Validation error";
    return await window.t(message, lang);
  }

  async function showValidationErrors(errors, lang) {
    for (const error of errors || []) {
      const target = byId(`err-${error.field}`) || byId("form-error");
      const text = await translate({ code: error.code, params: {} }, lang);
      target.textContent = target.textContent ? `${target.textContent} ${text}` : text;
    }
  }

  async function showWarnings(warnings, lang) {
    const holder = byId("warnings");
    holder.replaceChildren();
    for (const warning of warnings || []) {
      const notice = document.createElement("div");
      notice.className = "banner warning-banner";
      notice.textContent = await translate(warning, lang);
      holder.appendChild(notice);
    }
  }

  function startProgress() {
    const box = byId("progress");
    const items = [...box.querySelectorAll("li")];
    let active = 0;
    box.hidden = false;
    items.forEach((item) => item.classList.remove("active", "done"));
    if (items[0]) items[0].classList.add("active");
    clearInterval(progressTimer);
    progressTimer = setInterval(() => {
      if (active < items.length - 1) {
        items[active].classList.remove("active");
        items[active].classList.add("done");
        active += 1;
        items[active].classList.add("active");
      }
    }, 3000);
  }

  function stopProgress() {
    clearInterval(progressTimer);
    progressTimer = null;
  }

  async function validateFarm(farm) {
    const response = await fetch("/api/validate-farm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(farm)
    });
    const data = await response.json();
    if (!response.ok && !data.status) throw new Error(data.message || "Validation request failed.");
    return data;
  }

  async function analyzeFarm(farm) {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(farm)
    });
    const data = await response.json();
    if (!response.ok || data.status !== "success") throw new Error(data.message || "Analysis failed.");
    return data;
  }

  async function submitFarm(event) {
    event.preventDefault();
    clearMessages();
    const button = byId("analyze-button");
    button.disabled = true;
    const farm = readFarm();
    try {
      const validation = await validateFarm(farm);
      await showWarnings(validation.warnings, farm.language);
      if (validation.status === "error") {
        await showValidationErrors(validation.errors, farm.language);
        return;
      }
      startProgress();
      const result = await analyzeFarm(validation.farm);
      sessionStorage.setItem("fw_result", JSON.stringify(result));
      window.location.href = "/dashboard";
    } catch (error) {
      byId("form-error").textContent = error.message || "Something went wrong.";
    } finally {
      stopProgress();
      button.disabled = false;
    }
  }

  function useLocation() {
    if (!navigator.geolocation) {
      byId("form-error").textContent = "Geolocation is not supported by this browser.";
      return;
    }
    navigator.geolocation.getCurrentPosition((position) => {
      const latitude = position.coords.latitude;
      const longitude = position.coords.longitude;
      byId("latitude").value = latitude.toFixed(6);
      byId("longitude").value = longitude.toFixed(6);
      setMapLocation(latitude, longitude);
    }, () => {
      byId("form-error").textContent = "Location permission was unavailable. Choose the farm on the map or enter coordinates.";
    });
  }

  async function boot() {
    initMap();
    byId("farm-form").addEventListener("submit", submitFarm);
    byId("start_season").addEventListener("change", () => renderCurrentPlan());
    byId("use-location").addEventListener("click", useLocation);
    byId("language").addEventListener("change", () => {
      if (typeof window.setLanguage === "function") window.setLanguage(byId("language").value);
    });
    try {
      await Promise.all([loadCrops(), loadDemoFarms()]);
    } catch (error) {
      showPageNotice(`${error.message} Ask the team leader to enable the required API endpoints.`);
    }
  }

  document.addEventListener("DOMContentLoaded", boot);
}());
