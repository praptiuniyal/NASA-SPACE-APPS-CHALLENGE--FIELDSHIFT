import json
from pathlib import Path
import engine.gpm_api as g


def test_normalise_and_summary_recent_windows():
    rows=[{"date":f"2026-10-{d:02d}","rain_mm":d} for d in range(1,31)]
    x=g._summarise(rows,29.2,79.5,False)
    assert x["status"]=="success"
    assert x["recent_7d_rain_mm"]==sum(range(24,31))
    assert x["recent_30d_rain_mm"]==sum(range(1,31))
    assert x["from_cache"] is False


def test_negative_or_bad_values_are_excluded():
    rows=g._normalise_rows([{"date":"2026-10-01","rain_mm":"5"},{"date":"bad","rain_mm":2},{"date":"2026-10-02","rain_mm":-1}])
    assert rows==[{"date":"2026-10-01","rain_mm":5.0}]


def test_cache_fallback(monkeypatch,tmp_path):
    monkeypatch.setattr(g,"CACHE_DIR",tmp_path)
    p=g._cache_path(29.2,79.5); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps({"rows":[{"date":"2026-10-01","rain_mm":10},{"date":"2026-10-02","rain_mm":20}]}))
    x=g.get_gpm_context(29.2,79.5)
    assert x["status"]=="success" and x["from_cache"] is True


def test_no_cache_no_service_is_explicit_error(monkeypatch,tmp_path):
    monkeypatch.setattr(g,"CACHE_DIR",tmp_path)
    monkeypatch.delenv("FIELDWISE_GPM_POINT_URL",raising=False)
    x=g.get_gpm_context(29.2,79.5)
    assert x["status"]=="error" and x["code"]=="gpm_unavailable"


def test_evidence_consistency_never_pretends_recent_is_climatology():
    x=g.evidence_consistency({"status":"success","rain_state":"dry"},{"summary":{"rain_annual_mm":1200}})
    assert x["level"]=="context_only"
    assert any(m["code"]=="gpm_power_different_timescales" for m in x["messages"])
