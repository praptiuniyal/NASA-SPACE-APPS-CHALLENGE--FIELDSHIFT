from engine.farmer_card import build_farmer_card
def fixtures():
    farm={"language":"en"}
    rotations=[{"rotation":["wheat","mungbean","rice"],"slots":["rabi","zaid","kharif"],"final_score":86,"warnings":[]}]
    replays=[{"survival_rate":0.9}]
    nasa={"fetched_on":"2026-11-13"}
    return farm,rotations,replays,nasa
def test_farmer_card_exact_keys_and_values():
    f,r,p,n=fixtures(); c=build_farmer_card(f,r,p,{"status":"success","difference":{"water_m3_per_ha":-800}},n)
    assert set(c)=={"language","headline","rotation","three_numbers","warnings","footer"}
    assert c["three_numbers"]=={"survival_rate":0.9,"water_saved_m3_per_ha":800,"score":86}
    assert c["rotation"][0]=={"slot":"rabi","crop":"wheat"}
def test_no_plan_water_saved_zero():
    f,r,p,n=fixtures(); c=build_farmer_card(f,r,p,{"status":"no_plan","difference":{"water_m3_per_ha":None}},n)
    assert c["three_numbers"]["water_saved_m3_per_ha"]==0
def test_positive_water_difference_does_not_claim_savings():
    f,r,p,n=fixtures(); c=build_farmer_card(f,r,p,{"status":"success","difference":{"water_m3_per_ha":300}},n)
    assert c["three_numbers"]["water_saved_m3_per_ha"]==0
