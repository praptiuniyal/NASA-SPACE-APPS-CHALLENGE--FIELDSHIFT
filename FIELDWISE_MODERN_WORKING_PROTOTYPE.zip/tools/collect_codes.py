import argparse,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
MANUAL_CODES=['regret_main_climate','regret_main_water','regret_main_soil','regret_main_diversity','regret_main_compatibility','regret_main_resilience']
PAT=re.compile(r"['\"]code['\"]\s*:\s*['\"]([a-z0-9_]+)['\"]")
def used_codes():
    codes=set(MANUAL_CODES)
    for p in list((ROOT/'engine').glob('*.py'))+[ROOT/'app.py']:
        codes.update(PAT.findall(p.read_text(encoding='utf-8')))
    return codes
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--fill',action='store_true'); a=ap.parse_args(); codes=used_codes()
    files=[ROOT/'static/i18n/en.json']; hi=ROOT/'static/i18n/hi.json'
    if hi.exists(): files.append(hi)
    bad=False
    for p in files:
        data=json.loads(p.read_text(encoding='utf-8')); missing=sorted(codes-set(data))
        print(p.name,'missing:',', '.join(missing) if missing else 'none')
        if a.fill and p.name=='en.json' and missing:
            for c in missing:data[c]=c.replace('_',' ').capitalize()
            p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        elif missing: bad=True
    return 1 if bad and not a.fill else 0
if __name__=='__main__': raise SystemExit(main())
