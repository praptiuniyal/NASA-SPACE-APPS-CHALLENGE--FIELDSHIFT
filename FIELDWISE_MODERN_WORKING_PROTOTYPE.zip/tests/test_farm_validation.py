from engine.farm_validation import validate_farm


def valid_farm():
    return {
        "name": "Demo Farm",
        "latitude": 28.6,
        "longitude": 77.2,
        "area_ha": 2.0,
        "soil_type": "loamy",
        "irrigation": "canal",
        "water_availability": "medium",
        "start_season": "rabi",
        "previous_crops": ["rice", "mungbean"],
        "current_plan": ["wheat", "mungbean", "rice"],
        "priority": "balanced",
        "language": "en",
    }


CROP_ROWS = [
    {"crop": "rice", "season": "kharif"},
    {"crop": "wheat", "season": "rabi"},
    {"crop": "mungbean", "season": "zaid"},
]


def has_error(result, field, code):
    return {"field": field, "code": code} in result["errors"]


def test_bad_latitude():
    farm = valid_farm()
    farm["latitude"] = 91
    result = validate_farm(farm, CROP_ROWS)
    assert result["status"] == "error"
    assert has_error(result, "latitude", "out_of_range")


def test_area_zero():
    farm = valid_farm()
    farm["area_ha"] = 0
    result = validate_farm(farm, CROP_ROWS)
    assert has_error(result, "area_ha", "must_be_positive")


def test_wrong_enum():
    farm = valid_farm()
    farm["soil_type"] = "rocky"
    result = validate_farm(farm, CROP_ROWS)
    assert has_error(result, "soil_type", "invalid_choice")


def test_three_previous_crops():
    farm = valid_farm()
    farm["previous_crops"] = ["rice", "wheat", "mungbean"]
    result = validate_farm(farm, CROP_ROWS)
    assert has_error(result, "previous_crops", "wrong_length")


def test_rainfed_forces_low():
    farm = valid_farm()
    farm["irrigation"] = "rainfed"
    farm["water_availability"] = "high"
    result = validate_farm(farm, CROP_ROWS)
    assert result["farm"]["water_availability"] == "low"
    assert {"code": "rainfed_forces_low", "params": {}} in result["warnings"]


def test_outside_india():
    farm = valid_farm()
    farm["latitude"] = 40
    farm["longitude"] = 100
    result = validate_farm(farm, CROP_ROWS)
    assert {"code": "outside_india", "params": {}} in result["warnings"]


def test_valid_farm():
    result = validate_farm(valid_farm(), CROP_ROWS)
    assert result["status"] == "success"
    assert result["errors"] == []


def test_bad_current_plan_slot():
    farm = valid_farm()
    farm["current_plan"] = ["wheat", "wheat", "rice"]
    result = validate_farm(farm, CROP_ROWS)
    assert has_error(result, "current_plan[1]", "crop_wrong_slot")


def test_unknown_crop():
    farm = valid_farm()
    farm["current_plan"] = ["wheat", "mysterycrop", "rice"]
    result = validate_farm(farm, CROP_ROWS)
    assert has_error(result, "current_plan[1]", "unknown_crop")


def test_optional_empty_fields_are_defaulted():
    farm = valid_farm()
    farm["current_plan"] = None
    farm["language"] = ""
    result = validate_farm(farm, CROP_ROWS)
    assert result["farm"]["current_plan"] == []
    assert result["farm"]["language"] == "en"
    assert "current_plan" in result["defaulted_fields"]
    assert "language" in result["defaulted_fields"]
