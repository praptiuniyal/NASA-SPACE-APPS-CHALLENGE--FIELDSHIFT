# FIELDWISE working prototype — modern analysis workspace

This is a **real Flask-connected HTML/CSS/JavaScript dashboard**, not a standalone fake-data HTML file.

- `templates/dashboard.html`: semantic responsive workspace layout.
- `static/dashboard-modern.css`: scoped responsive visual system.
- `static/js/dashboard.js`: reads the real analysis response from `sessionStorage["fw_result"]` (written by the farm form) or the Flask `/api/mock` fallback; calls the existing `/api/simulate` route; uses `reweight.js`, `farmer_card.js`, `i18n.js`, and Chart.js.
- `app.py` and `engine/`: original working Flask/Python engine, unchanged.

## Run

```powershell
python -m pip install -r requirements.txt
python -m pytest
python app.py
```

Open `http://127.0.0.1:5000/`, choose a demo farm, then Analyze. The dashboard is at `/dashboard`.

## Data honesty

`app.py` currently sets `USE_MOCK = True`. In that mode the dashboard explicitly shows DEMONSTRATION MODE and values from `docs/mock/analyze_response.json`; **those values are not NASA observations**. Set `USE_MOCK = False` only after confirming real `/api/analyze` succeeds with valid crop rotations. The Terai demo was previously observed to produce no feasible zaid rotation under the current crop screening assumptions, and that real limitation should not be concealed. Real NASA POWER cache is included. GPM/IMERG panel displays unavailable until real IMERG observations are imported; no rainfall is invented.

The HTML must be served by Flask. Opening `templates/dashboard.html` directly as `file://` will not run the API-backed features.
