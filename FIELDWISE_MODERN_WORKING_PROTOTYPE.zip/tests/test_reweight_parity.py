import json, random, shutil, subprocess
from pathlib import Path
import pytest
from engine.scoring import reweight

def test_reweight_parity_20_random_cases():
    node=shutil.which("node")
    if not node: pytest.skip("node is not installed")
    js=Path(__file__).resolve().parents[1]/"static"/"js"/"reweight.js"
    rng=random.Random(42)
    keys=["climate","water","soil","diversity","compatibility","resilience"]
    for _ in range(20):
        comp={k:rng.uniform(0,100) for k in keys}
        weights={k:rng.uniform(0,5) for k in keys}
        py=reweight(comp,weights)
        code=f"const x=require({json.dumps(str(js))}); console.log(JSON.stringify(x.reweight({json.dumps(comp)},{json.dumps(weights)})));"
        jsval=json.loads(subprocess.check_output([node,"-e",code],text=True).strip())
        assert abs(py-jsval)<0.01
