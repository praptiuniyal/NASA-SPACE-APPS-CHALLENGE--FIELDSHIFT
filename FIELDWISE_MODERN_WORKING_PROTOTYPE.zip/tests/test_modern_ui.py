from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_dashboard_runtime_hooks_and_assets():
    html=(ROOT/'templates/dashboard.html').read_text(encoding='utf-8')
    js=(ROOT/'static/js/dashboard.js').read_text(encoding='utf-8')
    for section in ('overview','rotations','evidence','replay','scenario','trust'):
        assert f'id="{section}"' in html
    for element in ('mockBanner','gpmPanel','rotationCards','replayChart','dnaChart','whatIfChart','downloadCard'):
        assert f'id="{element}"' in html
    for dependency in ('/static/dashboard-modern.css','/static/js/reweight.js','/static/js/farmer_card.js'):
        assert dependency in html
    assert 'sessionStorage.getItem("fw_result")' in js
    assert 'fetch("/api/mock")' in js
    assert 'fetch("/api/simulate"' in js
    assert 'FW.mock' in js
