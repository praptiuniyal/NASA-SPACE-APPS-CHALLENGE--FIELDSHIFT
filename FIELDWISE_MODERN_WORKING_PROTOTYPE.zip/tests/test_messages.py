import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MANUAL={'regret_main_climate','regret_main_water','regret_main_soil','regret_main_diversity','regret_main_compatibility','regret_main_resilience'}
PAT=re.compile(r"['\"]code['\"]\s*:\s*['\"]([a-z0-9_]+)['\"]")
def codes():
    out=set(MANUAL)
    for p in list((ROOT/'engine').glob('*.py'))+[ROOT/'app.py']:out.update(PAT.findall(p.read_text(encoding='utf-8')))
    return out
def test_all_python_message_codes_are_translated():
    used=codes()
    for p in [ROOT/'static/i18n/en.json',ROOT/'static/i18n/hi.json']:
        if p.exists():
            data=json.loads(p.read_text(encoding='utf-8')); assert not (used-set(data)), f'{p.name} missing {sorted(used-set(data))}'
