# FIELDWISE AI submission pack

## ~150-word project summary
FIELDWISE AI helps farmers choose a resilient three-season crop rotation instead of recommending only one crop. A farmer enters farm location, soil, water availability and recent crops. The system uses NASA POWER daily weather history and transparent agronomic calculations to score crop options, build rotations and replay each plan across historical weather cycles. It reports a survival rate, compares the recommendation with the farmer's current plan, shows water and reference-income estimates, and explains the reasons behind each score. Farmers can change priority weights, test drought, heat or heavy-rain what-if scenarios, inspect regret and worst-year results, and download a shareable Farmer Card. Every value is labelled by provenance: NASA data, farmer input, reference estimate or modelling assumption. FIELDWISE deliberately presents replay results as model evidence rather than harvest records or yield promises. The project is designed around explainable maths, cached NASA data for offline demos, validation checks and honest documentation of limitations and assumptions.

## NASA data used
NASA POWER daily point data: T2M, T2M_MAX, T2M_MIN, PRECTOTCORR, ALLSKY_SFC_SW_DWN, RH2M, WS2M and GWETROOT; default analysis uses the last 30 complete calendar years.

## 7-slide pitch outline
1. **Problem** — Farmers need a multi-season plan that can survive bad years, not a black-box single-crop answer.
2. **FIELDWISE AI** — Three-season rotation advice with explanations, current-plan comparison and a shareable Farmer Card.
3. **How it works** — Farmer input → NASA POWER → crop suitability → rotation scoring → 30-year replay → resilience → dashboard.
4. **NASA is the engine** — Show the NASA provenance panel and the real cached 30-year daily record. Insert real `[YEARS]`, `[DAYS]` after final run.
5. **Proof, not just a recommendation** — Show recommended rotation, replay chart and `[RECOMMENDED_SURVIVAL]` versus `[CURRENT_SURVIVAL]`.
6. **Trust and validation** — Transparent formulas, validation report, assumptions, what-if/regret, and honest limits.
7. **Impact & team** — Water-aware planning, farmer-friendly card, English/Hindi direction, team roles and next steps.

## 3-minute demo script
- **0:00-0:15 Problem:** “Most crop recommenders give one crop. FIELDWISE asks what three-season rotation is most resilient when weather is bad.”
- **0:15-0:35 Farm:** Open a pre-cached demo farm, point out map, soil, water and current plan, then Analyze.
- **0:35-0:55 NASA:** Show the NASA panel. Say the actual final `[YEARS]`, `[DAYS]`, variables and cache status from the demo result.
- **0:55-1:25 Recommendation:** Show the top rotation and compare its actual final score, water estimate and current-plan difference.
- **1:25-2:05 Replay:** Focus on the historical replay chart. State actual `[SURVIVED_X_OF_Y]`. Emphasize “model replay, not harvest records.”
- **2:05-2:25 Sliders:** Change priority weights and show live re-ranking without rerunning NASA.
- **2:25-2:45 Drought/regret:** Run drought what-if and show the actual score change/regret result.
- **2:45-3:00 Farmer Card:** Download the Farmer Card and close with transparent provenance and offline cached NASA data.

## AI-use statement
We used AI coding assistants to help translate our shared software/data contract into code, tests, documentation and integration fixes. We did not treat AI output as evidence by itself. The team tested the code, documented assumptions and data sources, kept model replay separate from real harvest observations, and will only present final numerical results that were produced by the tested application. Individual team members should name the specific AI tools they actually used before submission.
