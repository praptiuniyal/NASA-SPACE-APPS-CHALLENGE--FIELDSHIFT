"""Historical replay and resilience calculations for FIELDWISE AI (Member 5)."""
from datetime import date, timedelta
from statistics import median

SURVIVE_THRESHOLD = 0.6  # ASSUMPTION from shared contract
SLOT_ORDER = ['kharif', 'rabi', 'zaid']


def _error(code, message):
    return {'status': 'error', 'code': code, 'message': message}


def _deps():
    from engine.crop_data import load_crops
    from engine.crop_engine import water_satisfaction
    from engine.season_stats import crop_season_stats
    return load_crops, water_satisfaction, crop_season_stats


def _midpoint(mm_start, mm_end, year):
    sm, sd = map(int, mm_start.split('-')); em, ed = map(int, mm_end.split('-'))
    a = date(year, sm, sd); b = date(year, em, ed)
    if b < a: b = date(year + 1, em, ed)
    return a + (b - a) // 2


def _slot_sequence(start):
    i = SLOT_ORDER.index(start)
    return [SLOT_ORDER[(i + j) % 3] for j in range(3)]


def _next_sow(row, slot, after, first_year=None):
    start, end = row['sowing_window']['start'], row['sowing_window']['end']
    if first_year is not None:
        return _midpoint(start, end, first_year)
    # Find first midpoint strictly after previous harvest.
    for y in range(after.year - 1, after.year + 3):
        d = _midpoint(start, end, y)
        if d >= after:
            return d
    return None


def _p10(values):
    if not values: return None
    s = sorted(values)
    if len(s) == 1: return s[0]
    pos = 0.1 * (len(s) - 1); lo = int(pos); hi = min(lo + 1, len(s) - 1); f = pos - lo
    return s[lo] * (1 - f) + s[hi] * f


def replay_detailed(rotation, farm, history):
    """Return {'status','cycles','years_excluded'}; cycles include per-crop relative yields."""
    try:
        if not isinstance(rotation, list) or len(rotation) != 3:
            return _error('wrong_length', 'rotation must contain exactly 3 crops')
        if history.get('status') != 'success' or not history.get('daily'):
            return _error('missing_data', 'history is unavailable')
        load_crops, water_satisfaction, crop_season_stats = _deps()
        rows = load_crops()
        slots = _slot_sequence(farm['start_season'])
        by_key = {(r['crop'], r['season']): r for r in rows}
        chosen = [by_key.get((c, s)) for c, s in zip(rotation, slots)]
        if any(r is None for r in chosen):
            return _error('unknown_crop', 'rotation crop is missing for its slot')
        dates = history['daily'].get('date', [])
        if not dates: return _error('missing_data', 'history has no dates')
        first_y, last_y = int(dates[0][:4]), int(dates[-1][:4])
        cache = {}; cycles = []; excluded = 0
        for y in range(first_y, last_y + 1):
            crops = []; previous_harvest = None; valid = True
            for idx, (crop, slot, row) in enumerate(zip(rotation, slots, chosen)):
                sow = _next_sow(row, slot, previous_harvest, y if idx == 0 else None)
                if sow is None: valid = False; break
                key = (crop, slot, sow.year, sow.isoformat())
                if key not in cache:
                    cache[key] = crop_season_stats(history['daily'], row, sow.isoformat())
                st = cache[key]
                needed = ['etc_mm','effective_rain_mm','heat_days_flowering','frost_days','waterlog_days']
                if st.get('status') != 'success' or not st.get('season_completed') or any(st.get(k) is None for k in needed):
                    valid = False; break
                ws = water_satisfaction(st, farm)
                if ws is None or row.get('ky') is None:
                    valid = False; break
                ry = max(0.0, min(1.0, 1 - row['ky'] * (1 - ws)))
                ry *= 1 - min(0.5, 0.05 * st['heat_days_flowering'])
                ry *= 1 - min(0.5, 0.10 * st['frost_days'])
                ry *= 1 - min(0.5, 0.05 * st['waterlog_days'])
                ry = max(0.0, min(1.0, ry))
                crops.append({'crop': crop, 'season': slot, 'sow_date': sow.isoformat(), 'relative_yield': ry})
                previous_harvest = date.fromisoformat(st['harvest_date'])
            if valid and len(crops) == 3:
                score = sum(c['relative_yield'] for c in crops) / 3 * 100
                cycles.append({'year': y, 'score': score, 'survived': all(c['relative_yield'] >= SURVIVE_THRESHOLD for c in crops), 'crops': crops})
            else:
                excluded += 1
        return {'status': 'success', 'cycles': cycles, 'years_excluded': excluded}
    except Exception as e:
        return _error('internal_error', f'replay_detailed failed: {type(e).__name__}: {e}')


def replay_history(rotation, farm, history):
    try:
        d = replay_detailed(rotation, farm, history)
        if d.get('status') != 'success': return d
        cycles = d['cycles']; scores = [c['score'] for c in cycles]
        worst = min(cycles, key=lambda c: c['score']) if cycles else None
        return {'status': 'success', 'rotation': rotation, 'years_tested': len(cycles),
                'years_excluded': d['years_excluded'], 'survive_threshold': SURVIVE_THRESHOLD,
                'survival_rate': (sum(c['survived'] for c in cycles) / len(cycles)) if cycles else None,
                'median_score': median(scores) if scores else None, 'p10_score': _p10(scores),
                'worst_year': ({'year': worst['year'], 'score': worst['score']} if worst else None),
                'by_year': [{'year': c['year'], 'score': c['score'], 'survived': c['survived']} for c in cycles]}
    except Exception as e:
        return _error('internal_error', f'replay_history failed: {type(e).__name__}: {e}')


def calculate_resilience(replay_result, scenario_results):
    try:
        sr = replay_result.get('survival_rate'); p10 = replay_result.get('p10_score')
        if sr is None or p10 is None: return None
        drops = []
        for r in scenario_results or []:
            b, ch = r.get('baseline_score'), r.get('score_change')
            if b is not None and ch is not None: drops.append(max(0, -ch) / max(b, 1))
        mean_drop = min(1.0, sum(drops) / len(drops)) if drops else 0.0
        return max(0.0, min(100.0, 100 * (0.5 * sr + 0.3 * (p10 / 100) + 0.2 * (1 - mean_drop))))
    except Exception:
        return None
