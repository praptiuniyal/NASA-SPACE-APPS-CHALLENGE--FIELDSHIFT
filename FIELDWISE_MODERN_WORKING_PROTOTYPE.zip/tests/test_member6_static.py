from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def text(p): return (ROOT/p).read_text(encoding="utf-8")
def test_dashboard_contract_hooks():
    h=text("templates/dashboard.html"); j=text("static/js/dashboard.js")
    for s in ["dashboard.js","farmer_card.js","reweight.js","i18n.js","replayChart","dnaChart","runWhatIf","downloadCard"]: assert s in h
    for s in ['sessionStorage.getItem("fw_result")','fetch("/api/mock")','fetch("/api/simulate"',"PRIORITY_WEIGHTS","reweight(","new Chart","downloadFarmerCard"]: assert s in j
def test_farmer_card_canvas_contract():
    j=text("static/js/farmer_card.js")
    for s in ["1080","1350","fieldwise-farmer-card.png","toDataURL","Noto Sans Devanagari","t(card.headline"]: assert s in j
def test_methods_required_topics():
    m=text("templates/methods.html")
    for s in ["NASA POWER","Hargreaves","Penman","USDA-SCS","Ky","0.6","Resilience","Confidence","Farmer input","Reference estimate","Limits"]: assert s in m
