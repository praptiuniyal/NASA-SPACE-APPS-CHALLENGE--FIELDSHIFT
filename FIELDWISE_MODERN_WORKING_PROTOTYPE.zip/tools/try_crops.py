"""tools/try_crops.py  (Member 3)

Run from the project folder:   python tools/try_crops.py

Loads the first farm from data/demo_farms.json, fetches NASA data (needs internet),
and prints the top 3 crops per slot plus every rejected crop with its reason code.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def _code(message):
    """Short text for a message object like {'code': 'water_deficit', 'params': {...}}."""
    if not isinstance(message, dict):
        return str(message)
    params = message.get("params") or {}
    return message["code"] + (" %s" % params if params else "")


def main():
    try:
        from engine.nasa_api import get_history, get_nasa_data
        from engine.crop_engine import recommend_crops
    except Exception as exc:  # noqa: BLE001
        print("Could not import a needed file (is Member 2's work in engine/?):", exc)
        return 1

    with open(ROOT / "data" / "demo_farms.json", encoding="utf-8") as handle:
        data = json.load(handle)
    farms = data.get("farms") if isinstance(data, dict) else data
    farm = farms[0]

    try:  # use the cleaned farm if Member 1's validator exists
        from engine.farm_validation import validate_farm
        cleaned = validate_farm(farm).get("farm")
        farm = cleaned or farm
    except Exception:  # noqa: BLE001
        pass

    print("Farm:", farm.get("name"), "| soil:", farm.get("soil_type"),
          "| irrigation:", farm.get("irrigation"), "/", farm.get("water_availability"))
    lat, lon = farm["latitude"], farm["longitude"]
    climate = get_nasa_data(lat, lon)
    history = get_history(lat, lon)
    for name, value in (("climate", climate), ("history", history)):
        if isinstance(value, dict) and value.get("status") == "error":
            print("NASA %s failed: %s - %s" % (name, value.get("code"), value.get("message")))
            return 1

    result = recommend_crops(farm, climate, history)
    if result.get("status") == "error":
        print("recommend_crops failed: %s - %s" % (result.get("code"), result.get("message")))
        return 1

    for slot in ("kharif", "rabi", "zaid"):
        print("\n== %s: top 3 ==" % slot)
        for item in result["slots"][slot][:3]:
            print("  %-14s score %5.1f  sub_scores %s" % (item["crop"], item["score"], item["sub_scores"]))
        if not result["slots"][slot]:
            print("  (no crop passed)")

    print("\n== rejected ==")
    for item in result["rejected"]:
        print("  %-14s %-7s %s" % (item["crop"], item["season"], _code(item["reject_reason"])))
    if not result["rejected"]:
        print("  (none)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
