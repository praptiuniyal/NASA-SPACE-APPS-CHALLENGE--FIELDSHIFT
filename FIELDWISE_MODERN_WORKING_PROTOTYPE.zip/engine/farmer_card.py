"""Member 6: build the shareable Farmer Card data object."""
def _error(code, message):
    return {"status": "error", "code": code, "message": message}

def build_farmer_card(farm, rotations, replays, comparison, nasa_used):
    """Return farmer_card exactly in the shared-contract shape; never raise."""
    try:
        if not rotations or not replays:
            return _error("missing_data", "Rotations and replays are required.")
        top = rotations[0]
        replay = replays[0]
        slots = top.get("slots") or []
        crops = top.get("rotation") or []
        if len(slots) != 3 or len(crops) != 3:
            return _error("wrong_length", "Top rotation must contain three slots and crops.")
        water_saved = 0
        if comparison and comparison.get("status") != "no_plan":
            d = (comparison.get("difference") or {}).get("water_m3_per_ha")
            if d is not None:
                water_saved = max(0, -d)
        fetched_on = (nasa_used or {}).get("fetched_on")
        return {
            "language": farm.get("language", "en"),
            "headline": {"code": "card_headline",
                         "params": {"rotation": ", ".join(crops)}},
            "rotation": [{"slot": s, "crop": c} for s, c in zip(slots, crops)],
            "three_numbers": {
                "survival_rate": replay.get("survival_rate"),
                "water_saved_m3_per_ha": water_saved,
                "score": top.get("final_score"),
            },
            "warnings": list(top.get("warnings") or []),
            "footer": {"code": "card_footer",
                       "params": {"source": "NASA POWER", "date": fetched_on}},
        }
    except Exception as e:
        return _error("internal_error", f"build_farmer_card failed: {type(e).__name__}: {e}")
