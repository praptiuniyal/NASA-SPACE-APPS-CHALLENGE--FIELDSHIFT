"""Member 4: generate candidate 3-crop rotations."""
SLOT_ORDER = ["kharif", "rabi", "zaid"]

def _error(code, message):
    return {"status": "error", "code": code, "message": message}

def _slots(start):
    try:
        i = SLOT_ORDER.index(start)
    except ValueError:
        return None
    return [SLOT_ORDER[(i+j) % 3] for j in range(3)]

def generate_rotations(farm, climate, crops):
    """Return up to 300 candidate rotations, best crop-score sums first."""
    try:
        slots = _slots(farm.get("start_season"))
        if slots is None:
            return _error("invalid_choice", "Invalid start_season.")
        if not isinstance(crops, dict) or not isinstance(crops.get("slots"), dict):
            return _error("no_candidates", "Crop recommendations are unavailable.")
        choices = []
        score_maps = []
        for slot in slots:
            usable = [r for r in crops["slots"].get(slot, [])
                      if isinstance(r, dict) and not r.get("rejected", False)]
            usable.sort(key=lambda r: r.get("score") if r.get("score") is not None else -1,
                        reverse=True)
            usable = usable[:8]
            if not usable:
                return _error("no_candidates", f"No usable crops for {slot}.")
            choices.append([r.get("crop") for r in usable if r.get("crop")])
            score_maps.append({r.get("crop"): (r.get("score") or 0) for r in usable})
        candidates = []
        for a in choices[0]:
            for b in choices[1]:
                if a == b:
                    continue
                for c in choices[2]:
                    if b == c:
                        continue
                    score = score_maps[0][a] + score_maps[1][b] + score_maps[2][c]
                    candidates.append((score, [a, b, c]))
        candidates.sort(key=lambda x: x[0], reverse=True)
        return [r for _, r in candidates[:300]]
    except Exception as e:
        return _error("internal_error", f"generate_rotations failed: {type(e).__name__}: {e}")
