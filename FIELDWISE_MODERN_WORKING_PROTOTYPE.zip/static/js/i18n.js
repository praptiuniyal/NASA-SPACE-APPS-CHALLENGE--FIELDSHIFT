(function () {
  "use strict";
  const cache = new Map();

  async function loadLanguage(lang) {
    if (cache.has(lang)) return cache.get(lang);
    const response = await fetch(`/static/i18n/${encodeURIComponent(lang)}.json`);
    if (!response.ok) throw new Error(`Could not load language: ${lang}`);
    const messages = await response.json();
    cache.set(lang, messages);
    return messages;
  }

  function interpolate(template, params) {
    return String(template).replace(/\{([^}]+)\}/g, (match, key) =>
      Object.prototype.hasOwnProperty.call(params || {}, key) ? String(params[key]) : match
    );
  }

  window.t = async function t(message, lang) {
    if (!message || typeof message !== "object") return String(message || "");
    const chosen = lang || localStorage.getItem("fw_language") || "en";
    try {
      const messages = await loadLanguage(chosen);
      return interpolate(messages[message.code] || message.code, message.params || {});
    } catch (_error) {
      if (chosen !== "en") {
        try {
          const messages = await loadLanguage("en");
          return interpolate(messages[message.code] || message.code, message.params || {});
        } catch (_ignored) { /* return code below */ }
      }
      return message.code;
    }
  };

  window.tAll = async function tAll(listOfMessages, lang) {
    return Promise.all((listOfMessages || []).map((message) => window.t(message, lang)));
  };

  window.setLanguage = function setLanguage(lang) {
    localStorage.setItem("fw_language", lang || "en");
  };
}());
