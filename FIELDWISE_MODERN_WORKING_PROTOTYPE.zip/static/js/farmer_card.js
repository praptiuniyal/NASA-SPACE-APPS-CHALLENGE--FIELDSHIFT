(function(global){
"use strict";
function rounded(ctx,x,y,w,h,r){
  ctx.beginPath(); ctx.roundRect(x,y,w,h,r); ctx.fill(); ctx.stroke();
}
function downloadFarmerCard(card){
  if(!card) return;
  const lang=card.language||"en";
  const c=document.createElement("canvas"); c.width=1080; c.height=1350;
  const x=c.getContext("2d");
  x.fillStyle="#f7faf7"; x.fillRect(0,0,c.width,c.height);
  x.fillStyle="#163b2b"; x.font='700 58px "Noto Sans Devanagari","Nirmala UI","Mangal",sans-serif';
  x.fillText("FIELDWISE AI",70,95);
  x.font='700 42px "Noto Sans Devanagari","Nirmala UI","Mangal",sans-serif';
  x.fillText(t(card.headline,lang),70,165);
  const boxes=card.rotation||[];
  boxes.forEach((r,i)=>{
    const bx=70+i*330, by=250;
    x.fillStyle="#ffffff"; x.strokeStyle="#2d6a4f"; x.lineWidth=4; rounded(x,bx,by,280,180,22);
    x.fillStyle="#2d6a4f"; x.font='600 28px "Noto Sans Devanagari","Nirmala UI","Mangal",sans-serif';
    x.fillText(String(r.slot).toUpperCase(),bx+25,by+55);
    x.fillStyle="#111"; x.font='700 36px "Noto Sans Devanagari","Nirmala UI","Mangal",sans-serif';
    x.fillText(r.crop,bx+25,by+115);
    if(i<2){ x.fillStyle="#2d6a4f"; x.font="700 48px sans-serif"; x.fillText("→",bx+285,by+105); }
  });
  const n=card.three_numbers||{};
  const vals=[
    ["Survival", n.survival_rate==null?"—":Math.round(n.survival_rate*100)+"%"],
    ["Water saved", n.water_saved_m3_per_ha==null?"—":Math.round(n.water_saved_m3_per_ha)+" m³/ha"],
    ["Score", n.score==null?"—":Math.round(n.score)+"/100"]
  ];
  vals.forEach((v,i)=>{
    const bx=70+i*330,by=520;
    x.fillStyle="#e9f5ee";x.strokeStyle="#b7d8c4";rounded(x,bx,by,280,190,22);
    x.fillStyle="#456";x.font='500 25px "Noto Sans Devanagari","Nirmala UI","Mangal",sans-serif';x.fillText(v[0],bx+22,by+55);
    x.fillStyle="#163b2b";x.font='700 39px "Noto Sans Devanagari","Nirmala UI","Mangal",sans-serif';x.fillText(v[1],bx+22,by+125);
  });
  x.fillStyle="#8a5a00"; x.font='500 25px "Noto Sans Devanagari","Nirmala UI","Mangal",sans-serif';
  let yy=800; (card.warnings||[]).forEach(w=>{ x.fillText("• "+t(w,lang),70,yy); yy+=40; });
  x.fillStyle="#445"; x.font='500 26px "Noto Sans Devanagari","Nirmala UI","Mangal",sans-serif';
  x.fillText(t(card.footer,lang),70,1240);
  x.font="22px sans-serif"; x.fillText("Model guidance — not a harvest guarantee",70,1290);
  const a=document.createElement("a"); a.download="fieldwise-farmer-card.png"; a.href=c.toDataURL("image/png"); a.click();
}
global.downloadFarmerCard=downloadFarmerCard;
})(window);
